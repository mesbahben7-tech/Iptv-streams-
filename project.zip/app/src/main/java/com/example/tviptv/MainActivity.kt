package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val host = findViewById<EditText>(R.id.host)
        val user = findViewById<EditText>(R.id.user)
        val pass = findViewById<EditText>(R.id.pass)
        val login = findViewById<Button>(R.id.login)
        val status = findViewById<TextView>(R.id.status)
        val prefs = getSharedPreferences("acc", MODE_PRIVATE)

        host.setText(prefs.getString("host", ""))
        user.setText(prefs.getString("user", ""))
        pass.setText(prefs.getString("pass", ""))

        login.setOnClickListener {
            val acc = Account.from(host.text.toString(), user.text.toString(), pass.text.toString())
            status.text = getString(R.string.connecting)
            login.isEnabled = false
            lifecycleScope.launch {
                try {
                    XtreamApi.login(acc)
                    prefs.edit()
                        .putString("host", acc.host)
                        .putString("user", acc.user)
                        .putString("pass", acc.pass)
                        .apply()
                    Session.account = acc
                    Session.stalker = null
                    getSharedPreferences("app", MODE_PRIVATE).edit().putString("last", "xtream").apply()
                    status.text = ""
                    startActivity(Intent(this@MainActivity, HomeActivity::class.java))
                } catch (e: Exception) {
                    status.text = getString(R.string.load_error, e.message ?: "")
                } finally {
                    login.isEnabled = true
                }
            }
        }
    }
}
