package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HistoryActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var filterAdapter: TextAdapter
    private lateinit var posterAdapter: PosterAdapter
    private var shown: List<Hist> = emptyList()
    private var filter = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        setContentView(R.layout.activity_channels)
        status = findViewById(R.id.status)
        val rvFilter = findViewById<RecyclerView>(R.id.categories)
        val rvGrid = findViewById<RecyclerView>(R.id.channels)

        filterAdapter = TextAdapter { i ->
            filter = i
            refresh()
        }
        posterAdapter = PosterAdapter({ i -> remove(i) }) { i -> open(i) }
        filterAdapter.items = listOf(
            getString(R.string.all),
            getString(R.string.movies),
            getString(R.string.series),
            getString(R.string.live)
        )
        rvFilter.layoutManager = LinearLayoutManager(this)
        rvFilter.adapter = filterAdapter

        val dm = resources.displayMetrics
        val widthDp = dm.widthPixels / dm.density
        val span = ((widthDp * 0.62f) / 150f).toInt().coerceAtLeast(2)
        rvGrid.layoutManager = GridLayoutManager(this, span)
        rvGrid.adapter = posterAdapter

        Toast.makeText(this, R.string.hist_hint, Toast.LENGTH_LONG).show()
        rvFilter.post { rvFilter.requestFocus() }
    }

    override fun onResume() {
        super.onResume()
        if (Session.hasSource()) refresh()
    }

    private fun refresh() {
        val all = History.list(this)
        shown = when (filter) {
            1 -> all.filter { it.kind == Kind.MOVIES }
            2 -> all.filter { it.kind == Kind.SERIES }
            3 -> all.filter { it.kind == Kind.LIVE }
            else -> all
        }
        posterAdapter.items = shown.map { History.display(this, it) }
        if (shown.isEmpty()) {
            status.text = getString(R.string.no_items)
            status.visibility = View.VISIBLE
        } else {
            status.visibility = View.GONE
        }
    }

    private fun open(i: Int) {
        if (i >= shown.size) return
        val h = shown[i]
        if (h.kind == Kind.LIVE) {
            Playback.play(this, Kind.LIVE, listOf(h.entry), 0)
        } else {
            Session.detail = Fav(h.kind, h.entry)
            startActivity(Intent(this, DetailsActivity::class.java))
        }
    }

    private fun remove(i: Int) {
        if (i >= shown.size) return
        val h = shown[i]
        History.remove(this, h.kind, h.entry.id)
        Toast.makeText(this, R.string.hist_removed, Toast.LENGTH_SHORT).show()
        refresh()
    }
}
