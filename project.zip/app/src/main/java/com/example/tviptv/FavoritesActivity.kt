package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FavoritesActivity : AppCompatActivity() {

    private val kinds = listOf(Kind.LIVE, Kind.MOVIES, Kind.SERIES)
    private var current = Kind.LIVE
    private var shown: List<Fav> = emptyList()
    private lateinit var status: TextView
    private lateinit var rvKinds: RecyclerView
    private lateinit var rvFavs: RecyclerView
    private lateinit var kindAdapter: TextAdapter
    private lateinit var favAdapter: TextAdapter

    private fun kindName(k: Kind): String = when (k) {
        Kind.LIVE -> getString(R.string.live)
        Kind.MOVIES -> getString(R.string.movies)
        Kind.SERIES -> getString(R.string.series)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        setContentView(R.layout.activity_channels)
        status = findViewById(R.id.status)
        rvKinds = findViewById(R.id.categories)
        rvFavs = findViewById(R.id.channels)

        kindAdapter = TextAdapter { i ->
            current = kinds[i]
            refresh()
        }
        favAdapter = TextAdapter(onLongClick = { i -> remove(i) }) { i -> open(i) }
        rvKinds.layoutManager = LinearLayoutManager(this)
        rvFavs.layoutManager = LinearLayoutManager(this)
        rvKinds.adapter = kindAdapter
        rvFavs.adapter = favAdapter
        refresh()
        rvKinds.post { rvKinds.requestFocus() }
    }

    private fun refresh() {
        val all = Store.favorites(this)
        kindAdapter.items = kinds.map { k -> kindName(k) + " (" + all.count { it.kind == k } + ")" }
        shown = all.filter { it.kind == current }
        favAdapter.items = shown.map { it.entry.name }
        if (shown.isEmpty()) {
            status.text = getString(R.string.no_items)
            status.visibility = View.VISIBLE
        } else {
            status.visibility = View.GONE
        }
    }

    private fun open(i: Int) {
        if (i >= shown.size) return
        val f = shown[i]
        when (f.kind) {
            Kind.LIVE -> Playback.play(this, Kind.LIVE, shown.map { it.entry }, i)
            else -> {
                Session.detail = f
                startActivity(Intent(this, DetailsActivity::class.java))
            }
        }
    }

    private fun remove(i: Int) {
        if (i >= shown.size) return
        val f = shown[i]
        Store.toggleFav(this, f.kind, f.entry)
        Toast.makeText(this, R.string.fav_removed, Toast.LENGTH_SHORT).show()
        refresh()
    }
}
