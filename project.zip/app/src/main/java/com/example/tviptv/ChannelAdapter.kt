package com.example.tviptv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class ChannelAdapter(
    private val onLongClick: (Int) -> Unit,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<ChannelAdapter.VH>() {

    private var data: List<Entry> = emptyList()
    var favIds: Set<String> = emptySet()
    var selected: Int = -1

    var items: List<Entry>
        get() = data
        set(value) {
            data = value
            notifyDataSetChanged()
        }

    fun append(more: List<Entry>) {
        if (more.isEmpty()) return
        val start = data.size
        data = data + more
        notifyItemRangeInserted(start, more.size)
    }

    fun refresh(position: Int) {
        if (position in data.indices) notifyItemChanged(position)
    }

    fun select(position: Int) {
        val old = selected
        selected = position
        if (old in data.indices) notifyItemChanged(old)
        if (position in data.indices) notifyItemChanged(position)
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val num: TextView = view.findViewById(R.id.num)
        val logo: ImageView = view.findViewById(R.id.logo)
        val name: TextView = view.findViewById(R.id.name)
        val fav: TextView = view.findViewById(R.id.fav)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = data[position]
        holder.num.text = (position + 1).toString().padStart(3, '0')
        holder.name.text = e.name
        holder.fav.visibility = if (favIds.contains(e.id)) View.VISIBLE else View.GONE
        holder.itemView.isSelected = position == selected

        if (e.icon.startsWith("http")) {
            Glide.with(holder.logo).load(e.icon).override(96, 96).fitCenter().into(holder.logo)
        } else {
            Glide.with(holder.logo).clear(holder.logo)
            holder.logo.setImageDrawable(null)
        }

        holder.itemView.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
        holder.itemView.setOnLongClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) {
                onLongClick(p)
                true
            } else {
                false
            }
        }
    }

    override fun onViewRecycled(holder: VH) {
        try {
            Glide.with(holder.logo).clear(holder.logo)
        } catch (e: Exception) {
            // activity may already be destroyed
        }
        super.onViewRecycled(holder)
    }

    override fun getItemCount() = data.size
}
