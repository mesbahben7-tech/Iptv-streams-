package com.example.tviptv

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TextAdapter(
    private val layoutRes: Int = R.layout.item_text,
    private val onLongClick: ((Int) -> Unit)? = null,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<TextAdapter.VH>() {

    private var data: List<String> = emptyList()

    var items: List<String>
        get() = data
        set(value) {
            data = value
            notifyDataSetChanged()
        }

    fun append(more: List<String>) {
        if (more.isEmpty()) return
        val start = data.size
        data = data + more
        notifyItemRangeInserted(start, more.size)
    }

    fun update(position: Int, text: String) {
        if (position < 0 || position >= data.size) return
        val copy = data.toMutableList()
        copy[position] = text
        data = copy
        notifyItemChanged(position)
    }

    class VH(val tv: TextView) : RecyclerView.ViewHolder(tv)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val tv = LayoutInflater.from(parent.context)
            .inflate(layoutRes, parent, false) as TextView
        return VH(tv)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.tv.text = data[position]
        holder.tv.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
        val lc = onLongClick
        if (lc != null) {
            holder.tv.setOnLongClickListener {
                val p = holder.bindingAdapterPosition
                if (p != RecyclerView.NO_POSITION) {
                    lc(p)
                    true
                } else {
                    false
                }
            }
        }
    }

    override fun getItemCount() = data.size
}
