package com.example.tviptv

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Hist(
    val kind: Kind,
    val entry: Entry,
    val epId: String = "",
    val epExt: String = "",
    val epTitle: String = "",
    val pos: Long = 0L,
    val dur: Long = 0L,
    val time: Long = 0L,
    val plays: Int = 1
)

object History {
    private const val MAX = 120

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("history", Context.MODE_PRIVATE)
    private fun key(): String = "h:" + Store.sourceKey()

    private fun read(ctx: Context): MutableList<Hist> {
        val raw = prefs(ctx).getString(key(), null) ?: return mutableListOf()
        val out = mutableListOf<Hist>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val entry = Entry(
                    o.optString("id"), o.optString("n"), o.optString("e"), o.optString("c"),
                    o.optString("g"), o.optString("i"), o.optString("r"), o.optString("y"),
                    o.optString("p")
                )
                out.add(
                    Hist(
                        Kind.valueOf(o.getString("k")), entry,
                        o.optString("ei"), o.optString("ex"), o.optString("et"),
                        o.optLong("pos"), o.optLong("dur"), o.optLong("t"), o.optInt("pl", 1)
                    )
                )
            }
        } catch (e: Exception) {
            // ignore corrupted data
        }
        return out
    }

    private fun write(ctx: Context, list: List<Hist>) {
        val arr = JSONArray()
        for (h in list) {
            val o = JSONObject()
            o.put("k", h.kind.name)
            o.put("id", h.entry.id)
            o.put("n", h.entry.name)
            o.put("e", h.entry.ext)
            o.put("c", h.entry.cmd)
            o.put("g", h.entry.group)
            o.put("i", h.entry.icon)
            o.put("r", h.entry.rating)
            o.put("y", h.entry.year)
            o.put("p", h.entry.plot)
            o.put("ei", h.epId)
            o.put("ex", h.epExt)
            o.put("et", h.epTitle)
            o.put("pos", h.pos)
            o.put("dur", h.dur)
            o.put("t", h.time)
            o.put("pl", h.plays)
            arr.put(o)
        }
        prefs(ctx).edit().putString(key(), arr.toString()).apply()
    }

    fun list(ctx: Context): List<Hist> = read(ctx).sortedByDescending { it.time }

    fun find(ctx: Context, kind: Kind, id: String): Hist? =
        read(ctx).firstOrNull { it.kind == kind && it.entry.id == id }

    fun touch(
        ctx: Context, kind: Kind, entry: Entry,
        epId: String = "", epExt: String = "", epTitle: String = ""
    ) {
        val l = read(ctx)
        val idx = l.indexOfFirst { it.kind == kind && it.entry.id == entry.id }
        val now = System.currentTimeMillis()
        if (idx >= 0) {
            val o = l.removeAt(idx)
            val same = o.epId == epId
            l.add(
                0,
                o.copy(
                    entry = entry, epId = epId, epExt = epExt, epTitle = epTitle,
                    pos = if (same) o.pos else 0L, dur = if (same) o.dur else 0L,
                    time = now, plays = o.plays + 1
                )
            )
        } else {
            l.add(0, Hist(kind, entry, epId, epExt, epTitle, 0L, 0L, now, 1))
        }
        while (l.size > MAX) l.removeAt(l.size - 1)
        write(ctx, l)
    }

    fun setEpisode(ctx: Context, item: PlayItem) {
        if (item.histId.isEmpty() || item.histEp.isEmpty()) return
        val kind = try {
            Kind.valueOf(item.histKind)
        } catch (e: Exception) {
            return
        }
        val l = read(ctx)
        val idx = l.indexOfFirst { it.kind == kind && it.entry.id == item.histId }
        if (idx < 0) return
        l[idx] = l[idx].copy(
            epId = item.histEp, epExt = item.histExt, epTitle = item.title,
            pos = 0L, dur = 0L, time = System.currentTimeMillis()
        )
        write(ctx, l)
    }

    fun save(ctx: Context, item: PlayItem, pos: Long, dur: Long) {
        if (item.histId.isEmpty()) return
        val kind = try {
            Kind.valueOf(item.histKind)
        } catch (e: Exception) {
            return
        }
        val l = read(ctx)
        val idx = l.indexOfFirst { it.kind == kind && it.entry.id == item.histId }
        if (idx < 0) return
        val o = l[idx]
        if (item.histEp.isNotEmpty() && o.epId != item.histEp) return
        val finished = dur > 0L && pos >= dur - 30000L
        l[idx] = o.copy(pos = if (finished) 0L else pos, dur = dur)
        write(ctx, l)
    }

    fun resume(ctx: Context, item: PlayItem): Long {
        if (item.histId.isEmpty()) return 0L
        val kind = try {
            Kind.valueOf(item.histKind)
        } catch (e: Exception) {
            return 0L
        }
        val o = find(ctx, kind, item.histId) ?: return 0L
        if (item.histEp.isNotEmpty() && o.epId != item.histEp) return 0L
        return if (o.pos > 15000L) o.pos else 0L
    }

    fun remove(ctx: Context, kind: Kind, id: String) {
        write(ctx, read(ctx).filter { !(it.kind == kind && it.entry.id == id) })
    }

    fun mostWatched(ctx: Context, limit: Int): List<Hist> =
        read(ctx)
            .filter { it.kind != Kind.LIVE }
            .sortedWith(compareByDescending<Hist> { it.plays }.thenByDescending { it.time })
            .take(limit)

    fun display(ctx: Context, h: Hist): Entry {
        val sub = if (h.kind == Kind.SERIES && h.epTitle.isNotEmpty()) {
            ctx.getString(R.string.ep_label, h.epTitle)
        } else if (h.dur > 0L && h.pos > 0L) {
            "▶ " + (h.pos * 100L / h.dur) + "%"
        } else {
            ""
        }
        return h.entry.copy(rating = "", year = sub)
    }
}
