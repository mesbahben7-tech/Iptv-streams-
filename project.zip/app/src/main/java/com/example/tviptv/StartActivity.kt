package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class StartActivity : AppCompatActivity() {

    private lateinit var adapter: ServerAdapter
    private lateinit var status: TextView
    private lateinit var lblServers: TextView
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)
        status = findViewById(R.id.status)
        lblServers = findViewById(R.id.lbl_servers)

        findViewById<View>(R.id.btn_add).setOnClickListener {
            startActivity(Intent(this, AddServerActivity::class.java))
        }
        findViewById<View>(R.id.tile_m3u).setOnClickListener { openForm("m3u") }
        findViewById<View>(R.id.tile_xtream).setOnClickListener { openForm("xtream") }
        findViewById<View>(R.id.tile_stalker).setOnClickListener { openForm("stalker") }

        adapter = ServerAdapter({ s -> openServer(s) }) { s -> editServer(s) }
        val rv = findViewById<RecyclerView>(R.id.servers)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        showPreviousCrash()
        findViewById<View>(R.id.btn_add).requestFocus()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val list = ServerStore.list(this)
        adapter.items = list
        lblServers.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun openForm(type: String) {
        startActivity(Intent(this, ServerFormActivity::class.java).putExtra("type", type))
    }

    private fun editServer(s: Server) {
        startActivity(Intent(this, ServerFormActivity::class.java).putExtra("id", s.id))
    }

    private fun openServer(s: Server) {
        if (busy) return
        if (!s.enabled) {
            status.text = getString(R.string.server_disabled)
            return
        }
        busy = true
        status.text = getString(R.string.connecting)
        lifecycleScope.launch {
            try {
                Connector.connect(this@StartActivity, s)
                status.text = ""
                startActivity(Intent(this@StartActivity, HomeActivity::class.java))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                ServerStore.setStatus(this@StartActivity, s.id, false)
                refresh()
                status.text = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
            } finally {
                busy = false
            }
        }
    }

    private fun showPreviousCrash() {
        val cp = getSharedPreferences("crash", MODE_PRIVATE)
        val log = cp.getString("log", null) ?: return
        cp.edit().remove("log").apply()
        AlertDialog.Builder(this)
            .setTitle("سبب إغلاق التطبيق في المرة السابقة")
            .setMessage(log)
            .setPositiveButton("حسنًا", null)
            .show()
    }
}
