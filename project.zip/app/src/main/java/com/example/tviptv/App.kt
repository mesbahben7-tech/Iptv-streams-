package com.example.tviptv

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("crash", MODE_PRIVATE)
                    .edit()
                    .putString("log", e.stackTraceToString().take(2500))
                    .commit()
            } catch (ex: Throwable) {
                // ignore
            }
            prev?.uncaughtException(t, e)
        }
    }
}
