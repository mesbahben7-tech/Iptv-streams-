package com.streamplayer.iptv

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.background

/** هل يعمل التطبيق على Android TV / صندوق تلفاز؟ */
fun detectTv(ctx: Context): Boolean {
    val ui = ctx.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
    return ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
        ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
}

val LocalIsTv = compositionLocalOf { false }

/** واجهة عريضة (تلفاز أو شاشة كبيرة) */
@Composable
fun isWideScreen(): Boolean = LocalIsTv.current || LocalConfiguration.current.screenWidthDp >= 800

/**
 * إطار تركيز واضح للتحكم بالريموت (D-pad).
 * يجب وضعه قبل `.clickable` / `.focusable` مباشرة حتى يراقب تركيز العنصر نفسه.
 */
fun Modifier.focusHighlight(shape: Shape = RoundedCornerShape(12.dp)): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    this.onFocusChanged { f = it.hasFocus }
        .border(if (f) 3.dp else 0.dp, if (f) Accent else Color.Transparent, shape)
}

/** أيقونة نصية قابلة للتركيز بالريموت (تكون غير قابلة للتركيز إن لم يوجد onClick) */
@Composable
fun FocusIcon(
    glyph: String, color: Color = Accent, size: TextUnit = 20.sp,
    modifier: Modifier = Modifier, onClick: (() -> Unit)? = null
) {
    var f by remember { mutableStateOf(false) }
    val sh = RoundedCornerShape(10.dp)
    var m = modifier.clip(sh).background(if (f) Color(0xFF123E83) else Color.Transparent)
        .border(if (f) 2.dp else 0.dp, if (f) Accent else Color.Transparent, sh)
    if (onClick != null) m = m.onFocusChanged { f = it.isFocused }.clickable(onClick = onClick)
    Box(m.padding(horizontal = 6.dp, vertical = 4.dp), contentAlignment = Alignment.Center) {
        Text(glyph, color = color, fontSize = size)
    }
}
