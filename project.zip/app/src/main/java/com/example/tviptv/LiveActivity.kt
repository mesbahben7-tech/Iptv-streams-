package com.example.tviptv

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class LiveActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var liveName: TextView
    private lateinit var rvCats: RecyclerView
    private lateinit var rvCh: RecyclerView
    private lateinit var catAdapter: TextAdapter
    private lateinit var chAdapter: ChannelAdapter
    private lateinit var epgAdapter: TextAdapter
    private lateinit var preview: PreviewPlayer
    private var cats: List<Category> = emptyList()
    private var entries: List<Entry> = emptyList()
    private var favIds: Set<String> = emptySet()
    private var selected = -1
    private var loadJob: Job? = null
    private var epgJob: Job? = null
    private var pickMode = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        pickMode = intent.getBooleanExtra("pick", false)
        favIds = Store.favIds(this, Kind.LIVE)
        setContentView(R.layout.activity_live)
        status = findViewById(R.id.status)
        liveName = findViewById(R.id.live_name)
        rvCats = findViewById(R.id.categories)
        rvCh = findViewById(R.id.channels)
        val rvEpg = findViewById<RecyclerView>(R.id.epg)
        val pv = findViewById<PlayerView>(R.id.preview)
        pv.useController = false
        preview = PreviewPlayer(this, pv) {
            Toast.makeText(this, R.string.preview_error, Toast.LENGTH_SHORT).show()
        }

        catAdapter = TextAdapter { i -> loadEntries(cats[i]) }
        chAdapter = ChannelAdapter({ i -> toggleFav(i) }) { i -> onChannelClick(i) }
        chAdapter.favIds = favIds
        epgAdapter = TextAdapter(R.layout.item_epg) { }
        rvCats.layoutManager = LinearLayoutManager(this)
        rvCh.layoutManager = LinearLayoutManager(this)
        rvEpg.layoutManager = LinearLayoutManager(this)
        rvCats.adapter = catAdapter
        rvCh.adapter = chAdapter
        rvEpg.adapter = epgAdapter

        findViewById<Button>(R.id.btn_full).setOnClickListener { goFull() }

        showStatus(getString(R.string.connecting))
        lifecycleScope.launch {
            try {
                val list = fetchCategories()
                cats = listOf(Category("", getString(R.string.all))) + list
                catAdapter.items = cats.map { it.name }
                status.visibility = View.GONE
                if (cats.size > 1) loadEntries(cats[1]) else loadEntries(cats[0])
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showStatus(getString(R.string.load_error, e.message ?: e.javaClass.simpleName))
            }
        }
    }

    override fun onStart() {
        super.onStart()
        if (!Session.hasSource() || !::preview.isInitialized) return
        preview.start()
        if (selected in entries.indices) {
            preview.play(Playback.item(Kind.LIVE, entries[selected]))
        }
    }

    override fun onStop() {
        super.onStop()
        if (::preview.isInitialized) preview.stop()
    }

    private fun showStatus(msg: String) {
        status.text = msg
        status.visibility = View.VISIBLE
    }

    private suspend fun fetchCategories(): List<Category> {
        val sa = Session.stalker
        val acc = Session.account
        return if (sa != null) {
            StalkerApi.categories(sa, Kind.LIVE)
        } else if (acc != null) {
            XtreamApi.categories(acc, Kind.LIVE)
        } else if (Session.m3u != null) {
            Session.m3u?.categories(Kind.LIVE) ?: emptyList()
        } else {
            emptyList()
        }
    }

    private fun onChannelClick(i: Int) {
        if (i >= entries.size) return
        if (pickMode) {
            Session.picked = entries[i]
            setResult(RESULT_OK)
            finish()
            return
        }
        if (i == selected) {
            goFull()
            return
        }
        selected = i
        chAdapter.select(i)
        val e = entries[i]
        liveName.text = e.name
        preview.play(Playback.item(Kind.LIVE, e))
        loadEpg(e)
    }

    private fun goFull() {
        if (selected in entries.indices) {
            Playback.play(this, Kind.LIVE, entries, selected)
        }
    }

    private fun toggleFav(i: Int) {
        if (i >= entries.size) return
        val e = entries[i]
        val now = Store.toggleFav(this, Kind.LIVE, e)
        favIds = if (now) favIds + e.id else favIds - e.id
        chAdapter.favIds = favIds
        chAdapter.refresh(i)
        Toast.makeText(this, if (now) R.string.fav_added else R.string.fav_removed, Toast.LENGTH_SHORT).show()
    }

    private fun loadEpg(e: Entry) {
        epgJob?.cancel()
        epgAdapter.items = listOf(getString(R.string.connecting))
        epgJob = lifecycleScope.launch {
            try {
                val sa = Session.stalker
                val acc = Session.account
                val list = if (sa != null) {
                    StalkerApi.epg(sa, e.id)
                } else if (acc != null) {
                    XtreamApi.epg(acc, e.id)
                } else {
                    emptyList()
                }
                val lines = list.map { (if (it.now) "▶ " else "") + it.time + "   " + it.title }
                epgAdapter.items = if (lines.isEmpty()) listOf(getString(R.string.no_epg)) else lines
            } catch (ex: CancellationException) {
                throw ex
            } catch (ex: Throwable) {
                epgAdapter.items = listOf(getString(R.string.no_epg))
            }
        }
    }

    private fun showEntries() {
        selected = -1
        chAdapter.selected = -1
        chAdapter.items = entries
        rvCh.scrollToPosition(0)
        if (entries.isEmpty()) {
            showStatus(getString(R.string.no_items))
        } else {
            status.visibility = View.GONE
            rvCh.post { rvCh.requestFocus() }
        }
    }

    private fun loadEntries(cat: Category) {
        loadJob?.cancel()
        showStatus(getString(R.string.connecting))
        loadJob = lifecycleScope.launch {
            try {
                val sa = Session.stalker
                val acc = Session.account
                if (sa != null) {
                    loadStalker(sa, cat)
                } else if (acc != null) {
                    entries = XtreamApi.entries(acc, Kind.LIVE, cat.id)
                    showEntries()
                } else if (Session.m3u != null) {
                    entries = Session.m3u?.entries(Kind.LIVE, cat.id) ?: emptyList()
                    showEntries()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showStatus(getString(R.string.load_error, e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private suspend fun loadStalker(sa: StalkerAccount, cat: Category) {
        val catId = if (cat.id.isEmpty()) "*" else cat.id
        entries = emptyList()
        selected = -1
        chAdapter.selected = -1
        chAdapter.items = emptyList()
        val collected = mutableListOf<Entry>()
        var p = 1
        while (p <= 100) {
            val pg = StalkerApi.page(sa, "itv", catId, p)
            if (pg.items.isEmpty()) break
            collected.addAll(pg.items)
            chAdapter.append(pg.items)
            entries = collected.toList()
            if (p == 1) {
                status.visibility = View.GONE
                rvCh.post { rvCh.requestFocus() }
            }
            if (pg.total <= 0 || collected.size >= pg.total) break
            p++
        }
        if (collected.isEmpty()) {
            val all = StalkerApi.allChannels(sa)
            entries = if (cat.id.isEmpty()) all else all.filter { it.group == cat.id }
            showEntries()
        }
    }
}
