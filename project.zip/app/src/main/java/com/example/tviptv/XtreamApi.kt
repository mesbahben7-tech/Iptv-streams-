package com.example.tviptv

import android.util.JsonReader
import android.util.JsonToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object XtreamApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    private fun apiUrl(a: Account, action: String?, extra: Map<String, String> = emptyMap()): String {
        val b = "${a.host}/player_api.php".toHttpUrl().newBuilder()
            .addQueryParameter("username", a.user)
            .addQueryParameter("password", a.pass)
        if (action != null) b.addQueryParameter("action", action)
        extra.forEach { (k, v) -> b.addQueryParameter(k, v) }
        return b.build().toString()
    }

    private fun get(url: String): String {
        val req = Request.Builder().url(url).header("User-Agent", "IPTVPlayer/1.0").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            return r.body?.string() ?: throw IOException("Empty response")
        }
    }

    suspend fun login(a: Account) {
        withContext(Dispatchers.IO) {
            val ui = JSONObject(get(apiUrl(a, null))).optJSONObject("user_info")
            if (ui == null || ui.optString("auth") != "1") {
                throw IOException("بيانات الدخول غير صحيحة")
            }
        }
    }

    private fun fmt(sec: Long): String =
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(sec * 1000))

    suspend fun info(a: Account): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val j = JSONObject(get(apiUrl(a, null)))
        val ui = j.optJSONObject("user_info") ?: JSONObject()
        val si = j.optJSONObject("server_info") ?: JSONObject()
        val now = System.currentTimeMillis() / 1000
        val expSec = ui.optString("exp_date").toLongOrNull()
        val expText = if (expSec == null) {
            "غير محدود"
        } else {
            val days = (expSec - now) / 86400
            val left = if (days >= 0) "باقي $days يوم" else "منتهي"
            "${fmt(expSec)} ($left)"
        }
        val created = ui.optString("created_at").toLongOrNull()?.let { fmt(it) } ?: "-"
        val trial = if (ui.optString("is_trial") == "1") "نعم" else "لا"
        listOf(
            "المستخدم" to ui.optString("username"),
            "الحالة" to ui.optString("status"),
            "تاريخ الانتهاء" to expText,
            "تاريخ الإنشاء" to created,
            "حساب تجريبي" to trial,
            "الاتصالات النشطة" to ui.optString("active_cons"),
            "أقصى عدد اتصالات" to ui.optString("max_connections"),
            "السيرفر" to a.host,
            "المنفذ" to si.optString("port"),
            "المنطقة الزمنية" to si.optString("timezone")
        )
    }

    suspend fun categories(a: Account, kind: Kind): List<Category> = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(apiUrl(a, kind.catAction))
            .header("User-Agent", "IPTVPlayer/1.0")
            .build()
        val out = ArrayList<Category>()
        val keys = setOf("category_id", "category_name")
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body ?: throw IOException("Empty response")
            JsonReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { rd ->
                rd.isLenient = true
                JsonStream.readObjects(rd, keys) { m ->
                    out.add(Category(m["category_id"] ?: "", m["category_name"] ?: ""))
                }
            }
        }
        out
    }

    suspend fun entries(a: Account, kind: Kind, categoryId: String): List<Entry> =
        withContext(Dispatchers.IO) {
            val extra = if (categoryId.isEmpty()) emptyMap() else mapOf("category_id" to categoryId)
            val req = Request.Builder()
                .url(apiUrl(a, kind.listAction, extra))
                .header("User-Agent", "IPTVPlayer/1.0")
                .build()
            val out = ArrayList<Entry>()
            val keys = setOf(kind.idKey, "name", "container_extension")
            client.newCall(req).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val body = r.body ?: throw IOException("Empty response")
                JsonReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { rd ->
                    rd.isLenient = true
                    JsonStream.readObjects(rd, keys) { m ->
                        out.add(
                            Entry(
                                m[kind.idKey] ?: "",
                                m["name"] ?: "",
                                (m["container_extension"] ?: "").ifBlank { "mp4" }
                            )
                        )
                    }
                }
            }
            out
        }

    suspend fun count(a: Account, kind: Kind): Int = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(apiUrl(a, kind.listAction))
            .header("User-Agent", "IPTVPlayer/1.0")
            .build()
        var n = 0
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body ?: throw IOException("Empty response")
            JsonReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { rd ->
                rd.isLenient = true
                if (rd.peek() == JsonToken.BEGIN_ARRAY) {
                    rd.beginArray()
                    while (rd.hasNext()) {
                        rd.skipValue()
                        n++
                    }
                    rd.endArray()
                }
            }
        }
        n
    }

    suspend fun episodes(a: Account, seriesId: String): List<Episode> = withContext(Dispatchers.IO) {
        val j = JSONObject(get(apiUrl(a, "get_series_info", mapOf("series_id" to seriesId))))
        val out = mutableListOf<Episode>()

        fun addList(arr: JSONArray, defaultSeason: Int) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Episode(
                        o.optString("id"),
                        o.optString("title"),
                        o.optString("container_extension").ifBlank { "mp4" },
                        o.optInt("season", defaultSeason),
                        o.optInt("episode_num", i + 1)
                    )
                )
            }
        }

        val eps = j.opt("episodes")
        if (eps is JSONObject) {
            val ks = eps.keys()
            while (ks.hasNext()) {
                val k = ks.next()
                val list = eps.optJSONArray(k)
                if (list != null) addList(list, k.toIntOrNull() ?: 1)
            }
        } else if (eps is JSONArray) {
            for (i in 0 until eps.length()) {
                val list = eps.optJSONArray(i)
                if (list != null) addList(list, i + 1)
            }
        }
        out.sortedWith(compareBy({ it.season }, { it.num }))
    }

    fun url(a: Account, kind: Kind, e: Entry): String = when (kind) {
        Kind.LIVE -> "${a.host}/live/${a.user}/${a.pass}/${e.id}.ts"
        Kind.MOVIES -> "${a.host}/movie/${a.user}/${a.pass}/${e.id}.${e.ext}"
        Kind.SERIES -> ""
    }

    fun altUrl(a: Account, kind: Kind, e: Entry): String = when (kind) {
        Kind.LIVE -> "${a.host}/live/${a.user}/${a.pass}/${e.id}.m3u8"
        else -> ""
    }

    fun episodeUrl(a: Account, ep: Episode): String =
        "${a.host}/series/${a.user}/${a.pass}/${ep.id}.${ep.ext}"
}
