package com.example.tviptv

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

data class Fav(val kind: Kind, val entry: Entry)

object Store {
    private const val MAX_RECENT = 12

    fun sourceKey(): String {
        val s = Session.stalker
        val a = Session.account
        return if (s != null) {
            "s:${s.portal}|${s.mac}"
        } else if (a != null) {
            "x:${a.host}|${a.user}"
        } else {
            "none"
        }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("store", Context.MODE_PRIVATE)

    private fun read(ctx: Context, name: String): MutableList<Fav> {
        val raw = prefs(ctx).getString("$name:${sourceKey()}", null) ?: return mutableListOf()
        val out = mutableListOf<Fav>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Fav(
                        Kind.valueOf(o.getString("k")),
                        Entry(
                            o.optString("id"),
                            o.optString("n"),
                            o.optString("e"),
                            o.optString("c"),
                            o.optString("g"),
                            o.optString("i"),
                            o.optString("r"),
                            o.optString("y"),
                            o.optString("p")
                        )
                    )
                )
            }
        } catch (e: Exception) {
            // ignore corrupted data
        }
        return out
    }

    private fun write(ctx: Context, name: String, list: List<Fav>) {
        val arr = JSONArray()
        for (f in list) {
            val o = JSONObject()
            o.put("k", f.kind.name)
            o.put("id", f.entry.id)
            o.put("n", f.entry.name)
            o.put("e", f.entry.ext)
            o.put("c", f.entry.cmd)
            o.put("g", f.entry.group)
            o.put("i", f.entry.icon)
            o.put("r", f.entry.rating)
            o.put("y", f.entry.year)
            o.put("p", f.entry.plot)
            arr.put(o)
        }
        prefs(ctx).edit().putString("$name:${sourceKey()}", arr.toString()).apply()
    }

    fun favorites(ctx: Context): List<Fav> = read(ctx, "fav")

    fun favIds(ctx: Context, kind: Kind): Set<String> =
        favorites(ctx).filter { it.kind == kind }.map { it.entry.id }.toHashSet()

    /** Returns true if the entry is now a favorite. */
    fun toggleFav(ctx: Context, kind: Kind, e: Entry): Boolean {
        val list = read(ctx, "fav")
        val idx = list.indexOfFirst { it.kind == kind && it.entry.id == e.id }
        val nowFav = idx < 0
        if (idx >= 0) list.removeAt(idx) else list.add(Fav(kind, e))
        write(ctx, "fav", list)
        return nowFav
    }

    fun recents(ctx: Context): List<Fav> = read(ctx, "recent")

    fun addRecent(ctx: Context, kind: Kind, e: Entry) {
        val list = read(ctx, "recent")
        list.removeAll { it.kind == kind && it.entry.id == e.id }
        list.add(0, Fav(kind, e))
        while (list.size > MAX_RECENT) list.removeAt(list.size - 1)
        write(ctx, "recent", list)
    }
}

object Playback {
    fun item(kind: Kind, e: Entry): PlayItem {
        val sa = Session.stalker
        val acc = Session.account
        return if (sa != null) {
            PlayItem(e.name, "", e.cmd, if (kind == Kind.LIVE) "itv" else "vod")
        } else if (acc != null) {
            PlayItem(e.name, XtreamApi.url(acc, kind, e), alt = XtreamApi.altUrl(acc, kind, e))
        } else {
            PlayItem(e.name, "")
        }
    }

    fun play(ctx: Context, kind: Kind, list: List<Entry>, index: Int) {
        if (index < 0 || index >= list.size) return
        Session.items = list.map { item(kind, it) }
        Session.index = index
        Session.isLive = kind == Kind.LIVE
        Store.addRecent(ctx, kind, list[index])
        ctx.startActivity(Intent(ctx, PlayerActivity::class.java))
    }
}
