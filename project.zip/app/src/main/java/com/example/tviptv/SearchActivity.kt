package com.example.tviptv

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class SearchActivity : AppCompatActivity() {

    private lateinit var query: EditText
    private lateinit var status: TextView
    private lateinit var adapter: TextAdapter
    private var results: List<Fav> = emptyList()
    private var job: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        setContentView(R.layout.activity_search)
        query = findViewById(R.id.query)
        status = findViewById(R.id.status)
        val rv = findViewById<RecyclerView>(R.id.results)
        adapter = TextAdapter { i -> open(i) }
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter

        findViewById<Button>(R.id.btn_search).setOnClickListener { doSearch() }
        query.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                doSearch()
                true
            } else {
                false
            }
        }
        query.requestFocus()
    }

    private fun prefix(k: Kind): String = when (k) {
        Kind.LIVE -> "📺  "
        Kind.MOVIES -> "🎬  "
        Kind.SERIES -> "🎞️  "
    }

    private fun doSearch() {
        val q = query.text.toString().trim()
        if (q.length < 2) {
            Toast.makeText(this, R.string.search_short, Toast.LENGTH_SHORT).show()
            return
        }
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(query.windowToken, 0)
        status.text = getString(R.string.searching)
        job?.cancel()
        job = lifecycleScope.launch {
            try {
                val list = search(q)
                results = list
                adapter.items = list.map { prefix(it.kind) + it.entry.name }
                status.text = if (list.isEmpty()) getString(R.string.no_items) else ""
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                status.text = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
            }
        }
    }

    private suspend fun search(q: String): List<Fav> {
        val out = mutableListOf<Fav>()
        val sa = Session.stalker
        val acc = Session.account
        val m = Session.m3u
        for (k in listOf(Kind.LIVE, Kind.MOVIES, Kind.SERIES)) {
            val found: List<Entry> = try {
                if (sa != null) {
                    if (k == Kind.SERIES) {
                        emptyList()
                    } else {
                        StalkerApi.page(sa, if (k == Kind.LIVE) "itv" else "vod", "*", 1, q).items
                    }
                } else if (acc != null) {
                    XtreamApi.entries(acc, k, "", q).take(60)
                } else if (m != null) {
                    m.search(k, q).take(60)
                } else {
                    emptyList()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                emptyList()
            }
            for (e in found) out.add(Fav(k, e))
        }
        return out
    }

    private fun open(i: Int) {
        if (i >= results.size) return
        val f = results[i]
        if (f.kind == Kind.LIVE) {
            Playback.play(this, Kind.LIVE, listOf(f.entry), 0)
        } else {
            Session.detail = f
            startActivity(Intent(this, DetailsActivity::class.java))
        }
    }
}
