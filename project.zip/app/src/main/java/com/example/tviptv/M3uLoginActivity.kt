package com.example.tviptv

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class M3uLoginActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var load: Button
    private lateinit var pickBtn: Button

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) loadFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_m3u)
        val url = findViewById<EditText>(R.id.url)
        load = findViewById(R.id.login)
        pickBtn = findViewById(R.id.btn_file)
        status = findViewById(R.id.status)

        url.setText(getSharedPreferences("m3u", MODE_PRIVATE).getString("url", ""))

        load.setOnClickListener {
            val u = url.text.toString().trim()
            if (u.isNotEmpty()) loadUrl(u)
        }
        pickBtn.setOnClickListener { pick.launch(arrayOf("*/*")) }
    }

    private fun busy(b: Boolean) {
        load.isEnabled = !b
        pickBtn.isEnabled = !b
        status.text = if (b) getString(R.string.connecting) else ""
    }

    private fun fail(e: Throwable) {
        status.text = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
    }

    private fun enter(src: M3uSource, saveUrl: String?) {
        Session.m3u = src
        Session.account = null
        Session.stalker = null
        if (saveUrl != null) {
            getSharedPreferences("m3u", MODE_PRIVATE).edit().putString("url", saveUrl).apply()
            getSharedPreferences("app", MODE_PRIVATE).edit().putString("last", "m3u").apply()
        }
        startActivity(Intent(this, HomeActivity::class.java))
    }

    private fun loadUrl(u: String) {
        busy(true)
        lifecycleScope.launch {
            try {
                val src = M3uApi.load(u)
                enter(src, u)
                status.text = ""
            } catch (e: Exception) {
                fail(e)
            } finally {
                load.isEnabled = true
                pickBtn.isEnabled = true
            }
        }
    }

    private fun loadFile(uri: Uri) {
        busy(true)
        lifecycleScope.launch {
            try {
                val src = withContext(Dispatchers.IO) {
                    val stream = contentResolver.openInputStream(uri) ?: throw IOException("تعذّر فتح الملف")
                    stream.use { M3uApi.parse("file", it) }
                }
                enter(src, null)
                status.text = ""
            } catch (e: Exception) {
                fail(e)
            } finally {
                load.isEnabled = true
                pickBtn.isEnabled = true
            }
        }
    }
}
