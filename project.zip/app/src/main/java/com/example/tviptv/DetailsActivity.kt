package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class DetailsActivity : AppCompatActivity() {

    private lateinit var kind: Kind
    private lateinit var entry: Entry
    private lateinit var btnFav: Button
    private lateinit var meta: TextView
    private lateinit var plot: TextView
    private lateinit var img: ImageView
    private var isFav = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = Session.detail
        if (d == null || !Session.hasSource()) {
            finish()
            return
        }
        kind = d.kind
        entry = d.entry
        setContentView(R.layout.activity_details)

        img = findViewById(R.id.poster)
        meta = findViewById(R.id.meta)
        plot = findViewById(R.id.plot)
        btnFav = findViewById(R.id.btn_fav)
        findViewById<TextView>(R.id.title).text = entry.name

        val play = findViewById<Button>(R.id.btn_play)
        play.setText(if (kind == Kind.SERIES) R.string.btn_episodes else R.string.btn_play)
        play.setOnClickListener { onPlay() }

        val hist = History.find(this, kind, entry.id)
        val cont = findViewById<Button>(R.id.btn_continue)
        if (kind == Kind.SERIES && hist != null && hist.epId.isNotEmpty() && Session.account != null) {
            cont.text = getString(R.string.btn_continue_ep, hist.epTitle)
            cont.visibility = View.VISIBLE
            cont.setOnClickListener { continueEpisode(hist) }
        } else if (kind == Kind.MOVIES && hist != null && hist.pos > 15000L) {
            play.setText(R.string.btn_resume)
        }

        isFav = Store.favIds(this, kind).contains(entry.id)
        updateFavButton()
        btnFav.setOnClickListener {
            isFav = Store.toggleFav(this, kind, entry)
            updateFavButton()
        }

        showMeta(entry.rating, entry.year, emptyList())
        plot.text = if (entry.plot.isNotBlank()) entry.plot else getString(R.string.no_plot)
        loadImage(entry.icon)
        play.requestFocus()

        val acc = Session.account
        if (kind == Kind.MOVIES && acc != null) {
            lifecycleScope.launch {
                try {
                    applyInfo(XtreamApi.vodInfo(acc, entry.id))
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    // details are optional
                }
            }
        }
    }

    private fun onPlay() {
        if (kind == Kind.MOVIES) {
            Playback.play(this, Kind.MOVIES, listOf(entry), 0)
        } else if (Session.account != null) {
            startActivity(Intent(this, SeriesActivity::class.java).putExtra("id", entry.id))
        } else {
            Toast.makeText(this, R.string.coming_soon, Toast.LENGTH_SHORT).show()
        }
    }

    private fun continueEpisode(h: Hist) {
        val acc = Session.account ?: return
        val ext = h.epExt.ifBlank { "mp4" }
        val ep = Episode(h.epId, h.epTitle, ext, 1, 1)
        History.touch(this, Kind.SERIES, entry, h.epId, ext, h.epTitle)
        Session.items = listOf(
            PlayItem(
                h.epTitle, XtreamApi.episodeUrl(acc, ep),
                histKind = Kind.SERIES.name, histId = entry.id, histEp = h.epId, histExt = ext
            )
        )
        Session.index = 0
        Session.isLive = false
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    private fun updateFavButton() {
        btnFav.setText(if (isFav) R.string.btn_fav_remove else R.string.btn_fav_add)
    }

    private fun loadImage(url: String) {
        if (!url.startsWith("http")) return
        Glide.with(this)
            .load(url)
            .override(500, 750)
            .centerCrop()
            .placeholder(R.drawable.poster_placeholder)
            .error(R.drawable.poster_placeholder)
            .into(img)
    }

    private fun showMeta(rating: String, year: String, extra: List<String>) {
        val parts = mutableListOf<String>()
        if (rating.isNotBlank() && rating != "0") parts.add("★ $rating")
        if (year.isNotBlank()) parts.add(year)
        parts.addAll(extra)
        meta.text = parts.joinToString("   ·   ")
    }

    private fun applyInfo(info: VodInfo) {
        val r = if (info.rating.isNotBlank()) info.rating else entry.rating
        val y = if (info.year.isNotBlank()) info.year else entry.year
        showMeta(r, y, listOf(info.genre, info.duration).filter { it.isNotBlank() })
        val sb = StringBuilder()
        sb.append(if (info.plot.isNotBlank()) info.plot else getString(R.string.no_plot))
        if (info.director.isNotBlank()) sb.append("\n\n").append(getString(R.string.director, info.director))
        if (info.cast.isNotBlank()) sb.append("\n").append(getString(R.string.cast, info.cast.take(200)))
        plot.text = sb.toString()
        if (info.image.startsWith("http")) loadImage(info.image)
    }
}
