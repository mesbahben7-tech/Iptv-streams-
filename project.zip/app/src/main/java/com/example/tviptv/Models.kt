package com.example.tviptv

data class Account(val host: String, val user: String, val pass: String) {
    companion object {
        fun from(host: String, user: String, pass: String): Account {
            var h = host.trim().trimEnd('/')
            if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://$h"
            return Account(h, user.trim(), pass.trim())
        }
    }
}

enum class Kind(val catAction: String, val listAction: String, val idKey: String) {
    LIVE("get_live_categories", "get_live_streams", "stream_id"),
    MOVIES("get_vod_categories", "get_vod_streams", "stream_id"),
    SERIES("get_series_categories", "get_series", "series_id")
}

data class Category(val id: String, val name: String)
data class Entry(
    val id: String,
    val name: String,
    val ext: String,
    val cmd: String = "",
    val group: String = ""
)
data class Episode(val id: String, val title: String, val ext: String, val season: Int, val num: Int)
data class PlayItem(
    val title: String,
    val url: String,
    val cmd: String = "",
    val stalkerType: String = "itv",
    val alt: String = ""
)

object Session {
    var account: Account? = null
    var stalker: StalkerAccount? = null
    var items: List<PlayItem> = emptyList()
    var index: Int = 0
    var isLive: Boolean = true

    fun hasSource(): Boolean = account != null || stalker != null
}
