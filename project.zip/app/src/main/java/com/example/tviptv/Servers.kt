package com.example.tviptv

import android.content.Context
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Random

data class Server(
    val id: String,
    val name: String,
    val type: String,
    val url: String,
    val user: String = "",
    val pass: String = "",
    val mac: String = "",
    val enabled: Boolean = true,
    val status: Int = 0
) {
    fun typeLabel(): String = when (type) {
        "xtream" -> "Xtream Codes"
        "stalker" -> "Stalker"
        else -> "M3U"
    }
}

object ServerStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("servers", Context.MODE_PRIVATE)

    fun hostOf(url: String): String {
        val u = url.trim()
        val withScheme = if (u.startsWith("http://") || u.startsWith("https://")) u else "http://$u"
        return withScheme.toHttpUrlOrNull()?.host ?: u.take(30)
    }

    fun defaultName(type: String, url: String): String = hostOf(url).ifBlank { "Server" }

    fun newId(): String = System.currentTimeMillis().toString(36) + Random().nextInt(1000)

    private fun migrate(ctx: Context): List<Server> {
        val out = mutableListOf<Server>()
        val a = ctx.getSharedPreferences("acc", Context.MODE_PRIVATE)
        val host = a.getString("host", "") ?: ""
        if (host.isNotEmpty()) {
            out.add(
                Server(
                    "legacy_x", defaultName("xtream", host), "xtream", host,
                    a.getString("user", "") ?: "", a.getString("pass", "") ?: ""
                )
            )
        }
        val s = ctx.getSharedPreferences("stalker", Context.MODE_PRIVATE)
        val portal = s.getString("portal", "") ?: ""
        val mac = s.getString("mac", "") ?: ""
        if (portal.isNotEmpty() && mac.isNotEmpty()) {
            out.add(Server("legacy_s", defaultName("stalker", portal), "stalker", portal, mac = mac))
        }
        val m = ctx.getSharedPreferences("m3u", Context.MODE_PRIVATE)
        val u = m.getString("url", "") ?: ""
        if (u.isNotEmpty()) {
            out.add(Server("legacy_m", defaultName("m3u", u), "m3u", u))
        }
        return out
    }

    fun list(ctx: Context): List<Server> {
        val raw = prefs(ctx).getString("list", null)
        if (raw == null) {
            val migrated = migrate(ctx)
            if (migrated.isNotEmpty()) write(ctx, migrated)
            return migrated
        }
        val out = mutableListOf<Server>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Server(
                        o.optString("id"),
                        o.optString("name"),
                        o.optString("type"),
                        o.optString("url"),
                        o.optString("user"),
                        o.optString("pass"),
                        o.optString("mac"),
                        o.optBoolean("enabled", true),
                        o.optInt("status", 0)
                    )
                )
            }
        } catch (e: Exception) {
            // ignore corrupted data
        }
        return out
    }

    private fun write(ctx: Context, list: List<Server>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject()
            o.put("id", s.id)
            o.put("name", s.name)
            o.put("type", s.type)
            o.put("url", s.url)
            o.put("user", s.user)
            o.put("pass", s.pass)
            o.put("mac", s.mac)
            o.put("enabled", s.enabled)
            o.put("status", s.status)
            arr.put(o)
        }
        prefs(ctx).edit().putString("list", arr.toString()).apply()
    }

    fun get(ctx: Context, id: String): Server? = list(ctx).firstOrNull { it.id == id }

    fun upsert(ctx: Context, s: Server) {
        val l = list(ctx).toMutableList()
        val idx = l.indexOfFirst { it.id == s.id }
        if (idx >= 0) l[idx] = s else l.add(s)
        write(ctx, l)
    }

    fun delete(ctx: Context, id: String) {
        write(ctx, list(ctx).filter { it.id != id })
    }

    fun setStatus(ctx: Context, id: String, ok: Boolean) {
        val l = list(ctx).toMutableList()
        val idx = l.indexOfFirst { it.id == id }
        if (idx < 0) return
        l[idx] = l[idx].copy(status = if (ok) 1 else 2)
        write(ctx, l)
    }

    fun setLast(ctx: Context, id: String) {
        prefs(ctx).edit().putString("last_id", id).apply()
    }
}

object Connector {
    suspend fun connect(ctx: Context, s: Server) {
        if (!s.enabled) throw IOException(ctx.getString(R.string.server_disabled))
        when (s.type) {
            "xtream" -> {
                val acc = Account.from(s.url, s.user, s.pass)
                XtreamApi.login(acc)
                Session.account = acc
                Session.stalker = null
                Session.m3u = null
            }
            "stalker" -> {
                val mac = StalkerApi.normalizeMac(s.mac) ?: throw IOException(ctx.getString(R.string.bad_mac))
                val sa = StalkerAccount(s.url, mac)
                StalkerApi.connect(sa)
                Session.stalker = sa
                Session.account = null
                Session.m3u = null
            }
            else -> {
                val src = M3uApi.load(s.url)
                Session.m3u = src
                Session.account = null
                Session.stalker = null
            }
        }
        Session.serverName = s.name
        ServerStore.setStatus(ctx, s.id, true)
        ServerStore.setLast(ctx, s.id)
    }
}
