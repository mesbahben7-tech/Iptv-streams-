package com.example.tviptv

import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Small player used for the live-channel preview pane. */
class PreviewPlayer(
    private val activity: AppCompatActivity,
    private val view: PlayerView,
    private val maxW: Int = 854,
    private val maxH: Int = 480,
    private val onFail: () -> Unit
) {
    private var player: ExoPlayer? = null
    private var job: Job? = null
    private var current: PlayItem? = null
    private var altTried = false
    private var hlsTried = false
    private var volume = 1f

    fun start() {
        if (player != null) return
        val ua = if (Session.stalker != null) StalkerApi.UA else "IPTVPlayer/1.0"
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(15000)
            .setReadTimeoutMs(15000)
        val p = ExoPlayer.Builder(activity)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(maxW, maxH)
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                handleError()
            }
        })
        p.volume = volume
        view.player = p
        player = p
    }

    fun setVolume(v: Float) {
        volume = v
        player?.volume = v
    }

    fun stop() {
        job?.cancel()
        view.player = null
        player?.release()
        player = null
    }

    fun play(item: PlayItem) {
        current = item
        altTried = false
        hlsTried = false
        begin(false)
    }

    private fun begin(forceHls: Boolean) {
        val cur = current ?: return
        val sa = Session.stalker
        job?.cancel()
        if (sa != null && cur.cmd.isNotEmpty()) {
            job = activity.lifecycleScope.launch {
                try {
                    val u = StalkerApi.createLink(sa, cur.stalkerType, cur.cmd)
                    startUrl(u, forceHls)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    onFail()
                }
            }
        } else {
            startUrl(cur.url, false)
        }
    }

    private fun startUrl(url: String, forceHls: Boolean) {
        val mediaItem = if (forceHls) {
            MediaItem.Builder().setUri(url).setMimeType(MimeTypes.APPLICATION_M3U8).build()
        } else {
            MediaItem.fromUri(url)
        }
        player?.apply {
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
        }
    }

    private fun handleError() {
        val cur = current ?: return
        if (cur.alt.isNotEmpty() && !altTried) {
            altTried = true
            startUrl(cur.alt, false)
            return
        }
        if (Session.stalker != null && cur.cmd.isNotEmpty() && !hlsTried) {
            hlsTried = true
            begin(true)
            return
        }
        onFail()
    }
}
