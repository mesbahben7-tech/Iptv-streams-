package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class BrowseActivity : AppCompatActivity() {

    private lateinit var kind: Kind
    private lateinit var status: TextView
    private lateinit var rvCats: RecyclerView
    private lateinit var rvCh: RecyclerView
    private lateinit var catAdapter: TextAdapter
    private lateinit var chAdapter: TextAdapter
    private var cats: List<Category> = emptyList()
    private var entries: List<Entry> = emptyList()
    private var loadJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        kind = Kind.valueOf(intent.getStringExtra("kind") ?: Kind.LIVE.name)
        setContentView(R.layout.activity_channels)
        status = findViewById(R.id.status)
        rvCats = findViewById(R.id.categories)
        rvCh = findViewById(R.id.channels)

        catAdapter = TextAdapter { i -> loadEntries(cats[i]) }
        chAdapter = TextAdapter { i -> onEntryClick(i) }
        rvCats.layoutManager = LinearLayoutManager(this)
        rvCh.layoutManager = LinearLayoutManager(this)
        rvCats.adapter = catAdapter
        rvCh.adapter = chAdapter

        showStatus(getString(R.string.connecting))
        lifecycleScope.launch {
            try {
                val list = fetchCategories()
                cats = listOf(Category("", getString(R.string.all))) + list
                catAdapter.items = cats.map { it.name }
                status.visibility = View.GONE
                rvCats.post { rvCats.requestFocus() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showStatus(getString(R.string.load_error, e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private suspend fun fetchCategories(): List<Category> {
        val sa = Session.stalker
        val acc = Session.account
        return if (sa != null) {
            StalkerApi.categories(sa, kind)
        } else if (acc != null) {
            XtreamApi.categories(acc, kind)
        } else {
            emptyList()
        }
    }

    private fun playItem(e: Entry): PlayItem {
        val sa = Session.stalker
        val acc = Session.account
        return if (sa != null) {
            PlayItem(e.name, "", e.cmd, if (kind == Kind.LIVE) "itv" else "vod")
        } else {
            if (acc != null) {
                PlayItem(e.name, XtreamApi.url(acc, kind, e), alt = XtreamApi.altUrl(acc, kind, e))
            } else {
                PlayItem(e.name, "")
            }
        }
    }

    private fun onEntryClick(i: Int) {
        if (i >= entries.size) return
        val e = entries[i]
        when (kind) {
            Kind.SERIES -> {
                if (Session.account != null) {
                    startActivity(Intent(this, SeriesActivity::class.java).putExtra("id", e.id))
                } else {
                    Toast.makeText(this, R.string.coming_soon, Toast.LENGTH_SHORT).show()
                }
            }
            Kind.MOVIES -> {
                Session.items = listOf(playItem(e))
                Session.index = 0
                Session.isLive = false
                startActivity(Intent(this, PlayerActivity::class.java))
            }
            Kind.LIVE -> {
                Session.items = entries.map { playItem(it) }
                Session.index = i
                Session.isLive = true
                startActivity(Intent(this, PlayerActivity::class.java))
            }
        }
    }

    private fun showStatus(msg: String) {
        status.text = msg
        status.visibility = View.VISIBLE
    }

    private fun showEntries() {
        chAdapter.items = entries.map { it.name }
        rvCh.scrollToPosition(0)
        if (entries.isEmpty()) {
            showStatus(getString(R.string.no_items))
        } else {
            status.visibility = View.GONE
            rvCh.post { rvCh.requestFocus() }
        }
    }

    private fun loadEntries(cat: Category) {
        loadJob?.cancel()
        showStatus(getString(R.string.connecting))
        loadJob = lifecycleScope.launch {
            try {
                val sa = Session.stalker
                val acc = Session.account
                if (sa != null) {
                    loadStalker(sa, cat)
                } else if (acc != null) {
                    entries = XtreamApi.entries(acc, kind, cat.id)
                    showEntries()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showStatus(getString(R.string.load_error, e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private suspend fun loadStalker(sa: StalkerAccount, cat: Category) {
        val type = if (kind == Kind.LIVE) "itv" else "vod"
        val catId = if (cat.id.isEmpty()) "*" else cat.id
        entries = emptyList()
        chAdapter.items = emptyList()
        val collected = mutableListOf<Entry>()
        var p = 1
        while (p <= 100) {
            val pg = StalkerApi.page(sa, type, catId, p)
            if (pg.items.isEmpty()) break
            collected.addAll(pg.items)
            chAdapter.append(pg.items.map { it.name })
            entries = collected.toList()
            if (p == 1) {
                status.visibility = View.GONE
                rvCh.post { rvCh.requestFocus() }
            }
            if (pg.total <= 0 || collected.size >= pg.total) break
            p++
        }
        if (collected.isEmpty() && kind == Kind.LIVE) {
            val all = StalkerApi.allChannels(sa)
            entries = if (cat.id.isEmpty()) all else all.filter { it.group == cat.id }
            showEntries()
            return
        }
        if (collected.isEmpty()) showStatus(getString(R.string.no_items))
    }
}
