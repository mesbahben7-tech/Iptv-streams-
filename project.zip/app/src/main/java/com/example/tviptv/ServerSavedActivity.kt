package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class ServerSavedActivity : AppCompatActivity() {

    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val server = ServerStore.get(this, intent.getStringExtra("id") ?: "")
        if (server == null) {
            finish()
            return
        }
        setContentView(R.layout.activity_server_saved)
        findViewById<TextView>(R.id.saved_name).text = server.name
        findViewById<TextView>(R.id.saved_type).text = server.typeLabel()
        val status = findViewById<TextView>(R.id.status)
        val open = findViewById<Button>(R.id.btn_open)

        open.setOnClickListener {
            if (busy) return@setOnClickListener
            busy = true
            status.text = getString(R.string.connecting)
            lifecycleScope.launch {
                try {
                    Connector.connect(this@ServerSavedActivity, server)
                    status.text = ""
                    startActivity(Intent(this@ServerSavedActivity, HomeActivity::class.java))
                    finish()
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    ServerStore.setStatus(this@ServerSavedActivity, server.id, false)
                    status.text = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
                } finally {
                    busy = false
                }
            }
        }
        findViewById<Button>(R.id.btn_back).setOnClickListener {
            val i = Intent(this, StartActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            finish()
        }
        open.requestFocus()
    }
}
