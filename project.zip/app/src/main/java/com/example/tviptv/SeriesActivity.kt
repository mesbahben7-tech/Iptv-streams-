package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class SeriesActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var rvSeasons: RecyclerView
    private lateinit var rvEps: RecyclerView
    private lateinit var seasonAdapter: TextAdapter
    private lateinit var epAdapter: TextAdapter
    private var episodes: List<Episode> = emptyList()
    private var seasons: List<Int> = emptyList()
    private var current: List<Episode> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val acc = Session.account
        val id = intent.getStringExtra("id")
        if (acc == null || id == null) {
            finish()
            return
        }
        setContentView(R.layout.activity_channels)
        status = findViewById(R.id.status)
        rvSeasons = findViewById(R.id.categories)
        rvEps = findViewById(R.id.channels)

        seasonAdapter = TextAdapter { i -> showSeason(i) }
        epAdapter = TextAdapter { i ->
            Session.items = current.map { PlayItem(label(it), XtreamApi.episodeUrl(acc, it)) }
            Session.index = i
            Session.isLive = false
            startActivity(Intent(this, PlayerActivity::class.java))
        }
        rvSeasons.layoutManager = LinearLayoutManager(this)
        rvEps.layoutManager = LinearLayoutManager(this)
        rvSeasons.adapter = seasonAdapter
        rvEps.adapter = epAdapter

        showStatus(getString(R.string.connecting))
        lifecycleScope.launch {
            try {
                episodes = XtreamApi.episodes(acc, id)
                seasons = episodes.map { it.season }.distinct().sorted()
                seasonAdapter.items = seasons.map { getString(R.string.season, it) }
                if (seasons.isEmpty()) {
                    showStatus(getString(R.string.no_items))
                } else {
                    status.visibility = View.GONE
                    showSeason(0)
                    rvSeasons.post { rvSeasons.requestFocus() }
                }
            } catch (e: Exception) {
                showStatus(getString(R.string.load_error, e.message ?: ""))
            }
        }
    }

    private fun label(e: Episode): String {
        val t = e.title.ifBlank { "S${e.season}E${e.num}" }
        return "${e.num}. $t"
    }

    private fun showSeason(i: Int) {
        current = episodes.filter { it.season == seasons[i] }
        epAdapter.items = current.map { label(it) }
        rvEps.scrollToPosition(0)
    }

    private fun showStatus(msg: String) {
        status.text = msg
        status.visibility = View.VISIBLE
    }
}
