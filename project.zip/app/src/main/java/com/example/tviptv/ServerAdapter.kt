package com.example.tviptv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ServerAdapter(
    private val onOpen: (Server) -> Unit,
    private val onEdit: (Server) -> Unit
) : RecyclerView.Adapter<ServerAdapter.VH>() {

    private var data: List<Server> = emptyList()

    var items: List<Server>
        get() = data
        set(value) {
            data = value
            notifyDataSetChanged()
        }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: TextView = view.findViewById(R.id.icon)
        val name: TextView = view.findViewById(R.id.name)
        val type: TextView = view.findViewById(R.id.type)
        val status: TextView = view.findViewById(R.id.status)
        val edit: TextView = view.findViewById(R.id.edit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_server, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val s = data[position]
        val ctx = holder.itemView.context
        holder.icon.text = when (s.type) {
            "xtream" -> "☁️"
            "stalker" -> "🖥️"
            else -> "📄"
        }
        holder.name.text = s.name
        holder.type.text = s.typeLabel()
        val label: String
        val color: Int
        if (!s.enabled) {
            label = ctx.getString(R.string.status_off)
            color = 0xFF9E9E9E.toInt()
        } else if (s.status == 1) {
            label = ctx.getString(R.string.status_ok)
            color = 0xFF4CAF50.toInt()
        } else if (s.status == 2) {
            label = ctx.getString(R.string.status_fail)
            color = 0xFFEF5350.toInt()
        } else {
            label = ctx.getString(R.string.status_unknown)
            color = 0xFFB0BEC5.toInt()
        }
        holder.status.text = "●  $label"
        holder.status.setTextColor(color)
        holder.itemView.alpha = if (s.enabled) 1f else 0.6f
        holder.itemView.setOnClickListener { onOpen(s) }
        holder.edit.setOnClickListener { onEdit(s) }
        holder.itemView.setOnLongClickListener {
            onEdit(s)
            true
        }
    }

    override fun getItemCount() = data.size
}
