package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class AddServerActivity : AppCompatActivity() {

    private fun openForm(type: String) {
        startActivity(Intent(this, ServerFormActivity::class.java).putExtra("type", type))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_server)
        val m3u = findViewById<View>(R.id.card_m3u)
        m3u.setOnClickListener { openForm("m3u") }
        findViewById<View>(R.id.card_xtream).setOnClickListener { openForm("xtream") }
        findViewById<View>(R.id.card_stalker).setOnClickListener { openForm("stalker") }
        m3u.requestFocus()
    }
}
