package com.example.tviptv

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.HttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var title: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val hideTitle = Runnable { title.visibility = View.GONE }
    private var resumeMs = 0L
    private var resolveJob: Job? = null
    private var currentUrl = ""
    private var altTried = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (!Session.hasSource() || Session.items.isEmpty()) {
            finish()
            return
        }
        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.player)
        title = findViewById(R.id.title)
    }

    override fun onStart() {
        super.onStart()
        if (!Session.hasSource() || Session.items.isEmpty()) return
        playerView.useController = !Session.isLive
        playerView.setShowSubtitleButton(true)

        val ua = if (Session.stalker != null) StalkerApi.UA else "IPTVPlayer/1.0"
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(ua)
            .setAllowCrossProtocolRedirects(true)
        val p = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(http))
            .build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage("ar")
            .build()
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                val item = Session.items.getOrNull(Session.index)
                if (item != null && item.alt.isNotEmpty() && !altTried) {
                    altTried = true
                    startPlayback(item.alt, 0L)
                } else {
                    val code = (error.cause as? HttpDataSource.InvalidResponseCodeException)?.responseCode
                    val detail = if (code != null) "HTTP $code" else error.errorCodeName
                    val msg = getString(R.string.play_error) + " (" + detail + ")"
                    Toast.makeText(this@PlayerActivity, msg, Toast.LENGTH_LONG).show()
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED && !Session.isLive &&
                    Session.index < Session.items.size - 1
                ) {
                    Session.index++
                    play()
                }
            }
        })
        playerView.player = p
        player = p
        playerView.requestFocus()
        play()
    }

    override fun onStop() {
        super.onStop()
        resolveJob?.cancel()
        val p = player
        resumeMs = if (Session.isLive || p == null) 0L else p.currentPosition
        playerView.player = null
        p?.release()
        player = null
    }

    private fun play() {
        val item = Session.items[Session.index]
        altTried = false
        showTitle(item.title)
        val start = resumeMs
        resumeMs = 0L
        resolveJob?.cancel()
        val sa = Session.stalker
        if (item.cmd.isNotEmpty() && sa != null) {
            resolveJob = lifecycleScope.launch {
                try {
                    val u = StalkerApi.createLink(sa, item.stalkerType, item.cmd)
                    startPlayback(u, start)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    Toast.makeText(this@PlayerActivity, R.string.play_error, Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            startPlayback(item.url, start)
        }
    }

    private fun startPlayback(url: String, start: Long) {
        currentUrl = url
        player?.apply {
            setMediaItem(MediaItem.fromUri(url), start)
            prepare()
            playWhenReady = true
        }
    }

    private fun showTitle(text: String) {
        title.text = text
        title.visibility = View.VISIBLE
        handler.removeCallbacks(hideTitle)
        handler.postDelayed(hideTitle, 3000)
    }

    private fun zap(step: Int) {
        val n = Session.items.size
        Session.index = ((Session.index + step) % n + n) % n
        play()
    }

    private fun askSubtitle() {
        val input = EditText(this)
        input.hint = "https://example.com/sub.srt"
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        input.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle(R.string.sub_title)
            .setView(input)
            .setPositiveButton(R.string.sub_add) { _, _ ->
                val u = input.text.toString().trim()
                if (u.isNotEmpty()) addExternalSubtitle(u)
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun addExternalSubtitle(url: String) {
        val p = player ?: return
        val cur = p.currentMediaItem ?: return
        val pos = p.currentPosition
        val mime = if (url.lowercase().contains(".vtt")) MimeTypes.TEXT_VTT else MimeTypes.APPLICATION_SUBRIP
        val sub = MediaItem.SubtitleConfiguration.Builder(Uri.parse(url))
            .setMimeType(mime)
            .setLanguage("ar")
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val item = cur.buildUpon().setSubtitleConfigurations(listOf(sub)).build()
        p.setMediaItem(item, pos)
        p.prepare()
        p.playWhenReady = true
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (Session.isLive) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_CHANNEL_UP -> { zap(1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> { zap(-1); return true }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                        showTitle(Session.items[Session.index].title)
                        return true
                    }
                }
            } else {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_INFO -> { askSubtitle(); return true }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }
}
