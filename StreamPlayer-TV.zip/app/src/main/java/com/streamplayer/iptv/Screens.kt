package com.streamplayer.iptv

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage

// ───────── مكوّنات مشتركة ─────────
@Composable
fun ScreenFrame(title: String, subtitle: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))).padding(18.dp)) {
        TopBar(onBack)
        Column(
            Modifier.fillMaxSize().clip(RoundedCornerShape(18.dp)).background(Color(0xAA061A35)).border(1.dp, Edge, RoundedCornerShape(18.dp))
                .verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color(0xFF8FBDE8), fontSize = 12.sp)
            content()
        }
    }
}

@Composable
fun OptionRow(label: String, value: String? = null, selected: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (selected) Color(0xFF0B3566) else Color(0xFF071F3D))
            .border(if (selected) 2.dp else 1.dp, if (selected) Accent else Color(0xFF124574), RoundedCornerShape(12.dp))
            .focusHighlight(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = Color.White, fontSize = 15.sp)
        if (value != null) Text(value, color = Color(0xFF8EDBFF), fontSize = 14.sp)
        else Text(if (selected) "◉" else "○", color = Accent, fontSize = 18.sp)
    }
}

@Composable
fun ActionBtn(icon: String, label: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(10.dp)).focusHighlight(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, color = Accent, fontSize = 20.sp)
        Text(label, color = Color.White, fontSize = 10.sp, maxLines = 1)
    }
}

// ───────── إضافة مصدر البث (Xtream / M3U / Stalker) ─────────
@Composable
fun Setup(city0: String, country0: String, onBack: () -> Unit, onDone: (Source, String, String) -> Unit) {
    var step by remember { mutableStateOf(0) }
    var t by remember { mutableStateOf("xtream") }
    var a by remember { mutableStateOf("") }; var b by remember { mutableStateOf("") }; var c by remember { mutableStateOf("") }
    BackHandler(step == 1) { step = 0 }
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))).verticalScroll(rememberScrollState()).padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("إضافة مصدر البث", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (step == 0) {
            Text("اختر طريقة إضافة السيرفر الخاص بك", color = Color(0xFF8FBDE8), fontSize = 13.sp)
            listOf(Triple("xtream", "Xtream Codes", "إضافة عبر Xtream"), Triple("m3u", "M3U", "إضافة عبر رابط M3U"), Triple("stalker", "Stalker", "إضافة عبر Stalker Portal")).forEach { (k, n, d) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF071F3D))
                        .border(if (t == k) 2.dp else 1.dp, if (t == k) Accent else Edge, RoundedCornerShape(16.dp))
                        .focusHighlight(RoundedCornerShape(16.dp)).clickable { t = k }.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(when (k) { "xtream" -> "≋"; "m3u" -> "▤"; else -> "◉" }, color = Accent, fontSize = 34.sp)
                    Column { Text(n, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(d, color = Color(0xFF9DC5EF), fontSize = 13.sp) }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f).focusHighlight(RoundedCornerShape(20.dp)), border = BorderStroke(1.dp, Accent)) { Text("رجوع", color = Color.White) }
                Button(onClick = { step = 1 }, modifier = Modifier.weight(2f).focusHighlight(RoundedCornerShape(20.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF08AEEF))) { Text("متابعة") }
            }
        } else {
            Text(when (t) { "xtream" -> "Xtream Codes"; "m3u" -> "رابط M3U"; else -> "Stalker Portal" }, color = Accent, fontSize = 15.sp)
            val l = when (t) { "m3u" -> "رابط M3U"; "xtream" -> "السيرفر http://host:port"; else -> "رابط البوابة http://host/c/" }
            OutlinedTextField(a, { a = it }, label = { Text(l) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            if (t == "xtream") {
                OutlinedTextField(b, { b = it }, label = { Text("المستخدم") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(c, { c = it }, label = { Text("كلمة المرور") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            if (t == "stalker") OutlinedTextField(b, { b = it }, label = { Text("MAC 00:1A:79:XX:XX:XX") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { step = 0 }, modifier = Modifier.weight(1f).focusHighlight(RoundedCornerShape(20.dp)), border = BorderStroke(1.dp, Accent)) { Text("رجوع", color = Color.White) }
                Button(onClick = { if (a.isNotBlank()) onDone(Source(t, a.trim(), b.trim(), c.trim()), city0, country0) }, modifier = Modifier.weight(2f).focusHighlight(RoundedCornerShape(20.dp)),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF08AEEF))) { Text("حفظ وتحميل") }
            }
        }
    }
}

// ───────── المشغّل: معلومات القناة + أدوات التحكم ─────────
@Composable
fun PlayerScreen(
    url: String, ch: Channel?, epg: List<String>, pr: SharedPreferences,
    onBack: () -> Unit, onPrev: () -> Unit, onNext: () -> Unit, nextName: String?
) {
    val ctx = LocalContext.current
    val cfg = LocalConfiguration.current
    val p = remember(url) { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(url)); prepare(); playWhenReady = true } }
    var panel by remember { mutableStateOf<String?>(null) }
    var isPlaying by remember { mutableStateOf(true) }
    var volume by remember { mutableStateOf(pr.getFloat("vol", 0.75f)) }
    var fav by remember(ch) { mutableStateOf(ch != null && Favs.has(pr, ch)) }
    var sub by remember { mutableStateOf(SubPrefs.load(pr)) }
    val tv = LocalIsTv.current
    var overlay by remember { mutableStateOf(true) }      // طبقة التحكم (تلفاز): تظهر عند OK وتختفي تلقائياً
    var tick by remember { mutableStateOf(0) }            // أي ضغطة زر تعيد مؤقّت الإخفاء
    var volToast by remember { mutableStateOf<String?>(null) }
    val playFocus = remember { FocusRequester() }

    DisposableEffect(p) {
        val l = object : androidx.media3.common.Player.Listener { override fun onIsPlayingChanged(b: Boolean) { isPlaying = b } }
        p.addListener(l)
        onDispose { p.removeListener(l); p.release() }
    }
    LaunchedEffect(p, volume) { p.volume = volume }
    LaunchedEffect(p, sub) {
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage(sub.lang).setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !sub.enabled).build()
    }
    BackHandler(panel != null) { panel = null }
    BackHandler(tv && overlay && panel == null) { overlay = false }
    LaunchedEffect(tv, overlay, tick, panel) { if (tv && overlay && panel == null) { kotlinx.coroutines.delay(6000); overlay = false } }
    LaunchedEffect(volToast) { if (volToast != null) { kotlinx.coroutines.delay(1500); volToast = null } }

    val video: @Composable (Modifier) -> Unit = { m ->
        Box(m.background(Color.Black)) {
            AndroidView(factory = { PlayerView(it).apply { useController = false } }, update = { v ->
                v.player = p
                v.subtitleView?.apply {
                    setFractionalTextSize(when (sub.size) { 0 -> 0.04f; 2 -> 0.07f; else -> 0.053f })
                    setStyle(CaptionStyleCompat(
                        if (sub.color == 1) android.graphics.Color.YELLOW else android.graphics.Color.WHITE,
                        if (sub.bg == 1) 0xAA000000.toInt() else android.graphics.Color.TRANSPARENT,
                        android.graphics.Color.TRANSPARENT, CaptionStyleCompat.EDGE_TYPE_OUTLINE, android.graphics.Color.BLACK, null))
                    setBottomPaddingFraction(if (sub.top) 0.75f else 0.08f)
                }
            }, modifier = Modifier.fillMaxSize())
            if (!tv) Text("‹", color = Color.White, fontSize = 32.sp, modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
                .clip(RoundedCornerShape(50)).background(Color(0x88000000)).clickable { onBack() }.padding(horizontal = 14.dp))
        }
    }

    val info: @Composable ColumnScope.() -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF0D2D53)), contentAlignment = Alignment.Center) {
                if (!ch?.logo.isNullOrBlank()) AsyncImage(ch?.logo, null, Modifier.fillMaxSize().padding(3.dp), contentScale = ContentScale.Fit)
                else Text((ch?.name ?: "▣").take(1).uppercase(), color = Accent, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.weight(1f)) {
                Text(ch?.name ?: "", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(epg.getOrNull(0) ?: "بث مباشر", color = Accent, fontSize = 12.sp, maxLines = 1)
                if (epg.size > 1) Text("التالي: ${epg[1]}", color = Color(0xFF9BB8DA), fontSize = 11.sp, maxLines = 1)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(Color(0xFFFF3B30)))
                Text("Live", color = Color.White, fontSize = 12.sp)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FocusIcon("⏮", Color.White, 24.sp) { onPrev() }
            FocusIcon(if (isPlaying) "⏸" else "▶", Accent, 28.sp, Modifier.focusRequester(playFocus)) { if (isPlaying) p.pause() else p.play() }
            FocusIcon("⏭", Color.White, 24.sp) { onNext() }
            Text("🔈", fontSize = 18.sp)
            Slider(volume, { volume = it; pr.edit().putFloat("vol", it).apply() }, Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
            Text("${(volume * 100).toInt()}%", color = Color(0xFF9BB8DA), fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            ActionBtn("◫", "DLNA") { panel = "cast" }
            ActionBtn("🔊", "الصوت الخارجي") { panel = "audio" }
            ActionBtn("CC", "الترجمة") { panel = "sub" }
            ActionBtn("ⓘ", "المعلومات") { panel = "info" }
            ActionBtn(if (fav) "★" else "☆", "المفضلة") { ch?.let { Favs.toggle(pr, it); fav = Favs.has(pr, it) } }
        }
        if (nextName != null) Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B2347)).focusHighlight(RoundedCornerShape(10.dp)).clickable { onNext() }.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("القناة التالية", color = Color(0xFF9BB8DA), fontSize = 12.sp)
            Text(nextName, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
            Text("›", color = Accent, fontSize = 22.sp)
        }
    }

    val short = cfg.screenHeightDp < 480 && cfg.screenWidthDp > cfg.screenHeightDp
    val rootFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { rootFocus.requestFocus() } }
    // تلفاز: عند ظهور الطبقة يذهب التركيز إلى زر التشغيل، وعند إخفائها يعود إلى الجذر لاستقبال أزرار الريموت
    LaunchedEffect(tv, overlay, panel) {
        if (tv && panel == null) {
            kotlinx.coroutines.delay(80)
            runCatching { if (overlay) playFocus.requestFocus() else rootFocus.requestFocus() }
        }
    }
    fun setVol(v: Float) { volume = v.coerceIn(0f, 1f); pr.edit().putFloat("vol", volume).apply(); volToast = "🔈 ${(volume * 100).toInt()}%" }
    // مفاتيح الريموت: القناة التالية/السابقة، تشغيل/إيقاف، وعلى التلفاز: أعلى/أسفل = قناة، يمين/يسار = صوت، OK = إظهار التحكم
    Box(Modifier.fillMaxSize().background(Color.Black).onKeyEvent { e ->
        if (e.type != KeyEventType.KeyDown) false else {
            tick++
            when (e.key) {
                Key.ChannelUp, Key.MediaNext -> { onNext(); true }
                Key.ChannelDown, Key.MediaPrevious -> { onPrev(); true }
                Key.MediaPlayPause -> { if (isPlaying) p.pause() else p.play(); true }
                else -> if (tv && !overlay && panel == null) when (e.key) {
                    Key.DirectionUp -> { onNext(); true }
                    Key.DirectionDown -> { onPrev(); true }
                    Key.DirectionLeft -> { setVol(volume - 0.05f); true }
                    Key.DirectionRight -> { setVol(volume + 0.05f); true }
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter, Key.Menu -> { overlay = true; true }
                    else -> false
                } else false
            }
        }
    }.focusRequester(rootFocus).focusable()) {
        if (tv) {
            video(Modifier.fillMaxSize())
            if (overlay) Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE020B1B))))
                .padding(horizontal = 56.dp, vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = info)
            volToast?.let { t ->
                Text(t, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopCenter).padding(28.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xCC000000)).padding(horizontal = 18.dp, vertical = 8.dp))
            }
        } else if (short) Row(Modifier.fillMaxSize()) {
            video(Modifier.weight(1.6f).fillMaxHeight())
            Column(Modifier.weight(1f).fillMaxHeight().background(Color(0xFF071A36)).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = info)
        } else Column(Modifier.fillMaxSize()) {
            video(Modifier.fillMaxWidth().weight(1f))
            Column(Modifier.fillMaxWidth().background(Color(0xFF071A36)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = info)
        }
        if (panel != null) Box(Modifier.fillMaxSize().background(Color(0xFF020B1B))) {
            when (panel) {
                "sub" -> SubtitleSettings(sub, { sub = it; SubPrefs.save(pr, it) }) { panel = null }
                "audio" -> AudioOutputSettings(p, volume, { volume = it; pr.edit().putFloat("vol", it).apply() }) { panel = null }
                "cast" -> CastScreen { panel = null }
                else -> ChannelInfoScreen(ch, url) { panel = null }
            }
        }
    }
}

// ───────── الترجمة ─────────
data class SubCfg(val enabled: Boolean = true, val lang: String = "ar", val size: Int = 1, val color: Int = 0, val bg: Int = 0, val top: Boolean = false)

object SubPrefs {
    fun load(pr: SharedPreferences) = SubCfg(pr.getBoolean("sub_on", true), pr.getString("sub_lang", "ar") ?: "ar",
        pr.getInt("sub_size", 1), pr.getInt("sub_color", 0), pr.getInt("sub_bg", 0), pr.getBoolean("sub_top", false))
    fun save(pr: SharedPreferences, c: SubCfg) {
        pr.edit().putBoolean("sub_on", c.enabled).putString("sub_lang", c.lang).putInt("sub_size", c.size)
            .putInt("sub_color", c.color).putInt("sub_bg", c.bg).putBoolean("sub_top", c.top).apply()
    }
}

@Composable
fun SubtitleSettings(c: SubCfg, onChange: (SubCfg) -> Unit, onBack: () -> Unit) {
    val langs = listOf("ar" to "العربية", "en" to "English", "fr" to "Français")
    val sizes = listOf("صغير", "متوسط", "كبير")
    ScreenFrame("الترجمة", "تعمل مع الترجمات المتوفرة داخل البث نفسه", onBack) {
        Box(Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF111B2B)),
            contentAlignment = if (c.top) Alignment.TopCenter else Alignment.BottomCenter) {
            Text("Everything will be fine", color = if (c.color == 1) Color(0xFFFFEB3B) else Color.White,
                fontSize = when (c.size) { 0 -> 14.sp; 2 -> 22.sp; else -> 18.sp },
                modifier = Modifier.padding(8.dp).background(if (c.bg == 1) Color(0xAA000000) else Color.Transparent).padding(horizontal = 6.dp))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("الترجمة", color = Color.White, fontSize = 16.sp)
            Switch(checked = c.enabled, onCheckedChange = { onChange(c.copy(enabled = it)) })
        }
        val li = langs.indexOfFirst { it.first == c.lang }.coerceAtLeast(0)
        OptionRow("لغة الترجمة", langs[li].second) { onChange(c.copy(lang = langs[(li + 1) % langs.size].first)) }
        OptionRow("حجم الخط", sizes[c.size.coerceIn(0, 2)]) { onChange(c.copy(size = (c.size + 1) % 3)) }
        OptionRow("لون النص", if (c.color == 1) "أصفر" else "أبيض") { onChange(c.copy(color = 1 - c.color)) }
        OptionRow("لون الخلفية", if (c.bg == 1) "أسود" else "شفاف") { onChange(c.copy(bg = 1 - c.bg)) }
        OptionRow("موقع الترجمة", if (c.top) "أعلى" else "أسفل") { onChange(c.copy(top = !c.top)) }
    }
}

// ───────── الصوت الخارجي ─────────
private fun audioLabel(d: AudioDeviceInfo): String {
    val n = when (d.type) {
        AudioDeviceInfo.TYPE_HDMI -> "HDMI"
        AudioDeviceInfo.TYPE_HDMI_ARC -> "HDMI (ARC)"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "مكبر الصوت الداخلي"
        AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "سماعات سلكية"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        else -> "جهاز صوت"
    }
    val pn = d.productName?.toString().orEmpty()
    return if (pn.isNotBlank() && !n.contains(pn)) "$n • $pn" else n
}

@Composable
fun AudioOutputSettings(p: ExoPlayer, volume: Float, onVolume: (Float) -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val devices = remember { am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).distinctBy { it.type to it.productName.toString() } }
    var chosen by remember { mutableStateOf(-1) }
    ScreenFrame("الصوت الخارجي", "اختر جهاز إخراج الصوت لهذه القناة", onBack) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("الجهاز الافتراضي", color = Color.White, fontSize = 16.sp)
            Switch(checked = chosen == -1, onCheckedChange = { if (it) { chosen = -1; p.setPreferredAudioDevice(null) } })
        }
        devices.forEach { d -> OptionRow(audioLabel(d), selected = chosen == d.id) { chosen = d.id; p.setPreferredAudioDevice(d) } }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🔈", fontSize = 20.sp)
            Slider(volume, onVolume, Modifier.weight(1f), colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent))
            Text("${(volume * 100).toInt()}%", color = Color.White)
        }
    }
}

// ───────── DLNA / Cast ─────────
@Composable
fun CastScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    ScreenFrame("DLNA / Cast", "بث القناة على الأجهزة الخارجية", onBack) {
        Text("لإرسال الشاشة أو الصوت إلى تلفاز أو مكبّر قريب استخدم خاصية البث في Android.", color = Color(0xFFB8D2F1), fontSize = 14.sp)
        Button(onClick = { runCatching { ctx.startActivity(Intent(Settings.ACTION_CAST_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } },
            modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8))) { Text("فتح إعدادات البث") }
        Text("اكتشاف أجهزة DLNA وChromecast من داخل التطبيق غير مفعّل بعد.", color = Color(0xFF8AAAD2), fontSize = 12.sp)
    }
}

@Composable
fun ChannelInfoScreen(ch: Channel?, url: String, onBack: () -> Unit) {
    val host = runCatching { java.net.URI(url).host }.getOrNull() ?: "—"
    ScreenFrame("معلومات القناة", ch?.name ?: "", onBack) {
        SettingLine("الاسم", ch?.name ?: "—", "اسم القناة أو العنصر")
        SettingLine("المجموعة", ch?.categoryName?.ifBlank { "غير مصنف" } ?: "—", "من المصدر الحالي")
        SettingLine("النوع", if (ch?.type == "itv") "بث مباشر" else "محتوى حسب الطلب", "نوع العنصر")
        SettingLine("خادم البث", host, "عنوان الخادم فقط")
    }
}

// ───────── شريط علوي مطابق للتصميم ─────────
@Composable
fun TopBar(onBack: (() -> Unit)?, subtitle: String? = null, onSearch: (() -> Unit)? = null, onSettings: (() -> Unit)? = null) {
    var now by remember { mutableStateOf(java.util.Calendar.getInstance().time) }
    LaunchedEffect(Unit) { while (true) { now = java.util.Calendar.getInstance().time; kotlinx.coroutines.delay(30_000) } }
    val loc = remember { java.util.Locale.Builder().setLanguage("ar").setUnicodeLocaleKeyword("nu", "latn").build() }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (onBack != null) FocusIcon("‹", Accent, 32.sp, onClick = onBack)
                Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(40.dp))
                Column {
                    Text(buildAnnotatedString {
                        withStyle(SpanStyle(color = Color.White)) { append("StreamPlayer ") }
                        withStyle(SpanStyle(color = Accent)) { append("IPTV Pro") }
                    }, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(subtitle ?: "عالمك الترفيهي في شاشة واحدة", color = Accent, fontSize = 11.sp)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                FocusIcon("🔍", Color.White, 17.sp, onClick = onSearch)
                Text("🔔", fontSize = 15.sp); Text("📶", fontSize = 15.sp)
                FocusIcon("⚙", Color(0xFF9CCFFF), 20.sp, onClick = onSettings)
                Column(horizontalAlignment = Alignment.End) {
                    Text(java.text.SimpleDateFormat("HH:mm", loc).format(now), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(java.text.SimpleDateFormat("EEEE d MMMM yyyy", loc).format(now), color = Color(0xFF9BB8DA), fontSize = 10.sp, maxLines = 1)
                }
            }
        }
    }
}

// ───────── الإعدادات (قائمة جانبية + لوحة مواقيت الصلاة) ─────────
@Composable
fun FieldRow(label: String, value: String, onChange: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF071F3D)).border(1.dp, Color(0xFF124574), RoundedCornerShape(10.dp))
        .focusHighlight(RoundedCornerShape(10.dp)).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        BasicTextField(value, onChange, singleLine = true, textStyle = TextStyle(color = Color(0xFFBFE6FF), fontSize = 15.sp, textAlign = TextAlign.End),
            cursorBrush = SolidColor(Accent), modifier = Modifier.width(150.dp))
        Text("  ›", color = Accent, fontSize = 18.sp)
    }
}

@Composable
fun SettingsScreen(
    city0: String, country0: String, prayers: List<Prayer>,
    onSave: (String, String, List<Prayer>) -> Unit, onSource: () -> Unit, onServer: () -> Unit, onBack: () -> Unit
) {
    val wide = isWideScreen()
    val tabs = listOf("عام" to "⚙", "مظهر التطبيق" to "▣", "تشغيل الفيديو" to "▶", "الصوت" to "🔊", "اللغة والمنطقة" to "◎", "الأمان والخصوصية" to "◈", "الإشعارات" to "♧")
    var selected by remember { mutableStateOf("عام") }
    var city by remember { mutableStateOf(city0) }; var country by remember { mutableStateOf(country0) }
    val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
    val times = remember { mutableStateMapOf<String, String>().apply { names.forEach { n -> put(n, prayers.firstOrNull { it.name == n }?.time ?: "--:--") } } }
    var status by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))).padding(18.dp)) {
        TopBar(onBack, "الإعدادات")
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.width(if (wide) 230.dp else 140.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Color(0xAA03142B))
                .border(1.dp, Edge, RoundedCornerShape(16.dp)).verticalScroll(rememberScrollState()).padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                tabs.forEach { (label, icon) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (selected == label) Color(0xFF0879D8) else Color.Transparent)
                        .focusHighlight(RoundedCornerShape(10.dp)).clickable { selected = label }.padding(if (wide) 12.dp else 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(icon, color = Color(0xFF76C8FF), fontSize = 17.sp)
                        Text(label, color = Color.White, fontSize = if (wide) 14.sp else 11.sp, modifier = Modifier.weight(1f), maxLines = 2)
                        if (selected == label) Text("›", color = Color.White, fontSize = 18.sp)
                    }
                }
                Divider(color = Edge, modifier = Modifier.padding(vertical = 6.dp))
                listOf("مصدر المشاهدة" to onSource, "معلومات السيرفر" to onServer).forEach { (label, act) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).focusHighlight(RoundedCornerShape(10.dp)).clickable { act() }.padding(if (wide) 12.dp else 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(label, color = Color(0xFF9DC5EF), fontSize = if (wide) 14.sp else 11.sp); Text("›", color = Accent, fontSize = 18.sp)
                    }
                }
            }
            Column(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Color(0xAA061A35)).border(1.dp, Edge, RoundedCornerShape(16.dp))
                .verticalScroll(rememberScrollState()).padding(if (wide) 20.dp else 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (selected == "عام") {
                    Text("مواقيت الصلاة", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    FieldRow("المدينة", city) { city = it }
                    FieldRow("الدولة", country) { country = it }
                    names.forEach { n -> FieldRow(n, times[n] ?: "") { times[n] = it } }
                    Text("المدينة والدولة بالإنجليزية (مثل Algiers / Algeria)، والأوقات بصيغة 24 ساعة HH:mm", color = Color(0xFF8AAAD2), fontSize = 11.sp)
                    Button(onClick = {
                        val ok = names.all { (times[it] ?: "").matches(Regex("(?:[01]\\d|2[0-3]):[0-5]\\d")) }
                        if (ok && city.isNotBlank() && country.isNotBlank()) { onSave(city.trim(), country.trim(), names.map { Prayer(it, times[it]!!) }); status = "تم حفظ التغييرات" }
                        else status = "تحقق من المدينة والدولة وصيغة الأوقات"
                    }, modifier = Modifier.fillMaxWidth().height(50.dp).focusHighlight(RoundedCornerShape(14.dp)), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8))) {
                        Text("حفظ التغييرات", fontWeight = FontWeight.Bold)
                    }
                    if (status.isNotBlank()) Text(status, color = if (status.startsWith("تم")) Color(0xFF45E7A4) else Color(0xFFFFC166), fontSize = 12.sp)
                } else {
                    Text(selected, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    when (selected) {
                        "مظهر التطبيق" -> { SettingLine("لون الواجهة", "أزرق نيون", "ألوان البطاقات والإطارات"); SettingLine("الرسوم المتحركة", "تلقائي", "حسب قدرة الجهاز") }
                        "تشغيل الفيديو" -> { SettingLine("الجودة الافتراضية", "تلقائي", "حسب جودة المصدر"); SettingLine("إظهار معلومات القناة", "مفعّل", "اسم القناة وبيانات EPG") }
                        "الصوت" -> { SettingLine("جهاز الإخراج", "الافتراضي", "يمكن تغييره أثناء التشغيل من «الصوت الخارجي»"); SettingLine("مستوى الصوت", "من المشغّل", "يُحفظ تلقائياً") }
                        "اللغة والمنطقة" -> { SettingLine("لغة التطبيق", "العربية", "العربية • Français • English"); SettingLine("المدينة", city, "تُضبط من تبويب «عام»") }
                        "الأمان والخصوصية" -> { SettingLine("بيانات الدخول", "محفوظة على الجهاز", "لا تشارك بيانات السيرفر") }
                        else -> SettingLine("الإشعارات", "حسب إعدادات الجهاز", "تُدار من إعدادات Android")
                    }
                }
            }
        }
    }
}

@Composable
fun SettingLine(label: String, value: String, hint: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF071F3D)).border(1.dp, Color(0xFF124574), RoundedCornerShape(12.dp)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) { Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text(hint, color = Color(0xFF7FA7CF), fontSize = 11.sp) }
        Text(value, color = Color(0xFF8EDBFF), fontSize = 12.sp, maxLines = 2)
    }
}

// ───────── معلومات السيرفر ─────────
@Composable
fun ServerInfoScreen(pr: SharedPreferences, status: String, onBack: () -> Unit, onEdit: () -> Unit, onRefresh: () -> Unit) {
    val type = pr.getString("t", "") ?: ""
    val a = pr.getString("a", "") ?: ""
    val b = pr.getString("b", "") ?: ""
    val connected = Repo.live.isNotEmpty() || Repo.movies.isNotEmpty() || Repo.series.isNotEmpty()
    var expiry by remember { mutableStateOf("...") }
    LaunchedEffect(type, a, b) { expiry = if (type == "xtream") xtreamExpiry(a, b, pr.getString("c", "") ?: "") else "—" }
    val typeName = when (type) { "m3u" -> "قائمة M3U"; "xtream" -> "Xtream Codes"; "stalker" -> "Stalker Portal"; else -> "غير مضبوط" }
    @Composable fun line(label: String, value: String, ok: Boolean = false) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF071F3D)).border(1.dp, Color(0xFF124574), RoundedCornerShape(12.dp)).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White, fontSize = 15.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(value, color = Color(0xFFBFE6FF), fontSize = 14.sp, maxLines = 1)
                if (ok) Text("✓", color = Color(0xFF45E7A4), fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
    ScreenFrame("معلومات السيرفر", status.ifBlank { "حالة الاتصال ومصدر القنوات" }, onBack) {
        line("حالة الاتصال", if (connected) typeName else "غير متصل", connected)
        line("رابط السيرفر", a.ifBlank { "لم تتم إضافة مصدر" })
        if (type == "xtream") { line("اسم المستخدم", b.ifBlank { "—" }); line("تاريخ انتهاء الاشتراك", expiry) }
        if (type == "stalker") line("عنوان MAC", b.ifBlank { "—" })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("القنوات المباشرة" to Repo.live.size, "الأفلام" to Repo.movies.size, "المسلسلات" to Repo.series.size).forEach { (n, v) ->
                Column(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF071F3D)).border(1.dp, Color(0xFF124574), RoundedCornerShape(12.dp)).padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(n, color = Color(0xFF9DC5EF), fontSize = 11.sp, maxLines = 1)
                    Text(v.toString(), color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth().height(50.dp).focusHighlight(RoundedCornerShape(14.dp)), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8))) { Text("تحديث البيانات", fontWeight = FontWeight.Bold) }
        OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth().focusHighlight(RoundedCornerShape(20.dp)), border = BorderStroke(1.dp, Accent)) { Text("تعديل المصدر", color = Color.White) }
    }
}

// ───────── المفضلة ─────────
@Composable
fun FavoritesScreen(onPlay: (Channel) -> Unit, onManage: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val pr = remember { ctx.getSharedPreferences("p", 0) }
    var favs by remember { mutableStateOf(Favs.all(pr)) }
    val favItems = remember(favs) { (Repo.live + Repo.movies).filter { Favs.key(it) in favs } }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))).padding(18.dp)) {
        TopBar(onBack, "المفضلة")
        Box(Modifier.align(Alignment.CenterHorizontally).clip(RoundedCornerShape(10.dp)).background(Color(0xFF0879D8)).padding(horizontal = 26.dp, vertical = 8.dp)) { Text("القنوات", color = Color.White, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(10.dp))
        if (favItems.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("لا توجد عناصر في المفضلة بعد", color = Color(0xFF8AAAD2)) }
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(favItems) { c ->
                Row(Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xAA061A35)).border(1.dp, Color(0xFF124574), RoundedCornerShape(12.dp))
                    .focusHighlight(RoundedCornerShape(12.dp)).clickable { onPlay(c) }.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF0D2D53)), contentAlignment = Alignment.Center) {
                        if (!c.logo.isNullOrBlank()) AsyncImage(c.logo, null, Modifier.fillMaxSize().padding(3.dp), contentScale = ContentScale.Fit) else Text(c.name.take(1).uppercase(), color = Accent, fontWeight = FontWeight.Bold)
                    }
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = Color.White, fontSize = 14.sp, maxLines = 1)
                        Text(c.categoryName.ifBlank { "غير مصنف" }, color = Color(0xFF86C8F8), fontSize = 11.sp, maxLines = 1)
                    }
                    FocusIcon("★", Color(0xFFFFC107), 22.sp) { Favs.toggle(pr, c); favs = Favs.all(pr) }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = onManage, modifier = Modifier.fillMaxWidth().height(50.dp).focusHighlight(RoundedCornerShape(14.dp)), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8))) { Text("إدارة المفضلة", fontWeight = FontWeight.Bold) }
    }
}
