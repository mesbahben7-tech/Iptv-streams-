package com.streamplayer.iptv

import android.content.SharedPreferences
import android.os.Bundle
import java.util.Calendar
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch

val Bg = Color(0xFF0A1830); val Card = Color(0xFF10264A); val Edge = Color(0xFF1E3F73); val Accent = Color(0xFF16B8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { App(getSharedPreferences("p", 0)) } }
}

@Composable
fun App(pr: SharedPreferences) {
    var screen by remember { mutableStateOf("home") }
    var list by remember { mutableStateOf(listOf<Channel>()) }
    var listTitle by remember { mutableStateOf("القنوات") }
    var playing by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf("") }
    var selectedChannel by remember { mutableStateOf<Channel?>(null) }
    val scope = rememberCoroutineScope()
    var city by remember { mutableStateOf(pr.getString("city", "Algiers")!!) }
    var country by remember { mutableStateOf(pr.getString("country", "Algeria")!!) }
    var prayers by remember { mutableStateOf(listOf<Prayer>()) }
    var epgNow by remember { mutableStateOf(listOf<String>()) }
    LaunchedEffect(city, country) {
        val fetched = runCatching { prayerTimes(city, country) }.getOrDefault(emptyList())
        val keys = mapOf("الفجر" to "fajr", "الظهر" to "dhuhr", "العصر" to "asr", "المغرب" to "maghrib", "العشاء" to "isha")
        val base = fetched.ifEmpty { keys.keys.map { Prayer(it, "--:--") } }
        prayers = base.map { p -> Prayer(p.name, pr.getString("prayer_${keys[p.name]}", null)?.takeIf { it.matches(Regex("\\d{2}:\\d{2}")) } ?: p.time) }
    }

    suspend fun load(s: Source) {
        msg = try { Repo.load(s); "تم تحميل قائمة القنوات بنجاح" } catch (e: Exception) { "خطأ: ${e.message}" }
    }
    LaunchedEffect(Unit) {
        pr.getString("t", null)?.let { load(Source(it, pr.getString("a", "")!!, pr.getString("b", "")!!, pr.getString("c", "")!!)) }
    }
    suspend fun playChannel(c: Channel) {
        try {
            epgNow = Repo.nowNext(c)
            selectedChannel = c
            playing = c.cmd?.let { Repo.stalker?.resolve(it, c.type, c.ep) } ?: c.url
            Recent.add(pr, c)
        } catch (e: Exception) { msg = "خطأ: ${e.message}" }
    }
    fun stepChannel(d: Int) {
        val cur = selectedChannel ?: return
        val i = list.indexOf(cur)
        val n = list.getOrNull(i + d)?.takeIf { i >= 0 && it.loader == null } ?: return
        scope.launch { playChannel(n) }
    }
    BackHandler(screen != "home" || playing != null) { if (playing != null) playing = null else screen = "home" }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Accent)) {
            Box(Modifier.fillMaxSize().background(Bg)) {
                when {
                    playing != null -> PlayerScreen(playing!!, selectedChannel, epgNow, pr, onBack = { playing = null },
                        onPrev = { stepChannel(-1) }, onNext = { stepChannel(1) },
                        nextName = selectedChannel?.let { cur -> val i = list.indexOf(cur); if (i >= 0) list.getOrNull(i + 1)?.takeIf { it.loader == null }?.name else null })
                    screen == "home" -> Home(msg, prayers, { k ->
                        if (k == "setup") { screen = "setup" } else {
                            listTitle = when (k) { "live" -> "البث المباشر"; "movies" -> "الأفلام"; "recent" -> "آخر مشاهدة"; else -> "المسلسلات" }
                            list = when (k) { "live" -> Repo.live; "movies" -> Repo.movies; "recent" -> Recent.load(pr); else -> Repo.series }
                            screen = "list"
                        }
                    }, { screen = "settings" }, { screen = "setup" })
                    screen == "settings" -> SettingsScreen(
                        onGeneral = { screen = "setup" },
                        onServer = { screen = "server" },
                        onPrayerSettings = { screen = "prayers" },
                        onBack = { screen = "home" }
                    )
                    screen == "server" -> ServerInfoScreen(pr, msg, onBack = { screen = "settings" }, onEdit = { screen = "setup" }, onRefresh = {
                        pr.getString("t", null)?.let { t0 -> scope.launch { msg = "جارٍ التحميل..."; load(Source(t0, pr.getString("a", "")!!, pr.getString("b", "")!!, pr.getString("c", "")!!)) } }
                    })
                    screen == "prayers" -> PrayerSettingsScreen(city, country, prayers, onBack = { screen = "settings" }) { c1, k1, times ->
                        city = c1; country = k1
                        pr.edit().putString("city", c1).putString("country", k1)
                            .putString("prayer_fajr", times.first { it.name == "الفجر" }.time)
                            .putString("prayer_dhuhr", times.first { it.name == "الظهر" }.time)
                            .putString("prayer_asr", times.first { it.name == "العصر" }.time)
                            .putString("prayer_maghrib", times.first { it.name == "المغرب" }.time)
                            .putString("prayer_isha", times.first { it.name == "العشاء" }.time).apply()
                        prayers = times
                        screen = "settings"
                    }
                    screen == "setup" -> Setup(city, country, onBack = { screen = "home" }) { s, c1, k1 ->
                        city = c1; country = k1
                        pr.edit().putString("city", c1).putString("country", k1).apply()
                        if (s.a.isNotBlank()) pr.edit().putString("t", s.type).putString("a", s.a).putString("b", s.b).putString("c", s.c).apply()
                        screen = "home"; if (s.a.isNotBlank()) scope.launch { msg = "جارٍ التحميل..."; load(s) }
                    }
                    else -> ChannelList(list, listTitle, selectedChannel, onBack = { screen = "home" }, onSelect = { selectedChannel = it }) { c ->
                        scope.launch {
                            val ld = c.loader
                            if (ld != null) {
                                listTitle = c.name
                                list = try { ld() } catch (e: Exception) { msg = "خطأ: ${e.message}"; list }
                                selectedChannel = null
                            } else {
                                try {
                                    epgNow = Repo.nowNext(c)
                                    selectedChannel = c
                                    playing = c.cmd?.let { Repo.stalker?.resolve(it, c.type, c.ep) } ?: c.url
                                    Recent.add(pr, c)
                                } catch (e: Exception) { msg = "خطأ: ${e.message}" }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Tile(mod: Modifier, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    var f by remember { mutableStateOf(false) }
    val sh = RoundedCornerShape(16.dp)
    Box(mod.clip(sh).background(Card).border(if (f) 3.dp else 1.dp, if (f) Accent else Edge, sh)
        .onFocusChanged { f = it.isFocused }.clickable(onClick = onClick), content = content)
}

@Composable
fun Home(msg: String, prayers: List<Prayer>, onOpen: (String) -> Unit, onSetup: () -> Unit, onAddServer: () -> Unit) {
    var clock by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) {
        while (true) {
            clock = Calendar.getInstance()
            kotlinx.coroutines.delay(30_000)
        }
    }
    val wide = androidx.compose.ui.platform.LocalConfiguration.current.let { it.screenWidthDp >= 800 }
    val loc = java.util.Locale.Builder().setLanguage("ar").setUnicodeLocaleKeyword("nu", "latn").build()
    val timeText = java.text.SimpleDateFormat("HH:mm", loc).format(clock.time)
    val dateText = java.text.SimpleDateFormat("EEEE d MMMM yyyy", loc).format(clock.time)
    val nowMins = clock.get(Calendar.HOUR_OF_DAY) * 60 + clock.get(Calendar.MINUTE)
    fun mins(t: String): Int = runCatching { t.take(2).toInt() * 60 + t.takeLast(2).toInt() }.getOrDefault(0)
    val nextPrayer = prayers.firstOrNull { mins(it.time) > nowMins } ?: prayers.firstOrNull()
    val prayerNames = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

    @Composable fun PrayerPanel(modifier: Modifier = Modifier) {
        Row(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Tile(Modifier.weight(1f).height(if (wide) 108.dp else 118.dp), {}) {
                Image(painterResource(R.drawable.prayer_mosque_art), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xCC06142C), Color(0xAA06142C), Color(0xEE06142C)))))
                Row(Modifier.fillMaxSize().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.width(if (wide) 150.dp else 105.dp), verticalArrangement = Arrangement.Center) {
                        Text("☾", color = Accent, fontSize = 27.sp)
                        Text("مواقيت الصلاة", color = Color.White, fontSize = if (wide) 17.sp else 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("📍 الجزائر⌄", color = Color(0xFF9DC5EF), fontSize = 12.sp, maxLines = 1)
                    }
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val displayPrayers = if (prayers.isEmpty()) prayerNames.map { Prayer(it, "--:--") } else prayers
                        displayPrayers.take(5).forEach { p ->
                            val active = p.name == nextPrayer?.name
                            Column(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(10.dp))
                                .background(if (active) Color(0xFF153C63) else Color(0x66102B50))
                                .border(if (active) 1.5.dp else 1.dp, if (active) Color(0xFFFFA726) else Color(0xFF174D82), RoundedCornerShape(10.dp))
                                .padding(horizontal = 2.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(when (p.name) { "الفجر" -> "☀"; "الظهر" -> "☼"; "العصر" -> "☀"; "المغرب" -> "◒"; else -> "☾" }, color = if (active) Color(0xFFFFA726) else Accent, fontSize = 20.sp)
                                Text(p.name, color = Color.White, fontSize = if (wide) 12.sp else 10.sp, maxLines = 1)
                                Text(p.time, color = if (active) Color(0xFFFFB74D) else Color.White, fontSize = if (wide) 14.sp else 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
            if (wide) Tile(Modifier.weight(0.34f).height(108.dp), onSetup) {
                Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.prayer_mecca_art), null, Modifier.fillMaxHeight().aspectRatio(1.1f).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        Text(nextPrayer?.name ?: "المغرب", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("◷ ${nextPrayer?.time ?: "--:--"}", color = Color(0xFF36D5FF), fontSize = 15.sp)
                    }
                    Text("›", color = Accent, fontSize = 34.sp)
                }
            } else
            Tile(Modifier.width(112.dp).height(118.dp), onSetup) {
                Image(painterResource(R.drawable.prayer_mecca_art), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xDD06142C), Color(0x55102B50)))))
                Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        Text("الصلاة القادمة", color = Color(0xFF9DC5EF), fontSize = if (wide) 11.sp else 9.sp, maxLines = 1)
                        Text(nextPrayer?.name ?: "المغرب", color = Color(0xFF36D5FF), fontSize = if (wide) 18.sp else 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("◷ ${nextPrayer?.time ?: "--:--"}", color = Color.White, fontSize = if (wide) 14.sp else 11.sp)
                    }
                    if (wide) Text("›", color = Accent, fontSize = 30.sp)
                }
            }
        }
    }

    @Composable fun FeaturePanel(modifier: Modifier = Modifier) {
        Tile(modifier.height(if (wide) 150.dp else 155.dp), {}) {
            Row(Modifier.fillMaxSize().padding(if (wide) 12.dp else 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(if (wide) 1.0f else 0.7f).fillMaxHeight().clip(RoundedCornerShape(12.dp))) {
                    Image(painterResource(R.drawable.home_hero_art), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0x2206142C), Color(0x6606142C), Color(0xEE06142C)))))
                }
                Column(Modifier.weight(if (wide) 1.35f else 1.0f), verticalArrangement = Arrangement.Center) {
                    Text("شاهد كل ما تحب", color = Color.White, fontSize = if (wide) 24.sp else 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(5.dp))
                    Text("قنواتك وأفلامك ومسلسلاتك في مكان واحد", color = Color(0xFFB8D2F1), fontSize = if (wide) 14.sp else 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                if (wide) Row(Modifier.weight(2.3f).fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF14C3FF), Color(0xFF0A8FE0)))).clickable(onClick = onAddServer), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("▶", color = Color.White, fontSize = 34.sp)
                            Text("ابدأ الآن", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(18.dp)).background(Color(0xFF0E2A55))
                        .clickable { onOpen("recent") }, contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("◷", color = Color(0xFF9CCFFF), fontSize = 34.sp)
                            Text("آخر مشاهدة", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else Column(Modifier.weight(0.85f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onAddServer, modifier = Modifier.fillMaxWidth().height(if (wide) 54.dp else 44.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF08AEEF)), contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("▶  ابدأ الآن", color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (wide) 16.sp else 12.sp, maxLines = 1)
                    }
                    OutlinedButton(onClick = { onOpen("recent") }, modifier = Modifier.fillMaxWidth().height(if (wide) 48.dp else 42.dp), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Color(0xFF1A5B99)), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Text("◷  آخر مشاهدة", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = if (wide) 14.sp else 11.sp, maxLines = 1)
                    }
                }
            }
        }
    }

    @Composable fun CategoryCard(title: String, key: String, glyph: String, art: List<Color>, modifier: Modifier = Modifier) {
        Tile(modifier, { onOpen(key) }) {
            val artRes = when (key) {
                "live" -> R.drawable.home_live_art
                "movies" -> R.drawable.home_movies_art
                else -> R.drawable.home_series_art
            }
            Image(painterResource(artRes), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000B1D), Color(0xCC031027), Color(0xF0031027)))))
            val iconRes = when (key) { "live" -> R.drawable.ic_live; "movies" -> R.drawable.ic_movies; else -> R.drawable.ic_series }
            Image(painterResource(iconRes), null, Modifier.align(Alignment.Center).offset(y = (-15).dp).size(if (wide) 72.dp else 44.dp))
            Text(title, color = Color.White, fontSize = if (wide) 22.sp else 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 15.dp))
            Text("›", color = Color(0xFF8CCBFF), fontSize = 32.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 10.dp))
        }
    }

    if (wide) {
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF031027)))).padding(horizontal = 28.dp, vertical = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth().height(66.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(54.dp))
                    Column {
                        Text(buildAnnotatedString {
                            withStyle(SpanStyle(color = Color.White)) { append("StreamPlayer ") }
                            withStyle(SpanStyle(color = Accent)) { append("IPTV Pro") }
                        }, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("عالمك الترفيهي في شاشة واحدة", color = Accent, fontSize = 13.sp)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Text("🔍", fontSize = 20.sp, modifier = Modifier.clickable { onOpen("live") })
                    Text("📶", fontSize = 20.sp)
                    Tile(Modifier.size(42.dp), onSetup) { Icon(Icons.Default.Settings, null, tint = Color(0xFF9CCFFF), modifier = Modifier.align(Alignment.Center)) }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(timeText, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text(dateText, color = Color(0xFF9BB8DA), fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
            PrayerPanel(Modifier.fillMaxWidth().height(108.dp))
            FeaturePanel(Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard("البث المباشر", "live", "◉", listOf(Color(0xFF0D4A78), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
                CategoryCard("الأفلام", "movies", "🎬", listOf(Color(0xFF17385F), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
                CategoryCard("المسلسلات", "series", "▣", listOf(Color(0xFF153052), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ℹ  StreamPlayer IPTV Pro     v1.0.0", color = Color(0xFF8AAAD2), fontSize = 12.sp)
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF0E2547)).padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(if (msg.startsWith("تم")) Color(0xFF00D58A) else Color(0xFF4C91CB)))
                    Text(msg.ifBlank { "جاهز للاتصال بالسيرفر" }, color = Color(0xFF9BC4F0), fontSize = 11.sp, maxLines = 1)
                }
            }
        }
      }
    } else {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF031027)))).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("StreamPlayer IPTV Pro", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("عالمك الترفيهي في شاشة واحدة", color = Accent, fontSize = 12.sp)
                }
                Tile(Modifier.size(44.dp), onSetup) { Icon(Icons.Default.Settings, null, tint = Color.White, modifier = Modifier.align(Alignment.Center)) }
            }
            Text("$timeText   •   $dateText", color = Color(0xFF9BB8DA), fontSize = 12.sp)
            PrayerPanel(Modifier.fillMaxWidth().height(118.dp))
            FeaturePanel(Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().height(130.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryCard("البث المباشر", "live", "◉", listOf(Color(0xFF0D4A78), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
                CategoryCard("الأفلام", "movies", "🎬", listOf(Color(0xFF17385F), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
                CategoryCard("المسلسلات", "series", "▣", listOf(Color(0xFF153052), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
            }
            Text(msg.ifBlank { "ℹ  StreamPlayer IPTV Pro  •  v1.0.0" }, color = Color(0xFF8AAAD2), fontSize = 12.sp)
        }
    }
}

@Composable
fun ChannelList(
    l: List<Channel>,
    title: String,
    selected: Channel?,
    onBack: () -> Unit,
    onSelect: (Channel) -> Unit,
    onPlay: (Channel) -> Unit
) {
    var q by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("الكل") }
    val ctx0 = LocalContext.current
    val pr0 = remember { ctx0.getSharedPreferences("p", 0) }
    var favs by remember { mutableStateOf(Favs.all(pr0)) }
    var byCountry by remember { mutableStateOf(false) }
    val wide = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 800
    fun gkey(c: Channel): String { val n = c.categoryName.trim(); return if (byCountry && n.contains("|")) n.substringBefore("|").trim() else n }
    val serverGroups = remember(l, byCountry) { l.map { gkey(it) }.filter { it.isNotBlank() && it != "غير مصنف" }.distinct() }
    val groups = remember(l, serverGroups, favs) {
        val categories = serverGroups + if (l.any { gkey(it).isBlank() || gkey(it) == "غير مصنف" }) listOf("غير مصنف") else emptyList()
        listOf("الكل") + (if (favs.isNotEmpty()) listOf("المفضلة") else emptyList()) + categories
    }
    fun belongs(c: Channel, g: String): Boolean {
        if (g == "الكل") return true
        if (g == "المفضلة") return Favs.key(c) in favs
        if (g == "غير مصنف") return gkey(c).isBlank() || gkey(c) == "غير مصنف"
        return gkey(c) == g
    }
    val shown = remember(l, q, group, byCountry, favs) { l.filter { belongs(it, group) && (q.isBlank() || it.name.contains(q, ignoreCase = true)) } }
    var previewEpg by remember { mutableStateOf(emptyList<String>()) }
    LaunchedEffect(selected) { previewEpg = selected?.let { Repo.nowNext(it) } ?: emptyList() }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))).padding(if (wide) 14.dp else 12.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF08284B)).border(1.dp, Accent, RoundedCornerShape(12.dp)).clickable { onBack() }, contentAlignment = Alignment.Center) { Text("‹", color = Accent, fontSize = 30.sp) }
                Column {
                    Text("StreamPlayer IPTV Pro", color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (wide) 20.sp else 16.sp)
                    Text(title, color = Accent, fontSize = if (wide) 13.sp else 11.sp)
                }
            }
            Text("◉   ⚙   ${java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(Calendar.getInstance().time)}", color = Color(0xFFBBD8F5), fontSize = 13.sp)
        }
        Divider(color = Color(0xFF124B80), thickness = 1.dp)
        if (wide) {
            Row(Modifier.fillMaxSize().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.width(210.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Color(0xAA03142B)).border(1.dp, Edge, RoundedCornerShape(16.dp)).padding(8.dp)) {
                    Text("أقسام القنوات", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(10.dp))
                    Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("الباقات" to false, "البلدان" to true).forEach { (t, v) ->
                            Box(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (byCountry == v) Color(0xFF0879D8) else Color(0xFF071F3D))
                                .clickable { byCountry = v; group = "الكل" }.padding(vertical = 8.dp), contentAlignment = Alignment.Center) { Text(t, color = Color.White, fontSize = 12.sp) }
                        }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        items(groups) { g ->
                            val count = if (g == "الكل") l.size else l.count { belongs(it, g) }
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (group == g) Color(0xFF0879D8) else Color.Transparent).clickable { group = g }.padding(horizontal = 10.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(when(g) { "الرياضية" -> "⚽"; "العربية" -> "▣"; "الأجنبية" -> "◎"; "الأخبار" -> "▤"; "الأطفال" -> "☻"; "دينية" -> "☾"; else -> "▦" }, color = Color(0xFF76C8FF), fontSize = 17.sp)
                                Text(g, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f), maxLines = 1)
                                Text(count.toString(), color = Color(0xFF9ED7FF), fontSize = 11.sp)
                            }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text("إجمالي القنوات: ${l.size}", color = Color(0xFF8DC9FF), fontSize = 12.sp, modifier = Modifier.padding(8.dp))
                }
                Column(Modifier.weight(1.12f).fillMaxHeight()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(q, { q = it }, modifier = Modifier.weight(1f).heightIn(min = 52.dp), singleLine = true, placeholder = { Text("بحث عن قناة...", color = Color(0xFF91ACCA)) }, leadingIcon = { Text("⌕", color = Accent, fontSize = 23.sp) }, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Edge, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                        Text("${shown.size} قناة", color = Color(0xFFB6D5F4), fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(shown) { c ->
                            val active = selected == c
                            Row(Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(12.dp)).background(if (active) Color(0xFF123E83) else Color(0xAA061A35)).border(if (active) 2.dp else 1.dp, if (active) Accent else Color(0xFF124574), RoundedCornerShape(12.dp)).clickable { if (wide) onSelect(c) else onPlay(c) }.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF0D2D53)), contentAlignment = Alignment.Center) {
                                    if (!c.logo.isNullOrBlank()) AsyncImage(c.logo, null, Modifier.fillMaxSize().padding(3.dp), contentScale = ContentScale.Fit) else Text(c.name.take(1).uppercase(), color = Accent, fontWeight = FontWeight.Bold)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text(c.name, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(if (c.type == "itv") "مباشر • ${group}" else "محتوى حسب الطلب", color = Color(0xFF86C8F8), fontSize = 10.sp, maxLines = 1)
                                }
                                Text(if (Favs.key(c) in favs) "★" else "☆", color = Color(0xFFFFC107), fontSize = 20.sp,
                                    modifier = Modifier.clickable { Favs.toggle(pr0, c); favs = Favs.all(pr0) }.padding(4.dp))
                                Text("%03d".format(shown.indexOf(c) + 1), color = Color(0xFF9BB9D7), fontSize = 11.sp)
                            }
                        }
                    }
                }
                Column(Modifier.weight(0.95f).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(Color(0xAA03142B)).border(1.dp, Edge, RoundedCornerShape(16.dp)).padding(10.dp)) {
                    Box(Modifier.fillMaxWidth().weight(0.9f).clip(RoundedCornerShape(12.dp)).background(Color(0xFF020812)), contentAlignment = Alignment.Center) {
                        if (selected?.logo != null) AsyncImage(selected.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                        else Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("▣", color = Accent, fontSize = 56.sp); Text("معاينة القناة", color = Color(0xFF91BCE8), fontSize = 13.sp) }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(selected?.name ?: "اختر قناة للعرض", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("دليل البرامج EPG", color = Color(0xFFB99AFF), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, bottom = 5.dp))
                    if (previewEpg.isEmpty()) Text("لا تتوفر بيانات EPG لهذه القناة حاليًا", color = Color(0xFF8EAAC8), fontSize = 12.sp) else previewEpg.take(2).forEachIndexed { i, e ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Text(if (i == 0) "●" else "◷", color = Accent); Text(e, color = Color.White, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
                    }
                    Spacer(Modifier.weight(0.1f))
                    Button(onClick = { selected?.let(onPlay) }, enabled = selected != null, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087DE3))) { Text("▶  تشغيل القناة") }
                }
            }
        } else {
            Row(Modifier.fillMaxSize().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LazyColumn(Modifier.width(104.dp).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(groups) { g ->
                        val count = if (g == "الكل") l.size else l.count { belongs(it, g) }
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(if (group == g) Color(0xFF0879D8) else Color.Transparent).clickable { group = g }.padding(horizontal = 6.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(g, color = if (group == g) Color.White else Color(0xFF9CB9D7), fontSize = 10.sp, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(count.toString(), color = Color(0xFF8CCBFF), fontSize = 9.sp)
                        }
                    }
                }
                Column(Modifier.weight(1f).fillMaxHeight()) {
                    OutlinedTextField(q, { q = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("بحث عن قناة...") }, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Edge, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(shown) { c ->
                            Row(Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(10.dp)).background(if (selected == c) Color(0xFF123E83) else Color(0xAA061A35)).border(1.dp, if (selected == c) Accent else Edge, RoundedCornerShape(10.dp)).clickable { onPlay(c) }.padding(7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(Modifier.size(36.dp), contentAlignment = Alignment.Center) { if (!c.logo.isNullOrBlank()) AsyncImage(c.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) else Text("▣", color = Accent) }
                                Text(c.name, color = Color.White, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(onGeneral: () -> Unit, onServer: () -> Unit, onPrayerSettings: () -> Unit, onBack: () -> Unit) {
    var selected by remember { mutableStateOf("عام") }
    val wide = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 800
    val tabs = listOf("عام" to "⚙", "مظهر التطبيق" to "▣", "تشغيل الفيديو" to "▶", "اللغة والمنطقة" to "◎", "الأمان والخصوصية" to "◈", "الإشعارات" to "♧", "مساعدة" to "?")
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))).padding(if (wide) 20.dp else 14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("الإعدادات", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("خصص تجربة المشاهدة بما يناسبك", color = Color(0xFF8FBDE8), fontSize = 12.sp) }
            Text("‹", color = Accent, fontSize = 32.sp, modifier = Modifier.clickable { onBack() }.padding(horizontal = 8.dp))
        }
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(Modifier.width(if (wide) 230.dp else 138.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xAA03142B)).border(1.dp, Edge, RoundedCornerShape(16.dp)).padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                tabs.forEach { (label, icon) -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (selected == label) Color(0xFF0879D8) else Color.Transparent).clickable { selected = label }.padding(if (wide) 12.dp else 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { Text(icon, color = Accent, fontSize = 17.sp); Text(label, color = Color.White, fontSize = if (wide) 14.sp else 11.sp, maxLines = 2) } }
            }
            Column(Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()).clip(RoundedCornerShape(16.dp)).background(Color(0xAA061A35)).border(1.dp, Edge, RoundedCornerShape(16.dp)).padding(if (wide) 20.dp else 12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(selected, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                when (selected) {
                    "عام" -> {
                        SettingLine("اللغة", "العربية", "تغيير لغة التطبيق")
                        SettingLine("المظهر", "داكن • أزرق كهربائي", "ثيم StreamPlayer")
                        SettingLine("اتجاه الواجهة", "تلقائي حسب اللغة", "دعم العربية والإنجليزية والفرنسية")
                        SettingLine("التشغيل التلقائي", "مفعّل", "تشغيل القناة عند اختيارها")
                        SettingLine("تحميل البيانات مسبقًا", "مفعّل", "تحسين سرعة التنقل")
                    }
                    "مظهر التطبيق" -> { SettingLine("لون الواجهة", "أزرق نيون", "ألوان البطاقات والإطارات"); SettingLine("حجم البطاقات", "متوازن", "مناسب للهاتف وAndroid TV"); SettingLine("الرسوم المتحركة", "تلقائي", "حسب قدرة الجهاز") }
                    "تشغيل الفيديو" -> { SettingLine("الجودة الافتراضية", "تلقائي", "حسب جودة المصدر"); SettingLine("نسبة العرض", "ملاءمة الشاشة", "تغيير وضع العرض من المشغل"); SettingLine("إظهار معلومات القناة", "مفعّل", "اسم القناة وبيانات EPG") }
                    "اللغة والمنطقة" -> { SettingLine("لغة التطبيق", "العربية", "العربية • Français • English"); SettingLine("المدينة", "إعدادات مواقيت الصلاة", "يتم ضبطها من إعداد المدينة") }
                    "الأمان والخصوصية" -> { SettingLine("قفل مجموعة +18", "مفعّل حسب إعدادات PIN", "القفل خاص بالمجموعة فقط"); SettingLine("بيانات الدخول", "محفوظة على الجهاز", "لا تشارك بيانات السيرفر") }
                    "الإشعارات" -> SettingLine("الإشعارات", "حسب إعدادات الجهاز", "يمكن إدارة أذونات النظام من إعدادات Android")
                    else -> SettingLine("المساعدة", "StreamPlayer IPTV Pro", "تحقق من رابط السيرفر وبيانات الاشتراك عند تعذر الاتصال")
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = onGeneral, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8))) { Text("إعداد مصدر المشاهدة / الاتصال") }
                OutlinedButton(onClick = onServer, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Accent)) { Text("معلومات السيرفر", color = Color.White) }
                OutlinedButton(onClick = onPrayerSettings, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Accent)) { Text("تعديل مواقيت الصلاة", color = Color.White) }
            }
        }
    }
}

@Composable
fun SettingLine(label: String, value: String, hint: String) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF071F3D)).border(1.dp, Color(0xFF124574), RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) { Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold); Text(hint, color = Color(0xFF7FA7CF), fontSize = 11.sp) }
        Text(value, color = Color(0xFF8EDBFF), fontSize = 12.sp, maxLines = 2)
    }
}

@Composable
fun ServerInfoScreen(pr: SharedPreferences, status: String, onBack: () -> Unit, onEdit: () -> Unit, onRefresh: () -> Unit) {
    val type = pr.getString("t", "") ?: ""
    val a = pr.getString("a", "") ?: ""
    val b = pr.getString("b", "") ?: ""
    val connected = Repo.live.isNotEmpty() || Repo.movies.isNotEmpty() || Repo.series.isNotEmpty()
    val host = runCatching { java.net.URI(a).host ?: a }.getOrDefault(a)
    var expiry by remember { mutableStateOf("...") }
    LaunchedEffect(type, a, b) { expiry = if (type == "xtream") xtreamExpiry(a, b, pr.getString("c", "") ?: "") else "—" }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))).padding(18.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column { Text("معلومات السيرفر", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold); Text("حالة الاتصال ومصدر القنوات", color = Color(0xFF8FBDE8), fontSize = 12.sp) }
            Text("‹", color = Accent, fontSize = 32.sp, modifier = Modifier.clickable { onBack() })
        }
        Spacer(Modifier.height(18.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xAA061A35)).border(1.dp, Edge, RoundedCornerShape(18.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) { Text("▤", color = Accent, fontSize = 38.sp); Column(Modifier.weight(1f)) { Text("معلومات السيرفر", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text(if (connected) "● متصل / تم تحميل المحتوى" else "● لم يتم تأكيد الاتصال", color = if (connected) Color(0xFF45E7A4) else Color(0xFFFFC166), fontSize = 13.sp) } }
            Divider(color = Edge)
            SettingLine("نوع المصدر", when(type) { "m3u" -> "قائمة M3U"; "xtream" -> "Xtream Codes"; "stalker" -> "Stalker Portal"; else -> "غير مضبوط" }, "نوع مصدر المشاهدة الحالي")
            SettingLine("عنوان السيرفر", host.ifBlank { "لم تتم إضافة مصدر" }, a.ifBlank { "أضف رابطًا من إعدادات الاتصال" })
            if (type == "xtream") SettingLine("اسم المستخدم", b.ifBlank { "—" }, "كلمة المرور مخفية حفاظًا على الخصوصية")
            if (type == "stalker") SettingLine("عنوان MAC", b.ifBlank { "—" }, "بيانات جهاز البوابة")
            if (type == "xtream") SettingLine("تاريخ انتهاء الاشتراك", expiry, "من بيانات حساب Xtream")
            SettingLine("قنوات البث المباشر", Repo.live.size.toString(), "العناصر المحمّلة من المصدر الحالي")
            SettingLine("الأفلام", Repo.movies.size.toString(), "العناصر المحمّلة من المصدر الحالي")
            SettingLine("المسلسلات", Repo.series.size.toString(), "العناصر المحمّلة من المصدر الحالي")
            SettingLine("حالة التحميل", status.ifBlank { "بانتظار الاتصال بالسيرفر" }, "آخر حالة معروفة")
            OutlinedButton(onClick = onRefresh, modifier = Modifier.fillMaxWidth(), border = BorderStroke(1.dp, Accent)) { Text("تحديث البيانات", color = Color.White) }
            Button(onClick = onEdit, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8))) { Text("إدارة الحساب / تعديل المصدر") }
        }
    }
}

@Composable
fun PrayerSettingsScreen(
    city0: String,
    country0: String,
    current: List<Prayer>,
    onBack: () -> Unit,
    onSave: (String, String, List<Prayer>) -> Unit
) {
    var city by remember { mutableStateOf(city0) }
    var country by remember { mutableStateOf(country0) }
    val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
    val times = remember { mutableStateMapOf<String, String>().apply { names.forEach { n -> put(n, current.firstOrNull { it.name == n }?.time ?: "--:--") } } }
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))).padding(20.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("تعديل مواقيت الصلاة", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold); Text("عدّل المدينة أو أدخل الأوقات يدويًا", color = Color(0xFF8FBDE8), fontSize = 12.sp) }
            Text("‹", color = Accent, fontSize = 32.sp, modifier = Modifier.clickable { onBack() })
        }
        OutlinedTextField(city, { city = it }, modifier = Modifier.fillMaxWidth(), label = { Text("المدينة (بالإنجليزية) مثل Algiers") }, singleLine = true)
        OutlinedTextField(country, { country = it }, modifier = Modifier.fillMaxWidth(), label = { Text("الدولة مثل Algeria") }, singleLine = true)
        Text("الأوقات بنظام 24 ساعة (HH:mm)", color = Color(0xFF8FBDE8), fontSize = 13.sp)
        names.forEach { n ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xFF071F3D)).border(1.dp, Edge, RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(n, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
                OutlinedTextField(value = times[n] ?: "--:--", onValueChange = { times[n] = it }, modifier = Modifier.width(130.dp), singleLine = true, placeholder = { Text("05:12") }, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Edge, focusedTextColor = Color.White, unfocusedTextColor = Color.White))
            }
        }
        Button(onClick = {
            val valid = names.all { (times[it] ?: "").matches(Regex("(?:[01]\\d|2[0-3]):[0-5]\\d")) }
            if (valid && city.isNotBlank() && country.isNotBlank()) onSave(city.trim(), country.trim(), names.map { Prayer(it, times[it]!!) })
        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8))) { Text("حفظ مواقيت الصلاة") }
        Text("إذا غيّرت المدينة، تُستخدم الأوقات التي أدخلتها هنا حتى تعدّلها مرة أخرى.", color = Color(0xFF8AAAD2), fontSize = 12.sp)
    }
}
