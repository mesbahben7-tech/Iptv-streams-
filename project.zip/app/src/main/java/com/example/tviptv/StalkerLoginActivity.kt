package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class StalkerLoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stalker)

        val portal = findViewById<EditText>(R.id.portal)
        val mac = findViewById<EditText>(R.id.mac)
        val login = findViewById<Button>(R.id.login)
        val status = findViewById<TextView>(R.id.status)
        val prefs = getSharedPreferences("stalker", MODE_PRIVATE)

        portal.setText(prefs.getString("portal", ""))
        mac.setText(prefs.getString("mac", ""))

        login.setOnClickListener {
            val normalized = StalkerApi.normalizeMac(mac.text.toString())
            if (normalized == null) {
                status.text = getString(R.string.bad_mac)
                return@setOnClickListener
            }
            val acc = StalkerAccount(portal.text.toString(), normalized)
            status.text = getString(R.string.connecting)
            login.isEnabled = false
            lifecycleScope.launch {
                try {
                    StalkerApi.connect(acc)
                    prefs.edit()
                        .putString("portal", portal.text.toString().trim())
                        .putString("mac", normalized)
                        .apply()
                    getSharedPreferences("app", MODE_PRIVATE).edit().putString("last", "stalker").apply()
                    Session.stalker = acc
                    Session.account = null
                    status.text = ""
                    startActivity(Intent(this@StalkerLoginActivity, HomeActivity::class.java))
                } catch (e: Exception) {
                    status.text = getString(R.string.load_error, e.message ?: "")
                } finally {
                    login.isEnabled = true
                }
            }
        }
    }
}
