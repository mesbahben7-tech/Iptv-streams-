package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {

    private lateinit var favCount: TextView
    private lateinit var homeHint: TextView
    private val countViews = HashMap<Kind, TextView>()
    private lateinit var histAdapter: PosterAdapter
    private lateinit var mostAdapter: PosterAdapter
    private lateinit var seriesAdapter: PosterAdapter
    private var histList: List<Hist> = emptyList()
    private var mostList: List<Hist> = emptyList()
    private var seriesList: List<Entry> = emptyList()

    private fun bind(id: Int, action: () -> Unit) {
        findViewById<View>(id).setOnClickListener { action() }
    }

    private fun openKind(kind: Kind) {
        val cls = if (kind == Kind.LIVE) LiveActivity::class.java else BrowseActivity::class.java
        startActivity(Intent(this, cls).putExtra("kind", kind.name))
    }

    private fun openSeries() {
        if (Session.account == null) {
            Toast.makeText(this, R.string.coming_soon, Toast.LENGTH_SHORT).show()
        } else {
            openKind(Kind.SERIES)
        }
    }

    private fun openDetails(kind: Kind, e: Entry) {
        Session.detail = Fav(kind, e)
        startActivity(Intent(this, DetailsActivity::class.java))
    }

    private fun openHist(h: Hist) {
        if (h.kind == Kind.LIVE) {
            Playback.play(this, Kind.LIVE, listOf(h.entry), 0)
        } else {
            openDetails(h.kind, h.entry)
        }
    }

    private fun switchAccount() {
        val i = Intent(this, StartActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        finish()
    }

    private fun setupRow(rvId: Int, adapter: PosterAdapter) {
        val rv = findViewById<RecyclerView>(rvId)
        rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rv.adapter = adapter
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        setContentView(R.layout.activity_home)

        countViews[Kind.LIVE] = findViewById<TextView>(R.id.count_live)
        countViews[Kind.MOVIES] = findViewById<TextView>(R.id.count_movies)
        countViews[Kind.SERIES] = findViewById<TextView>(R.id.count_series)
        favCount = findViewById<TextView>(R.id.count_favs)
        homeHint = findViewById<TextView>(R.id.home_hint)

        if (Session.serverName.isNotEmpty()) {
            findViewById<TextView>(R.id.hero_sub).text = getString(R.string.hero_server, Session.serverName)
        }

        bind(R.id.btn_hero) { openKind(Kind.LIVE) }
        bind(R.id.nav_live) { openKind(Kind.LIVE) }
        bind(R.id.tile_live) { openKind(Kind.LIVE) }
        bind(R.id.nav_movies) { openKind(Kind.MOVIES) }
        bind(R.id.tile_movies) { openKind(Kind.MOVIES) }
        bind(R.id.nav_series) { openSeries() }
        bind(R.id.tile_series) { openSeries() }
        bind(R.id.nav_favs) { startActivity(Intent(this, FavoritesActivity::class.java)) }
        bind(R.id.tile_favs) { startActivity(Intent(this, FavoritesActivity::class.java)) }
        bind(R.id.nav_hist) { startActivity(Intent(this, HistoryActivity::class.java)) }
        bind(R.id.nav_search) { startActivity(Intent(this, SearchActivity::class.java)) }
        bind(R.id.nav_multi) { startActivity(Intent(this, MultiViewActivity::class.java)) }
        bind(R.id.nav_info) { startActivity(Intent(this, InfoActivity::class.java)) }
        bind(R.id.nav_servers) { switchAccount() }

        histAdapter = PosterAdapter({ _ -> }, R.layout.item_poster_h) { i ->
            if (i < histList.size) openHist(histList[i])
        }
        mostAdapter = PosterAdapter({ _ -> }, R.layout.item_poster_h) { i ->
            if (i < mostList.size) openHist(mostList[i])
        }
        seriesAdapter = PosterAdapter({ _ -> }, R.layout.item_poster_h) { i ->
            if (i < seriesList.size) openDetails(Kind.SERIES, seriesList[i])
        }
        setupRow(R.id.rv_hist, histAdapter)
        setupRow(R.id.rv_most, mostAdapter)
        setupRow(R.id.rv_series, seriesAdapter)

        loadCounts()
        loadSeriesRow()
        findViewById<View>(R.id.btn_hero).requestFocus()
    }

    override fun onResume() {
        super.onResume()
        if (Session.hasSource()) refreshRows()
    }

    private fun showRow(lblId: Int, rvId: Int, visible: Boolean) {
        val v = if (visible) View.VISIBLE else View.GONE
        findViewById<View>(lblId).visibility = v
        findViewById<View>(rvId).visibility = v
    }

    private fun refreshRows() {
        favCount.text = Store.favorites(this).size.toString()
        histList = History.list(this).filter { it.kind != Kind.LIVE }.take(20)
        mostList = History.mostWatched(this, 20)
        histAdapter.items = histList.map { History.display(this, it) }
        mostAdapter.items = mostList.map { h -> History.display(this, h).copy(year = "👁 " + h.plays) }
        seriesAdapter.items = seriesList
        showRow(R.id.lbl_hist, R.id.rv_hist, histList.isNotEmpty())
        showRow(R.id.lbl_most, R.id.rv_most, mostList.isNotEmpty())
        showRow(R.id.lbl_series, R.id.rv_series, seriesList.isNotEmpty())
        val empty = histList.isEmpty() && mostList.isEmpty() && seriesList.isEmpty()
        homeHint.visibility = if (empty) View.VISIBLE else View.GONE
    }

    private fun loadSeriesRow() {
        val acc = Session.account ?: return
        val key = Store.sourceKey()
        if (Session.seriesRowKey == key && Session.seriesRow.isNotEmpty()) {
            seriesList = Session.seriesRow
            return
        }
        lifecycleScope.launch {
            try {
                val cats = XtreamApi.categories(acc, Kind.SERIES)
                val first = cats.firstOrNull() ?: return@launch
                val list = XtreamApi.entries(acc, Kind.SERIES, first.id).take(20)
                Session.seriesRow = list
                Session.seriesRowKey = key
                seriesList = list
                refreshRows()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                // the series row is optional
            }
        }
    }

    private fun showCount(k: Kind) {
        val n = Session.counts[k]
        countViews[k]?.text = if (n == null) "…" else n.toString()
    }

    private suspend fun fetchCount(k: Kind): Int {
        val sa = Session.stalker
        val acc = Session.account
        return if (sa != null) {
            StalkerApi.count(sa, k)
        } else if (acc != null) {
            XtreamApi.count(acc, k)
        } else if (Session.m3u != null) {
            Session.m3u?.list(k)?.size ?: 0
        } else {
            0
        }
    }

    private fun loadCounts() {
        val key = Store.sourceKey()
        if (Session.countsKey != key) {
            Session.counts.clear()
            Session.countsKey = key
        }
        val kinds = listOf(Kind.LIVE, Kind.MOVIES, Kind.SERIES)
        for (k in kinds) showCount(k)
        lifecycleScope.launch {
            for (k in kinds) {
                if (Session.counts.containsKey(k)) continue
                try {
                    Session.counts[k] = fetchCount(k)
                    showCount(k)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    countViews[k]?.text = "-"
                }
            }
        }
    }
}
