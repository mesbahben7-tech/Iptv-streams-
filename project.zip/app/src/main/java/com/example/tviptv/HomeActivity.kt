package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

class HomeActivity : AppCompatActivity() {

    private lateinit var recAdapter: TextAdapter
    private lateinit var favCount: TextView
    private lateinit var recentEmpty: TextView
    private var recents: List<Fav> = emptyList()
    private val countViews = HashMap<Kind, TextView>()

    private fun bind(id: Int, action: () -> Unit) {
        findViewById<View>(id).setOnClickListener { action() }
    }

    private fun openKind(kind: Kind) {
        startActivity(Intent(this, BrowseActivity::class.java).putExtra("kind", kind.name))
    }

    private fun openSeries() {
        if (Session.stalker != null) {
            Toast.makeText(this, R.string.coming_soon, Toast.LENGTH_SHORT).show()
        } else {
            openKind(Kind.SERIES)
        }
    }

    private fun openFavs() {
        startActivity(Intent(this, FavoritesActivity::class.java))
    }

    private fun switchAccount() {
        val i = Intent(this, StartActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        setContentView(R.layout.activity_home)

        countViews[Kind.LIVE] = findViewById<TextView>(R.id.count_live)
        countViews[Kind.MOVIES] = findViewById<TextView>(R.id.count_movies)
        countViews[Kind.SERIES] = findViewById<TextView>(R.id.count_series)
        favCount = findViewById<TextView>(R.id.count_favs)
        recentEmpty = findViewById<TextView>(R.id.recent_empty)

        bind(R.id.btn_hero) { openKind(Kind.LIVE) }
        bind(R.id.nav_live) { openKind(Kind.LIVE) }
        bind(R.id.tile_live) { openKind(Kind.LIVE) }
        bind(R.id.nav_movies) { openKind(Kind.MOVIES) }
        bind(R.id.tile_movies) { openKind(Kind.MOVIES) }
        bind(R.id.nav_series) { openSeries() }
        bind(R.id.tile_series) { openSeries() }
        bind(R.id.nav_favs) { openFavs() }
        bind(R.id.tile_favs) { openFavs() }
        bind(R.id.nav_info) { startActivity(Intent(this, InfoActivity::class.java)) }
        bind(R.id.nav_switch) { switchAccount() }

        val rv = findViewById<RecyclerView>(R.id.recents)
        rv.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recAdapter = TextAdapter(R.layout.item_card) { i ->
            if (i < recents.size) {
                val f = recents[i]
                Playback.play(this, f.kind, listOf(f.entry), 0)
            }
        }
        rv.adapter = recAdapter

        loadCounts()
        findViewById<View>(R.id.btn_hero).requestFocus()
    }

    override fun onResume() {
        super.onResume()
        if (!Session.hasSource()) return
        favCount.text = Store.favorites(this).size.toString()
        recents = Store.recents(this)
        recAdapter.items = recents.map { it.entry.name }
        recentEmpty.visibility = if (recents.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showCount(k: Kind) {
        val n = Session.counts[k]
        countViews[k]?.text = if (n == null) "…" else n.toString()
    }

    private suspend fun fetchCount(k: Kind): Int {
        val sa = Session.stalker
        val acc = Session.account
        return if (sa != null) {
            StalkerApi.count(sa, k)
        } else if (acc != null) {
            XtreamApi.count(acc, k)
        } else {
            0
        }
    }

    private fun loadCounts() {
        val key = Store.sourceKey()
        if (Session.countsKey != key) {
            Session.counts.clear()
            Session.countsKey = key
        }
        val kinds = listOf(Kind.LIVE, Kind.MOVIES, Kind.SERIES)
        for (k in kinds) showCount(k)
        lifecycleScope.launch {
            for (k in kinds) {
                if (Session.counts.containsKey(k)) continue
                try {
                    Session.counts[k] = fetchCount(k)
                    showCount(k)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Throwable) {
                    countViews[k]?.text = "-"
                }
            }
        }
    }
}
