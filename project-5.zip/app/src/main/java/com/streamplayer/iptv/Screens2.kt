package com.streamplayer.iptv

import android.content.SharedPreferences
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

private val PanelBg = Color(0xAA03142B)
private val BgBrush = Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF020B1B)))

fun nextPrayerText(prayers: List<Prayer>): String {
    if (prayers.isEmpty()) return ""
    val c = java.util.Calendar.getInstance(); val now = c.get(java.util.Calendar.HOUR_OF_DAY) * 60 + c.get(java.util.Calendar.MINUTE)
    fun m(t: String) = t.take(2).toIntOrNull()?.let { h -> h * 60 + (t.takeLast(2).toIntOrNull() ?: 0) } ?: -1
    val n = prayers.firstOrNull { m(it.time) > now } ?: prayers.first()
    return "${n.name} ${n.time}"
}

// ───────── معاينة مباشرة (صامتة) ─────────
@Composable
fun LivePreview(ch: Channel?, modifier: Modifier, onClick: () -> Unit = {}) {
    val ctx = LocalContext.current
    var url by remember(ch) { mutableStateOf<String?>(null) }
    LaunchedEffect(ch) { url = if (ch == null || ch.loader != null) null else runCatching { resolveUrl(ch) }.getOrNull() }
    Box(modifier.background(Color(0xFF020812)), contentAlignment = Alignment.Center) {
        val u = url
        if (u == null) Text(if (ch == null) "اختر قناة للمعاينة" else "...", color = Color(0xFF6F93BC), fontSize = 12.sp)
        else {
            val p = remember(u) { ExoPlayer.Builder(ctx).build().apply { volume = 0f; setMediaItem(MediaItem.fromUri(u)); prepare(); playWhenReady = true } }
            DisposableEffect(p) { onDispose { p.release() } }
            AndroidView(factory = { PlayerView(it).apply { useController = false } }, update = { it.player = p }, modifier = Modifier.fillMaxSize())
        }
        Box(Modifier.fillMaxSize().clickable(onClick = onClick))
    }
}

// ───────── دليل البرامج + تسجيل + معلومات ─────────
@Composable
fun EpgPanel(ch: Channel?, onPlay: (Channel) -> Unit, modifier: Modifier) {
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    var items by remember(ch) { mutableStateOf(emptyList<EpgItem>()) }
    LaunchedEffect(ch) { items = ch?.let { Repo.epgItems(it) } ?: emptyList() }
    var rec by remember { mutableStateOf<Job?>(null) }
    var recMsg by remember { mutableStateOf("") }
    var recFile by remember { mutableStateOf("") }
    var info by remember { mutableStateOf(false) }

    fun toggleRec() {
        if (rec != null) { rec?.cancel(); rec = null; recMsg = "تم إيقاف التسجيل وحفظ: $recFile"; return }
        val c = ch ?: return
        rec = scope.launch {
            try {
                var u = resolveUrl(c)
                if (u.contains("/live/") && u.endsWith(".m3u8")) u = u.removeSuffix(".m3u8") + ".ts"
                if (u.contains(".m3u8")) { recMsg = "التسجيل غير مدعوم لروابط HLS هذه"; return@launch }
                val dir = ctx.getExternalFilesDir("recordings") ?: ctx.filesDir
                val f = java.io.File(dir, c.name.replace(Regex("[^\\p{L}\\p{N}]+"), "_") + "_" + System.currentTimeMillis() + ".ts")
                recFile = f.name; recMsg = "جارٍ التسجيل..."
                recordStream(u, f)
                recMsg = "تم الحفظ: ${f.name}"
            } catch (e: CancellationException) { throw e } catch (e: Exception) { recMsg = "تعذر التسجيل: ${e.message}" }
            finally { rec = null }
        }
    }

    Column(modifier.clip(RoundedCornerShape(14.dp)).background(PanelBg).border(1.dp, Edge, RoundedCornerShape(14.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Box(Modifier.clip(RoundedCornerShape(6.dp)).border(1.dp, Color.White, RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 1.dp)) { Text("EPG", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            Text("دليل البرامج", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF071F3D)).padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(ch?.name ?: "اختر قناة", color = Color.White, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
            if (ch != null) Box(Modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFE53935)).padding(horizontal = 8.dp, vertical = 1.dp)) { Text("Live", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
        }
        if (items.isEmpty()) Text("لا تتوفر بيانات EPG لهذه القناة", color = Color(0xFF8EAAC8), fontSize = 12.sp, modifier = Modifier.weight(1f))
        else LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(items) { i, e ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(if (i == 0) Color(0xFF0B5FB8) else Color(0xFF071F3D)).padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${e.from} - ${e.to}", color = Color.White, fontSize = 12.sp)
                    Text(e.title, color = Color.White, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button({ ch?.let(onPlay) }, Modifier.weight(1f), enabled = ch != null, contentPadding = PaddingValues(4.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8))) { Text("الانتقال الآن", fontSize = 11.sp, maxLines = 1) }
            Button({ toggleRec() }, Modifier.weight(1f), enabled = ch != null, contentPadding = PaddingValues(4.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0B2347))) {
                Text(if (rec != null) "■ إيقاف" else "● تسجيل", fontSize = 11.sp, color = if (rec != null) Color.White else Color(0xFFFF5252), maxLines = 1)
            }
            Button({ info = true }, Modifier.weight(1f), enabled = ch != null, contentPadding = PaddingValues(4.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0B2347))) { Text("ⓘ معلومات", fontSize = 11.sp, maxLines = 1) }
        }
        if (recMsg.isNotBlank()) Text(recMsg, color = Color(0xFF9DC5EF), fontSize = 11.sp)
    }
    if (info && ch != null) AlertDialog(onDismissRequest = { info = false }, confirmButton = { TextButton({ info = false }) { Text("إغلاق") } }, title = { Text(ch.name) },
        text = { Text("المجموعة: ${ch.categoryName.ifBlank { "غير مصنف" }}\nالنوع: ${if (ch.type == "itv") "بث مباشر" else "محتوى حسب الطلب"}") })
}

// ───────── صف قناة ─────────
@Composable
fun ChannelRow(c: Channel, num: Int, active: Boolean, fav: Boolean, onFav: () -> Unit, onClick: () -> Unit) {
    var epgLine by remember(c) { mutableStateOf("") }
    LaunchedEffect(c) { epgLine = Repo.nowNext(c).firstOrNull() ?: "" }
    Row(Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(12.dp)).background(if (active) Color(0xFF123E83) else Color(0xAA061A35))
        .border(if (active) 2.dp else 1.dp, if (active) Accent else Color(0xFF124574), RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("%03d".format(num), color = Color(0xFF9BB9D7), fontSize = 11.sp)
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF0D2D53)), contentAlignment = Alignment.Center) {
            if (!c.logo.isNullOrBlank()) AsyncImage(c.logo, null, Modifier.fillMaxSize().padding(3.dp), contentScale = ContentScale.Fit) else Text(c.name.take(1).uppercase(), color = Accent, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1f)) {
            Text(c.name, color = Color.White, fontSize = 13.sp, maxLines = 1)
            Text(epgLine.ifBlank { c.categoryName.ifBlank { if (c.type == "itv") "Live" else "" } }, color = Color(0xFF86C8F8), fontSize = 10.sp, maxLines = 1)
        }
        Text(if (fav) "★" else "☆", color = Color(0xFFFFC107), fontSize = 20.sp, modifier = Modifier.clickable { onFav() }.padding(4.dp))
    }
}

// ───────── قائمة القنوات: TV (3 أعمدة + معاينة + EPG) / هاتف (تبويبات + معاينة + قائمة) ─────────
@Composable
fun ChannelList(
    l: List<Channel>, title: String, selected: Channel?, onBack: () -> Unit, onSelect: (Channel) -> Unit,
    phoneHome: Boolean = false, hint: String = "", onTab: (String) -> Unit = {}, onNav: (String) -> Unit = {},
    onPlay: (Channel) -> Unit
) {
    val wide = LocalConfiguration.current.screenWidthDp >= 800
    val ctx = LocalContext.current
    val pr = remember { ctx.getSharedPreferences("p", 0) }
    var favs by remember { mutableStateOf(Favs.all(pr)) }
    var q by remember { mutableStateOf("") }
    var group by remember { mutableStateOf("الكل") }
    var byCountry by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }

    fun gkey(c: Channel): String { val n = c.categoryName.trim(); return if (byCountry && n.contains("|")) n.substringBefore("|").trim() else n }
    val counts = remember(l, byCountry) { l.groupingBy { gkey(it) }.eachCount() }
    val groups = remember(l, counts, favs) {
        listOf("الكل") + (if (favs.isNotEmpty()) listOf("المفضلة") else emptyList()) +
            counts.keys.filter { it.isNotBlank() && it != "غير مصنف" } +
            (if ((counts[""] ?: 0) + (counts["غير مصنف"] ?: 0) > 0) listOf("غير مصنف") else emptyList())
    }
    fun belongs(c: Channel, g: String): Boolean = when (g) {
        "الكل" -> true
        "المفضلة" -> Favs.key(c) in favs
        "غير مصنف" -> gkey(c).isBlank() || gkey(c) == "غير مصنف"
        else -> gkey(c) == g
    }
    fun countOf(g: String): Int = when (g) {
        "الكل" -> l.size
        "المفضلة" -> l.count { Favs.key(it) in favs }
        "غير مصنف" -> (counts[""] ?: 0) + (counts["غير مصنف"] ?: 0)
        else -> counts[g] ?: 0
    }
    val shown = remember(l, q, group, byCountry, favs) { l.filter { belongs(it, group) && (q.isBlank() || it.name.contains(q, ignoreCase = true)) } }
    fun previewable(c: Channel) = c.type == "itv" && c.loader == null
    fun click(c: Channel) { if (!previewable(c) || selected == c) onPlay(c) else onSelect(c) }
    fun toggleFav(c: Channel) { Favs.toggle(pr, c); favs = Favs.all(pr) }
    val searchColors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Edge, focusedTextColor = Color.White, unfocusedTextColor = Color.White)

    if (wide) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.fillMaxSize().background(BgBrush).padding(14.dp)) {
                TopBar(onBack, title)
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.width(200.dp).fillMaxHeight().clip(RoundedCornerShape(16.dp)).background(PanelBg).border(1.dp, Edge, RoundedCornerShape(16.dp)).padding(8.dp)) {
                        Text("قنوات مباشرة", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(8.dp))
                        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("الباقات" to false, "البلدان" to true).forEach { (t, v) ->
                                Box(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (byCountry == v) Color(0xFF0879D8) else Color(0xFF071F3D))
                                    .clickable { byCountry = v; group = "الكل" }.padding(vertical = 7.dp), contentAlignment = Alignment.Center) { Text(t, color = Color.White, fontSize = 12.sp) }
                            }
                        }
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(groups) { g ->
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(if (group == g) Color(0xFF0879D8) else Color.Transparent)
                                    .clickable { group = g }.padding(horizontal = 10.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(g, color = Color.White, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
                                    Text(countOf(g).toString(), color = Color(0xFF9ED7FF), fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    Column(Modifier.weight(1f).fillMaxHeight()) {
                        OutlinedTextField(q, { q = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("بحث عن قناة...", color = Color(0xFF91ACCA)) }, leadingIcon = { Text("⌕", color = Accent, fontSize = 22.sp) }, colors = searchColors)
                        Spacer(Modifier.height(8.dp))
                        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            itemsIndexed(shown) { i, c -> ChannelRow(c, i + 1, selected == c, Favs.key(c) in favs, { toggleFav(c) }) { click(c) } }
                        }
                    }
                    Column(Modifier.weight(1.15f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LivePreview(selected, Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp)).border(1.dp, Edge, RoundedCornerShape(12.dp))) { selected?.let(onPlay) }
                        EpgPanel(selected, onPlay, Modifier.fillMaxWidth().weight(1f))
                    }
                }
            }
        }
    } else {
        val showPreview = phoneHome || l.firstOrNull { it.loader == null }?.type == "itv"
        Column(Modifier.fillMaxSize().background(BgBrush).padding(horizontal = 12.dp, vertical = 10.dp)) {
            TopBar(if (phoneHome) null else onBack, if (phoneHome && hint.isNotBlank()) hint else title, onSearch = { showSearch = !showSearch })
            if (phoneHome) Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("قنوات" to "live", "أفلام" to "movies", "مسلسلات" to "series").forEach { (t, k) ->
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (k == "live") Color(0xFF0879D8) else Color(0xFF0B2347))
                        .clickable { if (k != "live") onTab(k) }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) { Text(t, color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
            if (showSearch) OutlinedTextField(q, { q = it }, modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp), singleLine = true, placeholder = { Text("بحث عن قناة...", color = Color(0xFF91ACCA)) }, colors = searchColors)
            LazyRow(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(groups) { g ->
                    Box(Modifier.clip(RoundedCornerShape(50)).background(if (group == g) Color(0xFF0879D8) else Color(0xFF0B2347)).clickable { group = g }.padding(horizontal = 14.dp, vertical = 7.dp)) {
                        Text("$g ${countOf(g)}", color = Color.White, fontSize = 12.sp, maxLines = 1)
                    }
                }
            }
            if (showPreview) LivePreview(selected, Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp)).border(1.dp, Edge, RoundedCornerShape(12.dp))) { selected?.let(onPlay) }
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(shown) { i, c -> ChannelRow(c, i + 1, selected == c, Favs.key(c) in favs, { toggleFav(c) }) { click(c) } }
            }
            if (phoneHome) Row(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF07204A)).border(1.dp, Edge, RoundedCornerShape(16.dp)).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf(Triple("home", "الرئيسية", "⌂"), Triple("multi", "متعدد", "▦"), Triple("favs", "المفضلة", "☆"), Triple("settings", "الإعدادات", "⚙")).forEach { (k, n, ic) ->
                    Column(Modifier.clickable { if (k != "home") onNav(k) }.padding(horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(ic, color = if (k == "home") Accent else Color(0xFF9BB8DA), fontSize = 20.sp)
                        Text(n, color = if (k == "home") Accent else Color(0xFF9BB8DA), fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

// ───────── الأفلام والمسلسلات: بطاقات الملصقات ─────────
@Composable
fun Poster(c: Channel, onPlay: (Channel) -> Unit) {
    val r = c.rating.toDoubleOrNull()?.takeIf { it > 0 }?.let { "%.1f".format(it) }
    Column(Modifier.width(118.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xAA061A35)).border(1.dp, Edge, RoundedCornerShape(12.dp)).clickable { onPlay(c) }) {
        Box(Modifier.fillMaxWidth().aspectRatio(0.68f).background(Color(0xFF0D2D53)), contentAlignment = Alignment.Center) {
            if (!c.logo.isNullOrBlank()) AsyncImage(c.logo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Text(c.name.take(1).uppercase(), color = Accent, fontSize = 30.sp)
        }
        Column(Modifier.padding(8.dp)) {
            Text(c.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 2)
            Row(Modifier.fillMaxWidth().padding(top = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(c.year, color = Color(0xFF9BB8DA), fontSize = 11.sp)
                if (r != null) Text("★ $r", color = Color(0xFFFFC107), fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun PosterSection(title: String, list: List<Channel>, onMore: () -> Unit, onPlay: (Channel) -> Unit) {
    if (list.isEmpty()) return
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("المزيد", color = Accent, fontSize = 12.sp, modifier = Modifier.clickable { onMore() }.padding(4.dp))
    }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(list) { Poster(it, onPlay) } }
}

@Composable
fun BrowseScreen(kind0: String, onPlay: (Channel) -> Unit, onMore: (String) -> Unit, onGenre: (String, List<Channel>) -> Unit, onBack: () -> Unit) {
    var tab by remember { mutableStateOf(kind0) }
    val src = if (tab == "series") Repo.series else Repo.movies
    Column(Modifier.fillMaxSize().background(BgBrush).padding(14.dp)) {
        TopBar(onBack, onSearch = { onMore(if (tab == "series") "series" else "movies") })
        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("الأفلام" to "movies", "المسلسلات" to "series", "الأنواع" to "genres").forEach { (t, k) ->
                Box(Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(if (tab == k) Color(0xFF0879D8) else Color(0xFF0B2347)).clickable { tab = k }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    Text(t, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (tab == "genres") {
            val all = Repo.movies + Repo.series
            val names = remember(all) { all.map { it.categoryName.trim() }.filter { it.isNotBlank() }.distinct() }
            if (names.isEmpty()) Text("لا توجد أنواع متاحة بعد", color = Color(0xFF8AAAD2))
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(names) { n ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0xAA061A35)).border(1.dp, Edge, RoundedCornerShape(12.dp))
                        .clickable { onGenre(n, all.filter { it.categoryName.trim() == n }) }.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(n, color = Color.White, fontSize = 14.sp); Text("›", color = Accent, fontSize = 18.sp)
                    }
                }
            }
        } else {
            val newest = remember(src) { src.sortedByDescending { it.year }.take(14) }
            val top = remember(src) { src.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }.take(14) }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (src.isEmpty()) Text("لا يوجد محتوى بعد، أضف مصدراً من الإعدادات", color = Color(0xFF8AAAD2))
                if (tab == "series") {
                    PosterSection("المسلسلات الأكثر متابعة", top, { onMore("series") }, onPlay)
                    PosterSection("أحدث المسلسلات", newest, { onMore("series") }, onPlay)
                } else {
                    PosterSection("الأفلام الجديدة", newest, { onMore("movies") }, onPlay)
                    PosterSection("الأعلى تقييماً", top, { onMore("movies") }, onPlay)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF07204A)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("مشاهدة بلا حدود ... في أي وقت وأي مكان", color = Color.White, fontSize = 12.sp)
            Text("Android TV • TV Box • Phone", color = Color(0xFF9BB8DA), fontSize = 10.sp)
        }
    }
}

// ───────── مشاهدة عدة قنوات ─────────
@Composable
fun MultiCell(ch: Channel?, selected: Boolean, num: Int, modifier: Modifier, onClick: () -> Unit) {
    val ctx = LocalContext.current
    var url by remember(ch) { mutableStateOf<String?>(null) }
    LaunchedEffect(ch) { url = ch?.let { runCatching { resolveUrl(it) }.getOrNull() } }
    Box(modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF020812)).border(if (selected) 2.dp else 1.dp, if (selected) Accent else Edge, RoundedCornerShape(10.dp))) {
        val u = url
        if (u != null) {
            val p = remember(u) { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(u)); prepare(); playWhenReady = true } }
            DisposableEffect(p) { onDispose { p.release() } }
            LaunchedEffect(p, selected) { p.volume = if (selected) 1f else 0f }
            AndroidView(factory = { PlayerView(it).apply { useController = false } }, update = { it.player = p }, modifier = Modifier.fillMaxSize())
        } else Text(if (ch == null) "＋ إضافة قناة" else "...", color = Color(0xFF6F93BC), fontSize = 13.sp, modifier = Modifier.align(Alignment.Center))
        Box(Modifier.fillMaxSize().clickable(onClick = onClick))
        if (ch != null) Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Color(0x99000000)).padding(horizontal = 8.dp, vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(ch.name, color = Color.White, fontSize = 11.sp, maxLines = 1, modifier = Modifier.weight(1f))
            Text("%03d".format(num), color = Color.White, fontSize = 11.sp)
        }
    }
}

@Composable
fun MultiViewScreen(onBack: () -> Unit, onSetup: () -> Unit, onFavs: () -> Unit, onGuide: () -> Unit) {
    val ctx = LocalContext.current
    val pr = remember { ctx.getSharedPreferences("p", 0) }
    var layout by remember { mutableStateOf("2x2") }
    val slots = remember { mutableStateListOf<Channel?>(null, null, null, null) }
    var active by remember { mutableStateOf(0) }
    var picking by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    val count = when (layout) { "2x2" -> 4; "2x1", "1x2" -> 2; else -> 1 }
    val cell: @Composable (Int, Modifier) -> Unit = { i, m ->
        MultiCell(slots[i], i == active, i + 1, m) { active = i; if (slots[i] == null) picking = true }
    }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().background(BgBrush).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            TopBar(onBack, "مشاهدة عدة قنوات")
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when (layout) {
                    "2x2" -> {
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { cell(0, Modifier.weight(1f).fillMaxHeight()); cell(1, Modifier.weight(1f).fillMaxHeight()) }
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { cell(2, Modifier.weight(1f).fillMaxHeight()); cell(3, Modifier.weight(1f).fillMaxHeight()) }
                    }
                    "2x1" -> Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) { cell(0, Modifier.weight(1f).fillMaxHeight()); cell(1, Modifier.weight(1f).fillMaxHeight()) }
                    "1x2" -> { cell(0, Modifier.weight(1f).fillMaxWidth()); cell(1, Modifier.weight(1f).fillMaxWidth()) }
                    else -> cell(0, Modifier.weight(1f).fillMaxWidth())
                }
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("إدارة التعدد", color = Color(0xFF9BB8DA), fontSize = 11.sp)
                listOf("2x2", "2x1", "1x2", "1x1").forEach { k ->
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF0B2347)).border(if (layout == k) 2.dp else 1.dp, if (layout == k) Accent else Edge, RoundedCornerShape(8.dp))
                        .clickable { layout = k; if (active >= when (k) { "2x2" -> 4; "2x1", "1x2" -> 2; else -> 1 }) active = 0 }.padding(horizontal = 10.dp, vertical = 8.dp)) {
                        Text(k, color = Color.White, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.weight(1f))
                Button({ val e = slots.take(count).indexOfFirst { it == null }; if (e >= 0) active = e; picking = true }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0879D8)), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) { Text("إضافة قناة +", fontSize = 12.sp) }
            }
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xAA03142B)).border(1.dp, Edge, RoundedCornerShape(14.dp)).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                ActionBtn("▤", "دعم M3U") { onSetup() }
                ActionBtn("≋", "Xtream Codes") { onSetup() }
                ActionBtn("◉", "Stalker") { onSetup() }
                ActionBtn("CC", "ترجمة عربية") { SubPrefs.save(pr, SubPrefs.load(pr).copy(enabled = true, lang = "ar")); note = "تم تفعيل الترجمة العربية (إن وُجدت داخل البث)" }
                ActionBtn("▦", "دليل البرامج") { onGuide() }
                ActionBtn("★", "المفضلة") { onFavs() }
            }
            Text(note.ifBlank { "كل ما تحب في مكان واحد" }, color = Color(0xFF9DC5EF), fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
        if (picking) Column(Modifier.fillMaxSize().background(Color(0xFF020B1B)).padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(q, { q = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("اختر قناة...") })
                Text("✕", color = Accent, fontSize = 26.sp, modifier = Modifier.clickable { picking = false }.padding(8.dp))
            }
            val found = remember(q) { Repo.live.filter { q.isBlank() || it.name.contains(q, ignoreCase = true) }.take(300) }
            LazyColumn(Modifier.fillMaxSize().padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(found) { i, c ->
                    ChannelRow(c, i + 1, false, false, {}) { slots[active] = c; picking = false; q = "" }
                }
            }
        }
    }
}
