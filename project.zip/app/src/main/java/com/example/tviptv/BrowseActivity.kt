package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class BrowseActivity : AppCompatActivity() {

    private lateinit var kind: Kind
    private var poster = false
    private lateinit var status: TextView
    private lateinit var rvCats: RecyclerView
    private lateinit var rvCh: RecyclerView
    private lateinit var catAdapter: TextAdapter
    private lateinit var chAdapter: TextAdapter
    private lateinit var posterAdapter: PosterAdapter
    private var cats: List<Category> = emptyList()
    private var entries: List<Entry> = emptyList()
    private var favIds: Set<String> = emptySet()
    private var loadJob: Job? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        kind = Kind.valueOf(intent.getStringExtra("kind") ?: Kind.LIVE.name)
        poster = kind != Kind.LIVE
        favIds = Store.favIds(this, kind)
        setContentView(R.layout.activity_channels)
        status = findViewById(R.id.status)
        rvCats = findViewById(R.id.categories)
        rvCh = findViewById(R.id.channels)

        catAdapter = TextAdapter { i -> loadEntries(cats[i]) }
        chAdapter = TextAdapter(onLongClick = { i -> toggleFav(i) }) { i -> onEntryClick(i) }
        posterAdapter = PosterAdapter({ i -> toggleFav(i) }) { i -> onEntryClick(i) }
        posterAdapter.favIds = favIds

        rvCats.layoutManager = LinearLayoutManager(this)
        rvCats.adapter = catAdapter
        if (poster) {
            val dm = resources.displayMetrics
            val widthDp = dm.widthPixels / dm.density
            val span = ((widthDp * 0.62f) / 150f).toInt().coerceAtLeast(2)
            rvCh.layoutManager = GridLayoutManager(this, span)
            rvCh.adapter = posterAdapter
        } else {
            rvCh.layoutManager = LinearLayoutManager(this)
            rvCh.adapter = chAdapter
        }

        val hp = getSharedPreferences("app", MODE_PRIVATE)
        if (!hp.getBoolean("fav_hint", false)) {
            Toast.makeText(this, R.string.fav_hint, Toast.LENGTH_LONG).show()
            hp.edit().putBoolean("fav_hint", true).apply()
        }

        showStatus(getString(R.string.connecting))
        lifecycleScope.launch {
            try {
                val list = fetchCategories()
                cats = listOf(Category("", getString(R.string.all))) + list
                catAdapter.items = cats.map { it.name }
                status.visibility = View.GONE
                rvCats.post { rvCats.requestFocus() }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showStatus(getString(R.string.load_error, e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private fun label(e: Entry): String = if (favIds.contains(e.id)) "★ " + e.name else e.name

    private fun setList() {
        if (poster) posterAdapter.items = entries else chAdapter.items = entries.map { label(it) }
    }

    private fun appendList(more: List<Entry>) {
        if (poster) posterAdapter.append(more) else chAdapter.append(more.map { label(it) })
    }

    private fun refreshItem(i: Int) {
        if (poster) {
            posterAdapter.favIds = favIds
            posterAdapter.refresh(i)
        } else {
            chAdapter.update(i, label(entries[i]))
        }
    }

    private fun toggleFav(i: Int) {
        if (i >= entries.size) return
        val e = entries[i]
        val now = Store.toggleFav(this, kind, e)
        favIds = if (now) favIds + e.id else favIds - e.id
        refreshItem(i)
        Toast.makeText(this, if (now) R.string.fav_added else R.string.fav_removed, Toast.LENGTH_SHORT).show()
    }

    private suspend fun fetchCategories(): List<Category> {
        val sa = Session.stalker
        val acc = Session.account
        return if (sa != null) {
            StalkerApi.categories(sa, kind)
        } else if (acc != null) {
            XtreamApi.categories(acc, kind)
        } else {
            emptyList()
        }
    }

    private fun onEntryClick(i: Int) {
        if (i >= entries.size) return
        val e = entries[i]
        if (kind == Kind.LIVE) {
            Playback.play(this, Kind.LIVE, entries, i)
        } else {
            Session.detail = Fav(kind, e)
            startActivity(Intent(this, DetailsActivity::class.java))
        }
    }

    private fun showStatus(msg: String) {
        status.text = msg
        status.visibility = View.VISIBLE
    }

    private fun showEntries() {
        setList()
        rvCh.scrollToPosition(0)
        if (entries.isEmpty()) {
            showStatus(getString(R.string.no_items))
        } else {
            status.visibility = View.GONE
            rvCh.post { rvCh.requestFocus() }
        }
    }

    private fun loadEntries(cat: Category) {
        loadJob?.cancel()
        showStatus(getString(R.string.connecting))
        loadJob = lifecycleScope.launch {
            try {
                val sa = Session.stalker
                val acc = Session.account
                if (sa != null) {
                    loadStalker(sa, cat)
                } else if (acc != null) {
                    entries = XtreamApi.entries(acc, kind, cat.id)
                    showEntries()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                showStatus(getString(R.string.load_error, e.message ?: e.javaClass.simpleName))
            }
        }
    }

    private suspend fun loadStalker(sa: StalkerAccount, cat: Category) {
        val type = if (kind == Kind.LIVE) "itv" else "vod"
        val catId = if (cat.id.isEmpty()) "*" else cat.id
        entries = emptyList()
        setList()
        val collected = mutableListOf<Entry>()
        var p = 1
        while (p <= 100) {
            val pg = StalkerApi.page(sa, type, catId, p)
            if (pg.items.isEmpty()) break
            collected.addAll(pg.items)
            appendList(pg.items)
            entries = collected.toList()
            if (p == 1) {
                status.visibility = View.GONE
                rvCh.post { rvCh.requestFocus() }
            }
            if (pg.total <= 0 || collected.size >= pg.total) break
            p++
        }
        if (collected.isEmpty() && kind == Kind.LIVE) {
            val all = StalkerApi.allChannels(sa)
            entries = if (cat.id.isEmpty()) all else all.filter { it.group == cat.id }
            showEntries()
            return
        }
        if (collected.isEmpty()) showStatus(getString(R.string.no_items))
    }
}
