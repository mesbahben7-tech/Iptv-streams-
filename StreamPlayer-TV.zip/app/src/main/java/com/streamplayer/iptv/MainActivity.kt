package com.streamplayer.iptv

import android.content.SharedPreferences
import android.os.Bundle
import java.util.Calendar
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.*
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.launch

val Bg = Color(0xFF0A1830); val Card = Color(0xFF10264A); val Edge = Color(0xFF1E3F73); val Accent = Color(0xFF16B8FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val tv = detectTv(this)
        setContent { CompositionLocalProvider(LocalIsTv provides tv) { App(getSharedPreferences("p", 0)) } }
    }
}

@Composable
fun App(pr: SharedPreferences) {
    var screen by remember { mutableStateOf("home") }
    var list by remember { mutableStateOf(listOf<Channel>()) }
    var listTitle by remember { mutableStateOf("القنوات") }
    var playing by remember { mutableStateOf<String?>(null) }
    var msg by remember { mutableStateOf("") }
    var selectedChannel by remember { mutableStateOf<Channel?>(null) }
    var browseKind by remember { mutableStateOf("movies") }
    val isWide = isWideScreen()
    val scope = rememberCoroutineScope()
    var city by remember { mutableStateOf(pr.getString("city", "Algiers")!!) }
    var country by remember { mutableStateOf(pr.getString("country", "Algeria")!!) }
    var prayers by remember { mutableStateOf(listOf<Prayer>()) }
    var epgNow by remember { mutableStateOf(listOf<String>()) }
    LaunchedEffect(city, country) {
        val fetched = runCatching { prayerTimes(city, country) }.getOrDefault(emptyList())
        val keys = mapOf("الفجر" to "fajr", "الظهر" to "dhuhr", "العصر" to "asr", "المغرب" to "maghrib", "العشاء" to "isha")
        val base = fetched.ifEmpty { keys.keys.map { Prayer(it, "--:--") } }
        prayers = base.map { p -> Prayer(p.name, pr.getString("prayer_${keys[p.name]}", null)?.takeIf { it.matches(Regex("\\d{2}:\\d{2}")) } ?: p.time) }
    }

    suspend fun load(s: Source) {
        msg = try { Repo.load(s); "تم تحميل قائمة القنوات بنجاح" } catch (e: Exception) { "خطأ: ${e.message}" }
    }
    LaunchedEffect(Unit) {
        pr.getString("t", null)?.let { load(Source(it, pr.getString("a", "")!!, pr.getString("b", "")!!, pr.getString("c", "")!!)) }
    }
    suspend fun playChannel(c: Channel) {
        try {
            epgNow = Repo.nowNext(c)
            selectedChannel = c
            playing = c.cmd?.let { Repo.stalker?.resolve(it, c.type, c.ep) } ?: c.url
            Recent.add(pr, c)
        } catch (e: Exception) { msg = "خطأ: ${e.message}" }
    }
    fun stepChannel(d: Int) {
        val cur = selectedChannel ?: return
        val i = list.indexOf(cur)
        val n = list.getOrNull(i + d)?.takeIf { i >= 0 && it.loader == null } ?: return
        scope.launch { playChannel(n) }
    }
    suspend fun openItem(c: Channel) {
        val ld = c.loader
        if (ld != null) {
            listTitle = c.name
            list = try { ld() } catch (e: Exception) { msg = "خطأ: ${e.message}"; list }
            selectedChannel = null; screen = "list"
        } else playChannel(c)
    }
    BackHandler(screen != "home" || playing != null) { if (playing != null) playing = null else screen = "home" }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Card, primary = Accent)) {
            Box(Modifier.fillMaxSize().background(Bg)) {
                when {
                    playing != null -> PlayerScreen(playing!!, selectedChannel, epgNow, pr, onBack = { playing = null },
                        onPrev = { stepChannel(-1) }, onNext = { stepChannel(1) },
                        nextName = selectedChannel?.let { cur -> val i = list.indexOf(cur); if (i >= 0) list.getOrNull(i + 1)?.takeIf { it.loader == null }?.name else null })
                    screen == "home" && !isWide -> ChannelList(Repo.live, "الرئيسية", selectedChannel, onBack = {}, onSelect = { selectedChannel = it },
                        phoneHome = true, hint = nextPrayerText(prayers),
                        onTab = { k -> browseKind = k; screen = "browse" },
                        onNav = { k -> screen = k },
                        onPlay = { c -> scope.launch { playChannel(c) } })
                    screen == "home" -> Home(msg, prayers, { k ->
                        if (k == "setup") { screen = "setup" } else if (k == "favorites") { screen = "favs" } else if (k == "multi") { screen = "multi" } else if (k == "movies" || k == "series") { browseKind = k; screen = "browse" } else {
                            listTitle = when (k) { "live" -> "البث المباشر"; "movies" -> "الأفلام"; "recent" -> "آخر مشاهدة"; else -> "المسلسلات" }
                            list = when (k) { "live" -> Repo.live; "movies" -> Repo.movies; "recent" -> Recent.load(pr); else -> Repo.series }
                            screen = "list"
                        }
                    }, { screen = "settings" }, { screen = "setup" })
                    screen == "settings" -> SettingsScreen(city, country, prayers,
                        onSave = { c1, k1, times ->
                            city = c1; country = k1
                            pr.edit().putString("city", c1).putString("country", k1)
                                .putString("prayer_fajr", times.first { it.name == "الفجر" }.time)
                                .putString("prayer_dhuhr", times.first { it.name == "الظهر" }.time)
                                .putString("prayer_asr", times.first { it.name == "العصر" }.time)
                                .putString("prayer_maghrib", times.first { it.name == "المغرب" }.time)
                                .putString("prayer_isha", times.first { it.name == "العشاء" }.time).apply()
                            prayers = times
                        },
                        onSource = { screen = "setup" }, onServer = { screen = "server" }, onBack = { screen = "home" })
                    screen == "server" -> ServerInfoScreen(pr, msg, onBack = { screen = "settings" }, onEdit = { screen = "setup" }, onRefresh = {
                        pr.getString("t", null)?.let { t0 -> scope.launch { msg = "جارٍ التحميل..."; load(Source(t0, pr.getString("a", "")!!, pr.getString("b", "")!!, pr.getString("c", "")!!)) } }
                    })
                    screen == "favs" -> FavoritesScreen(onPlay = { c -> scope.launch { playChannel(c) } },
                        onManage = { listTitle = "البث المباشر"; list = Repo.live; screen = "list" }, onBack = { screen = "home" })
                    screen == "browse" -> BrowseScreen(browseKind, onPlay = { c -> scope.launch { openItem(c) } },
                        onMore = { k -> listTitle = if (k == "series") "المسلسلات" else "الأفلام"; list = if (k == "series") Repo.series else Repo.movies; screen = "list" },
                        onGenre = { n, l2 -> listTitle = n; list = l2; screen = "list" }, onBack = { screen = "home" })
                    screen == "multi" -> MultiViewScreen(onBack = { screen = "home" }, onSetup = { screen = "setup" }, onFavs = { screen = "favs" },
                        onGuide = { listTitle = "البث المباشر"; list = Repo.live; screen = "list" })
                    screen == "setup" -> Setup(city, country, onBack = { screen = "home" }) { s, c1, k1 ->
                        city = c1; country = k1
                        pr.edit().putString("city", c1).putString("country", k1).apply()
                        if (s.a.isNotBlank()) pr.edit().putString("t", s.type).putString("a", s.a).putString("b", s.b).putString("c", s.c).apply()
                        screen = "home"; if (s.a.isNotBlank()) scope.launch { msg = "جارٍ التحميل..."; load(s) }
                    }
                    else -> ChannelList(list, listTitle, selectedChannel, onBack = { screen = "home" }, onSelect = { selectedChannel = it }, onNav = { k -> screen = k }) { c ->
                        scope.launch {
                            val ld = c.loader
                            if (ld != null) {
                                listTitle = c.name
                                list = try { ld() } catch (e: Exception) { msg = "خطأ: ${e.message}"; list }
                                selectedChannel = null
                            } else {
                                try {
                                    epgNow = Repo.nowNext(c)
                                    selectedChannel = c
                                    playing = c.cmd?.let { Repo.stalker?.resolve(it, c.type, c.ep) } ?: c.url
                                    Recent.add(pr, c)
                                } catch (e: Exception) { msg = "خطأ: ${e.message}" }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Tile(mod: Modifier, onClick: () -> Unit, content: @Composable BoxScope.() -> Unit) {
    var f by remember { mutableStateOf(false) }
    val sh = RoundedCornerShape(16.dp)
    Box(mod.clip(sh).background(Card).border(if (f) 3.dp else 1.dp, if (f) Accent else Edge, sh)
        .onFocusChanged { f = it.isFocused }.clickable(onClick = onClick), content = content)
}

@Composable
fun Home(msg: String, prayers: List<Prayer>, onOpen: (String) -> Unit, onSetup: () -> Unit, onAddServer: () -> Unit) {
    var clock by remember { mutableStateOf(Calendar.getInstance()) }
    LaunchedEffect(Unit) {
        while (true) {
            clock = Calendar.getInstance()
            kotlinx.coroutines.delay(30_000)
        }
    }
    val wide = isWideScreen()
    // شاشات التلفاز القصيرة (540dp عند 1080p): نصغّر الأقسام الثابتة كي تبقى البطاقات ظاهرة بالكامل
    val compact = wide && androidx.compose.ui.platform.LocalConfiguration.current.screenHeightDp < 620
    val loc = java.util.Locale.Builder().setLanguage("ar").setUnicodeLocaleKeyword("nu", "latn").build()
    val timeText = java.text.SimpleDateFormat("HH:mm", loc).format(clock.time)
    val dateText = java.text.SimpleDateFormat("EEEE d MMMM yyyy", loc).format(clock.time)
    val nowMins = clock.get(Calendar.HOUR_OF_DAY) * 60 + clock.get(Calendar.MINUTE)
    fun mins(t: String): Int = runCatching { t.take(2).toInt() * 60 + t.takeLast(2).toInt() }.getOrDefault(0)
    val nextPrayer = prayers.firstOrNull { mins(it.time) > nowMins } ?: prayers.firstOrNull()
    val prayerNames = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

    @Composable fun PrayerPanel(modifier: Modifier = Modifier) {
        Row(modifier, horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Tile(Modifier.weight(1f).height(if (compact) 92.dp else if (wide) 108.dp else 118.dp), {}) {
                Image(painterResource(R.drawable.prayer_mosque_art), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xCC06142C), Color(0xAA06142C), Color(0xEE06142C)))))
                Row(Modifier.fillMaxSize().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Column(Modifier.width(if (wide) 150.dp else 105.dp), verticalArrangement = Arrangement.Center) {
                        Text("☾", color = Accent, fontSize = 27.sp)
                        Text("مواقيت الصلاة", color = Color.White, fontSize = if (wide) 17.sp else 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("📍 الجزائر⌄", color = Color(0xFF9DC5EF), fontSize = 12.sp, maxLines = 1)
                    }
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val displayPrayers = if (prayers.isEmpty()) prayerNames.map { Prayer(it, "--:--") } else prayers
                        displayPrayers.take(5).forEach { p ->
                            val active = p.name == nextPrayer?.name
                            Column(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(10.dp))
                                .background(if (active) Color(0xFF153C63) else Color(0x66102B50))
                                .border(if (active) 1.5.dp else 1.dp, if (active) Color(0xFFFFA726) else Color(0xFF174D82), RoundedCornerShape(10.dp))
                                .padding(horizontal = 2.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(when (p.name) { "الفجر" -> "☀"; "الظهر" -> "☼"; "العصر" -> "☀"; "المغرب" -> "◒"; else -> "☾" }, color = if (active) Color(0xFFFFA726) else Accent, fontSize = 20.sp)
                                Text(p.name, color = Color.White, fontSize = if (wide) 12.sp else 10.sp, maxLines = 1)
                                Text(p.time, color = if (active) Color(0xFFFFB74D) else Color.White, fontSize = if (wide) 14.sp else 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            }
                        }
                    }
                }
            }
            if (wide) Tile(Modifier.weight(0.34f).height(if (compact) 92.dp else 108.dp), onSetup) {
                Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.prayer_mecca_art), null, Modifier.fillMaxHeight().aspectRatio(1.1f).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        Text(nextPrayer?.name ?: "المغرب", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("◷ ${nextPrayer?.time ?: "--:--"}", color = Color(0xFF36D5FF), fontSize = 15.sp)
                    }
                    Text("›", color = Accent, fontSize = 34.sp)
                }
            } else
            Tile(Modifier.width(112.dp).height(118.dp), onSetup) {
                Image(painterResource(R.drawable.prayer_mecca_art), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xDD06142C), Color(0x55102B50)))))
                Row(Modifier.fillMaxSize().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                        Text("الصلاة القادمة", color = Color(0xFF9DC5EF), fontSize = if (wide) 11.sp else 9.sp, maxLines = 1)
                        Text(nextPrayer?.name ?: "المغرب", color = Color(0xFF36D5FF), fontSize = if (wide) 18.sp else 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                        Text("◷ ${nextPrayer?.time ?: "--:--"}", color = Color.White, fontSize = if (wide) 14.sp else 11.sp)
                    }
                    if (wide) Text("›", color = Accent, fontSize = 30.sp)
                }
            }
        }
    }

    @Composable fun FeaturePanel(modifier: Modifier = Modifier) {
        Tile(modifier.height(if (compact) 116.dp else if (wide) 150.dp else 155.dp), {}) {
            Row(Modifier.fillMaxSize().padding(if (wide) 12.dp else 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(if (wide) 1.0f else 0.7f).fillMaxHeight().clip(RoundedCornerShape(12.dp))) {
                    Image(painterResource(R.drawable.home_hero_art), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0x2206142C), Color(0x6606142C), Color(0xEE06142C)))))
                }
                Column(Modifier.weight(if (wide) 1.35f else 1.0f), verticalArrangement = Arrangement.Center) {
                    Text("شاهد كل ما تحب", color = Color.White, fontSize = if (wide) 24.sp else 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(5.dp))
                    Text("قنواتك وأفلامك ومسلسلاتك في مكان واحد", color = Color(0xFFB8D2F1), fontSize = if (wide) 14.sp else 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                if (wide) Row(Modifier.weight(2.3f).fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(Color(0xFF14C3FF), Color(0xFF0A8FE0))))
                        .focusHighlight(RoundedCornerShape(18.dp)).clickable(onClick = onAddServer), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("▶", color = Color.White, fontSize = 34.sp)
                            Text("ابدأ الآن", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(18.dp)).background(Color(0xFF0E2A55))
                        .focusHighlight(RoundedCornerShape(18.dp)).clickable { onOpen("recent") }, contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("◷", color = Color(0xFF9CCFFF), fontSize = 34.sp)
                            Text("آخر مشاهدة", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                } else Column(Modifier.weight(0.85f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onAddServer, modifier = Modifier.fillMaxWidth().height(if (wide) 54.dp else 44.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF08AEEF)), contentPadding = PaddingValues(horizontal = 8.dp)) {
                        Text("▶  ابدأ الآن", color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (wide) 16.sp else 12.sp, maxLines = 1)
                    }
                    OutlinedButton(onClick = { onOpen("recent") }, modifier = Modifier.fillMaxWidth().height(if (wide) 48.dp else 42.dp), shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, Color(0xFF1A5B99)), contentPadding = PaddingValues(horizontal = 4.dp)) {
                        Text("◷  آخر مشاهدة", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = if (wide) 14.sp else 11.sp, maxLines = 1)
                    }
                }
            }
        }
    }

    @Composable fun CategoryCard(title: String, key: String, glyph: String, art: List<Color>, modifier: Modifier = Modifier) {
        Tile(modifier, { onOpen(key) }) {
            val artRes = when (key) {
                "live" -> R.drawable.home_live_art
                "movies" -> R.drawable.home_movies_art
                else -> R.drawable.home_series_art
            }
            Image(painterResource(artRes), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x22000B1D), Color(0xCC031027), Color(0xF0031027)))))
            val iconRes = when (key) { "live" -> R.drawable.ic_live; "movies" -> R.drawable.ic_movies; else -> R.drawable.ic_series }
            Image(painterResource(iconRes), null, Modifier.align(Alignment.Center).offset(y = (-15).dp).size(if (wide) 72.dp else 44.dp))
            Text(title, color = Color.White, fontSize = if (wide) 22.sp else 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 15.dp))
            Text("›", color = Color(0xFF8CCBFF), fontSize = 32.sp, modifier = Modifier.align(Alignment.BottomEnd).padding(end = 14.dp, bottom = 10.dp))
        }
    }

    if (wide) {
      CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF031027)))).padding(horizontal = 28.dp, vertical = if (compact) 12.dp else 18.dp), verticalArrangement = Arrangement.spacedBy(if (compact) 8.dp else 14.dp)) {
            Row(Modifier.fillMaxWidth().height(if (compact) 54.dp else 66.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    Image(painterResource(R.drawable.ic_launcher), null, Modifier.size(54.dp))
                    Column {
                        Text(buildAnnotatedString {
                            withStyle(SpanStyle(color = Color.White)) { append("StreamPlayer ") }
                            withStyle(SpanStyle(color = Accent)) { append("IPTV Pro") }
                        }, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("عالمك الترفيهي في شاشة واحدة", color = Accent, fontSize = 13.sp)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    FocusIcon("▦", Accent, 22.sp) { onOpen("multi") }
                    FocusIcon("★", Color(0xFFFFC107), 22.sp) { onOpen("favorites") }
                    FocusIcon("🔍", Color.White, 22.sp) { onOpen("live") }
                    Text("🔔", fontSize = 20.sp)
                    Text("📶", fontSize = 20.sp)
                    Tile(Modifier.size(42.dp), onSetup) { Icon(Icons.Default.Settings, null, tint = Color(0xFF9CCFFF), modifier = Modifier.align(Alignment.Center)) }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(timeText, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text(dateText, color = Color(0xFF9BB8DA), fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
            PrayerPanel(Modifier.fillMaxWidth().height(if (compact) 92.dp else 108.dp))
            FeaturePanel(Modifier.fillMaxWidth())
            val liveFocus = remember { FocusRequester() }
            LaunchedEffect(Unit) { kotlinx.coroutines.delay(250); runCatching { liveFocus.requestFocus() } }
            Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CategoryCard("البث المباشر", "live", "◉", listOf(Color(0xFF0D4A78), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight().focusRequester(liveFocus))
                CategoryCard("الأفلام", "movies", "🎬", listOf(Color(0xFF17385F), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
                CategoryCard("المسلسلات", "series", "▣", listOf(Color(0xFF153052), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("ℹ  StreamPlayer IPTV Pro     v1.0.0", color = Color(0xFF8AAAD2), fontSize = 12.sp)
                Row(Modifier.clip(RoundedCornerShape(50)).background(Color(0xFF0E2547)).padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(if (msg.startsWith("تم")) Color(0xFF00D58A) else Color(0xFF4C91CB)))
                    Text(msg.ifBlank { "جاهز للاتصال بالسيرفر" }, color = Color(0xFF9BC4F0), fontSize = 11.sp, maxLines = 1)
                }
            }
        }
      }
    } else {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06142C), Color(0xFF031027)))).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("StreamPlayer IPTV Pro", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("عالمك الترفيهي في شاشة واحدة", color = Accent, fontSize = 12.sp)
                }
                Tile(Modifier.size(44.dp), onSetup) { Icon(Icons.Default.Settings, null, tint = Color.White, modifier = Modifier.align(Alignment.Center)) }
            }
            Text("$timeText   •   $dateText", color = Color(0xFF9BB8DA), fontSize = 12.sp)
            PrayerPanel(Modifier.fillMaxWidth().height(118.dp))
            FeaturePanel(Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth().height(130.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CategoryCard("البث المباشر", "live", "◉", listOf(Color(0xFF0D4A78), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
                CategoryCard("الأفلام", "movies", "🎬", listOf(Color(0xFF17385F), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
                CategoryCard("المسلسلات", "series", "▣", listOf(Color(0xFF153052), Color(0xFF07152E)), Modifier.weight(1f).fillMaxHeight())
            }
            Text(msg.ifBlank { "ℹ  StreamPlayer IPTV Pro  •  v1.0.0" }, color = Color(0xFF8AAAD2), fontSize = 12.sp)
        }
    }
}
