package com.example.tviptv

import android.util.JsonReader
import android.util.JsonToken
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class StalkerAccount(input: String, val mac: String) {
    val portal: String = input.trim().let { s ->
        var h = s.trimEnd('/')
        if (!h.startsWith("http://") && !h.startsWith("https://")) h = "http://$h"
        h.removeSuffix("/c").trimEnd('/')
    }
    var endpoint: String = ""
    var token: String = ""
    var channelCache: List<Entry>? = null
}

data class Page(val items: List<Entry>, val total: Int)

object StalkerApi {
    const val UA = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun normalizeMac(input: String): String? {
        val hexStr = input.filter { it.isLetterOrDigit() }.uppercase()
        if (hexStr.length != 12 || !hexStr.all { it in '0'..'9' || it in 'A'..'F' }) return null
        return hexStr.chunked(2).joinToString(":")
    }

    private fun hex(bytes: ByteArray): String = bytes.joinToString("") { "%02X".format(it) }
    private fun serial(mac: String): String =
        hex(MessageDigest.getInstance("MD5").digest(mac.toByteArray())).substring(0, 13)
    private fun deviceId(mac: String): String =
        hex(MessageDigest.getInstance("SHA-256").digest(mac.toByteArray()))

    private fun url(a: StalkerAccount, params: Map<String, String>): String {
        val b = a.endpoint.toHttpUrl().newBuilder()
        params.forEach { (k, v) -> b.addQueryParameter(k, v) }
        b.addQueryParameter("JsHttpRequest", "1-xml")
        return b.build().toString()
    }

    private fun req(a: StalkerAccount, url: String): Request {
        val b = Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("X-User-Agent", "Model: MAG250; Link: WiFi")
            .header("Cookie", "mac=${a.mac}; stb_lang=en; timezone=GMT")
            .header("Accept", "*/*")
        if (a.token.isNotEmpty()) b.header("Authorization", "Bearer ${a.token}")
        return b.build()
    }

    private fun get(a: StalkerAccount, url: String): String {
        client.newCall(req(a, url)).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val s = r.body?.string() ?: throw IOException("Empty response")
            return s.trimStart('\uFEFF')
        }
    }

    private fun candidates(portal: String): List<String> {
        if (portal.endsWith(".php")) return listOf(portal)
        return listOf(
            "$portal/server/load.php",
            "$portal/portal.php",
            "$portal/stalker_portal/server/load.php"
        )
    }

    private fun profileParams(a: StalkerAccount): Map<String, String> = mapOf(
        "type" to "stb",
        "action" to "get_profile",
        "hd" to "1",
        "num_banks" to "2",
        "sn" to serial(a.mac),
        "stb_type" to "MAG250",
        "client_type" to "STB",
        "image_version" to "218",
        "video_out" to "hdmi",
        "device_id" to deviceId(a.mac),
        "device_id2" to deviceId(a.mac),
        "auth_second_step" to "1",
        "hw_version" to "1.7-BD-00",
        "not_valid_token" to "0"
    )

    suspend fun connect(a: StalkerAccount) {
        withContext(Dispatchers.IO) {
            var lastErr: Exception? = null
            var ok = false
            for (ep in candidates(a.portal)) {
                try {
                    a.endpoint = ep
                    a.token = ""
                    val hs = JSONObject(
                        get(a, url(a, mapOf("type" to "stb", "action" to "handshake", "token" to "")))
                    )
                    val js = hs.optJSONObject("js") ?: throw IOException("رد غير صالح")
                    a.token = js.optString("token")
                    if (a.token == "null") a.token = ""
                    try {
                        get(a, url(a, profileParams(a)))
                    } catch (e: Exception) {
                        // some portals do not need / support this step
                    }
                    val g = JSONObject(get(a, url(a, mapOf("type" to "itv", "action" to "get_genres"))))
                    if (!g.has("js")) throw IOException("رد غير صالح")
                    ok = true
                    break
                } catch (e: Exception) {
                    lastErr = e
                }
            }
            if (!ok) {
                throw IOException("تعذّر الاتصال بالبوابة، تحقق من الرابط وعنوان MAC (${lastErr?.message ?: ""})")
            }
        }
    }

    suspend fun categories(a: StalkerAccount, kind: Kind): List<Category> = withContext(Dispatchers.IO) {
        val live = kind == Kind.LIVE
        val type = if (live) "itv" else "vod"
        val action = if (live) "get_genres" else "get_categories"
        val js = JSONObject(get(a, url(a, mapOf("type" to type, "action" to action)))).opt("js")
        val arr = js as? JSONArray ?: JSONArray()
        val out = mutableListOf<Category>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id == "*" || id.isEmpty()) continue
            val title = o.optString("title").ifBlank { o.optString("name") }
            out.add(Category(id, title))
        }
        out
    }

    suspend fun allChannels(a: StalkerAccount): List<Entry> {
        val cached = a.channelCache
        if (cached != null) return cached
        return withContext(Dispatchers.IO) {
            val out = ArrayList<Entry>()
            val keys = setOf("id", "name", "cmd", "tv_genre_id")
            val add: (Map<String, String>) -> Unit = { m ->
                out.add(Entry(m["id"] ?: "", m["name"] ?: "", "", m["cmd"] ?: "", m["tv_genre_id"] ?: ""))
            }
            val request = req(a, url(a, mapOf("type" to "itv", "action" to "get_all_channels")))
            client.newCall(request).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val body = r.body ?: throw IOException("Empty response")
                JsonReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { rd ->
                    rd.isLenient = true
                    rd.beginObject()
                    while (rd.hasNext()) {
                        if (rd.nextName() != "js") {
                            rd.skipValue()
                        } else {
                            val t = rd.peek()
                            if (t == JsonToken.BEGIN_ARRAY) {
                                JsonStream.readObjects(rd, keys, add)
                            } else if (t == JsonToken.BEGIN_OBJECT) {
                                rd.beginObject()
                                while (rd.hasNext()) {
                                    if (rd.nextName() == "data") {
                                        JsonStream.readObjects(rd, keys, add)
                                    } else {
                                        rd.skipValue()
                                    }
                                }
                                rd.endObject()
                            } else {
                                rd.skipValue()
                            }
                        }
                    }
                    rd.endObject()
                }
            }
            a.channelCache = out
            out
        }
    }

    suspend fun page(a: StalkerAccount, type: String, catId: String, p: Int): Page =
        withContext(Dispatchers.IO) {
            val key = if (type == "itv") "genre" else "category"
            val params = mapOf(
                "type" to type,
                "action" to "get_ordered_list",
                key to catId,
                "p" to p.toString(),
                "sortby" to "added"
            )
            val js = JSONObject(get(a, url(a, params))).optJSONObject("js")
            if (js == null) {
                Page(emptyList(), 0)
            } else {
                val data = js.optJSONArray("data") ?: JSONArray()
                val list = mutableListOf<Entry>()
                for (i in 0 until data.length()) {
                    val o = data.optJSONObject(i) ?: continue
                    list.add(Entry(o.optString("id"), o.optString("name"), "", o.optString("cmd"), ""))
                }
                Page(list, js.optInt("total_items"))
            }
        }

    private fun clean(raw: String): String {
        val t = raw.trim()
        val m = Regex("https?://").find(t)
        if (m != null) return t.substring(m.range.first).trim()
        val sp = t.indexOf(' ')
        return if (sp > 0) t.substring(sp + 1).trim() else t
    }

    private suspend fun requestLink(a: StalkerAccount, type: String, cmd: String): String =
        withContext(Dispatchers.IO) {
            val params = mapOf(
                "type" to type,
                "action" to "create_link",
                "cmd" to cmd,
                "series" to "",
                "forced_storage" to "undefined",
                "disable_ad" to "0",
                "download" to "0"
            )
            val js = JSONObject(get(a, url(a, params))).optJSONObject("js")
                ?: throw IOException("لا يوجد رابط")
            val u = clean(js.optString("cmd"))
            if (u.isBlank()) throw IOException("لا يوجد رابط")
            u
        }

    suspend fun createLink(a: StalkerAccount, type: String, cmd: String): String {
        try {
            return requestLink(a, type, cmd)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            try {
                connect(a)
                return requestLink(a, type, cmd)
            } catch (e2: CancellationException) {
                throw e2
            } catch (e2: Exception) {
                val direct = clean(cmd)
                if (direct.startsWith("http")) return direct
                throw e2
            }
        }
    }

    suspend fun info(a: StalkerAccount): List<Pair<String, String>> = withContext(Dispatchers.IO) {
        val out = mutableListOf("البوابة" to a.portal, "عنوان MAC" to a.mac)
        try {
            val js = JSONObject(
                get(a, url(a, mapOf("type" to "account_info", "action" to "get_main_info")))
            ).optJSONObject("js")
            if (js != null) {
                val phone = js.optString("phone")
                if (phone.isNotBlank() && phone != "null") out.add("تاريخ الانتهاء" to phone)
            }
        } catch (e: Exception) {
            // info is optional
        }
        out
    }
}
