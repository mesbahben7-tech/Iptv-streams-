package com.example.tviptv

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class InfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val acc = Session.account
        val sa = Session.stalker
        if (acc == null && sa == null) {
            finish()
            return
        }
        setContentView(R.layout.activity_info)
        val tv = findViewById<TextView>(R.id.info)
        tv.text = getString(R.string.connecting)
        lifecycleScope.launch {
            try {
                val lines = if (sa != null) {
                    StalkerApi.info(sa)
                } else if (acc != null) {
                    XtreamApi.info(acc)
                } else {
                    emptyList()
                }
                tv.text = lines.joinToString("\n\n") { "${it.first}:  ${it.second}" }
            } catch (e: Exception) {
                tv.text = getString(R.string.load_error, e.message ?: "")
            }
        }
    }
}
