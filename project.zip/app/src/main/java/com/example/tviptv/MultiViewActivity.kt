package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.ui.PlayerView

class MultiViewActivity : AppCompatActivity() {

    private val cells = arrayOfNulls<Entry>(4)
    private val players = arrayOfNulls<PreviewPlayer>(4)
    private val frames = ArrayList<View>()
    private val pvs = ArrayList<PlayerView>()
    private val names = ArrayList<TextView>()
    private val pluses = ArrayList<TextView>()
    private lateinit var row1: View
    private lateinit var row2: View
    private var mode = 0
    private var active = 0
    private var pending = -1
    private var started = false

    private val picker = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val e = Session.picked
        Session.picked = null
        val i = pending
        pending = -1
        if (res.resultCode == RESULT_OK && e != null && i in 0..3) assign(i, e)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        setContentView(R.layout.activity_multi)
        val cellIds = intArrayOf(R.id.cell0, R.id.cell1, R.id.cell2, R.id.cell3)
        val pvIds = intArrayOf(R.id.pv0, R.id.pv1, R.id.pv2, R.id.pv3)
        val nameIds = intArrayOf(R.id.name0, R.id.name1, R.id.name2, R.id.name3)
        val plusIds = intArrayOf(R.id.plus0, R.id.plus1, R.id.plus2, R.id.plus3)
        for (i in 0..3) {
            val f = findViewById<View>(cellIds[i])
            frames.add(f)
            val pv = findViewById<PlayerView>(pvIds[i])
            pv.useController = false
            pvs.add(pv)
            names.add(findViewById<TextView>(nameIds[i]))
            pluses.add(findViewById<TextView>(plusIds[i]))
            f.setOnClickListener { onCellClick(i) }
            f.setOnFocusChangeListener { _, has -> if (has) setActive(i) }
        }
        row1 = findViewById(R.id.row1)
        row2 = findViewById(R.id.row2)
        findViewById<Button>(R.id.btn_l22).setOnClickListener { setMode(0) }
        findViewById<Button>(R.id.btn_l21).setOnClickListener { setMode(1) }
        findViewById<Button>(R.id.btn_l12).setOnClickListener { setMode(2) }
        findViewById<Button>(R.id.btn_l11).setOnClickListener { setMode(3) }
        applyMode()
        frames[0].requestFocus()
        Toast.makeText(this, R.string.multi_warn, Toast.LENGTH_LONG).show()
    }

    override fun onStart() {
        super.onStart()
        started = true
        for (i in 0..3) startCell(i)
    }

    override fun onStop() {
        super.onStop()
        started = false
        for (i in 0..3) stopCell(i)
    }

    private fun startCell(i: Int) {
        if (!started || frames[i].visibility != View.VISIBLE) return
        val e = cells[i] ?: return
        if (players[i] != null) return
        val p = PreviewPlayer(this, pvs[i], 640, 360) {
            Toast.makeText(this, R.string.preview_error, Toast.LENGTH_SHORT).show()
        }
        p.start()
        p.setVolume(if (i == active) 1f else 0f)
        p.play(Playback.item(Kind.LIVE, e))
        players[i] = p
    }

    private fun stopCell(i: Int) {
        players[i]?.stop()
        players[i] = null
    }

    private fun updateLabels() {
        for (i in 0..3) {
            val e = cells[i]
            names[i].text = e?.name ?: ""
            names[i].visibility = if (e != null) View.VISIBLE else View.GONE
            pluses[i].visibility = if (e == null) View.VISIBLE else View.GONE
        }
    }

    private fun setActive(i: Int) {
        active = i
        for (j in 0..3) players[j]?.setVolume(if (j == i) 1f else 0f)
    }

    private fun assign(i: Int, e: Entry) {
        cells[i] = e
        stopCell(i)
        updateLabels()
        startCell(i)
        setActive(i)
    }

    private fun remove(i: Int) {
        cells[i] = null
        stopCell(i)
        updateLabels()
    }

    private fun pick(i: Int) {
        pending = i
        picker.launch(Intent(this, LiveActivity::class.java).putExtra("pick", true))
    }

    private fun onCellClick(i: Int) {
        val e = cells[i]
        if (e == null) {
            pick(i)
            return
        }
        val items = arrayOf(
            getString(R.string.multi_change),
            getString(R.string.multi_remove),
            getString(R.string.multi_full)
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> pick(i)
                    1 -> remove(i)
                    2 -> Playback.play(this, Kind.LIVE, listOf(e), 0)
                    else -> {}
                }
            }
            .show()
    }

    private fun setMode(m: Int) {
        mode = m
        applyMode()
    }

    private fun applyMode() {
        val vis = when (mode) {
            0 -> booleanArrayOf(true, true, true, true)
            1 -> booleanArrayOf(true, true, false, false)
            2 -> booleanArrayOf(true, false, true, false)
            else -> booleanArrayOf(true, false, false, false)
        }
        for (i in 0..3) {
            frames[i].visibility = if (vis[i]) View.VISIBLE else View.GONE
            if (!vis[i]) stopCell(i)
        }
        row1.visibility = if (vis[0] || vis[1]) View.VISIBLE else View.GONE
        row2.visibility = if (vis[2] || vis[3]) View.VISIBLE else View.GONE
        updateLabels()
        for (i in 0..3) startCell(i)
    }
}
