package com.example.tviptv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class M3uSource(val url: String, val live: List<Entry>, val movies: List<Entry>) {
    fun list(kind: Kind): List<Entry> = when (kind) {
        Kind.LIVE -> live
        Kind.MOVIES -> movies
        Kind.SERIES -> emptyList()
    }

    fun categories(kind: Kind): List<Category> =
        list(kind).map { it.group }.distinct().map { Category(it, it) }

    fun entries(kind: Kind, groupId: String): List<Entry> =
        if (groupId.isEmpty()) list(kind) else list(kind).filter { it.group == groupId }

    fun search(kind: Kind, q: String): List<Entry> =
        list(kind).filter { it.name.contains(q, ignoreCase = true) }
}

object M3uApi {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private val attr = Regex("([\\w-]+)=\"([^\"]*)\"")
    private val movieExt = listOf(".mp4", ".mkv", ".avi", ".mov", ".m4v", ".wmv")

    suspend fun load(url: String): M3uSource = withContext(Dispatchers.IO) {
        val req = Request.Builder().url(url).header("User-Agent", "IPTVPlayer/1.0").build()
        client.newCall(req).execute().use { r ->
            if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
            val body = r.body ?: throw IOException("Empty response")
            parse(url, body.byteStream())
        }
    }

    fun parse(url: String, input: InputStream): M3uSource {
        val live = ArrayList<Entry>()
        val movies = ArrayList<Entry>()
        var name = ""
        var logo = ""
        var group = ""
        var pending = false
        var n = 0
        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { br ->
            while (true) {
                val raw = br.readLine() ?: break
                val line = raw.trim()
                if (line.isEmpty()) continue
                if (line.startsWith("#EXTINF")) {
                    pending = true
                    logo = ""
                    group = ""
                    for (m in attr.findAll(line)) {
                        val key = m.groupValues[1].lowercase()
                        if (key == "tvg-logo") logo = m.groupValues[2]
                        if (key == "group-title") group = m.groupValues[2]
                    }
                    val comma = line.lastIndexOf(',')
                    name = if (comma >= 0) line.substring(comma + 1).trim() else ""
                } else if (line.startsWith("#")) {
                    continue
                } else if (pending) {
                    pending = false
                    n++
                    val path = line.lowercase().substringBefore('?')
                    val isMovie = movieExt.any { path.endsWith(it) }
                    val e = Entry(
                        n.toString(),
                        name.ifBlank { "Channel $n" },
                        "",
                        line,
                        group.ifBlank { "غير مصنّف" },
                        logo
                    )
                    if (isMovie) movies.add(e) else live.add(e)
                }
            }
        }
        if (live.isEmpty() && movies.isEmpty()) throw IOException("القائمة فارغة أو غير صالحة")
        return M3uSource(url, live, movies)
    }
}
