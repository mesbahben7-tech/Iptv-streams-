package com.example.tviptv

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException

class ServerFormActivity : AppCompatActivity() {

    private var type = "xtream"
    private var existing: Server? = null
    private lateinit var fName: EditText
    private lateinit var fUrl: EditText
    private lateinit var fUser: EditText
    private lateinit var fPass: EditText
    private lateinit var fMac: EditText
    private lateinit var swEnable: SwitchCompat
    private lateinit var btnSave: Button
    private lateinit var status: TextView
    private var forceSave = false
    private var busy = false

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) openFile(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getStringExtra("id")
        existing = if (id != null) ServerStore.get(this, id) else null
        type = existing?.type ?: (intent.getStringExtra("type") ?: "xtream")
        setContentView(R.layout.activity_server_form)

        fName = findViewById(R.id.f_name)
        fUrl = findViewById(R.id.f_url)
        fUser = findViewById(R.id.f_user)
        fPass = findViewById(R.id.f_pass)
        fMac = findViewById(R.id.f_mac)
        swEnable = findViewById(R.id.sw_enable)
        btnSave = findViewById(R.id.btn_save)
        status = findViewById(R.id.status)
        val lblUrl = findViewById<TextView>(R.id.lbl_url)
        val grpUser = findViewById<View>(R.id.grp_user)
        val grpMac = findViewById<View>(R.id.grp_mac)
        val btnFile = findViewById<Button>(R.id.btn_file)
        val btnDelete = findViewById<Button>(R.id.btn_delete)

        val typeName = when (type) {
            "m3u" -> getString(R.string.type_m3u_title)
            "stalker" -> getString(R.string.type_stalker_title)
            else -> getString(R.string.type_xtream_title)
        }
        val head = getString(if (existing != null) R.string.form_edit else R.string.form_add)
        findViewById<TextView>(R.id.form_title).text = "$head  ·  $typeName"

        when (type) {
            "m3u" -> {
                lblUrl.setText(R.string.f_url_m3u)
                fUrl.hint = "http://example.com/playlist.m3u"
                grpUser.visibility = View.GONE
                grpMac.visibility = View.GONE
                btnFile.visibility = View.VISIBLE
            }
            "stalker" -> {
                lblUrl.setText(R.string.f_url_stalker)
                fUrl.hint = "http://example.com/c"
                grpUser.visibility = View.GONE
                grpMac.visibility = View.VISIBLE
            }
            else -> {
                lblUrl.setText(R.string.f_url_xtream)
                fUrl.hint = "http://example.com:8080"
                grpUser.visibility = View.VISIBLE
                grpMac.visibility = View.GONE
            }
        }

        val ex = existing
        if (ex != null) {
            fName.setText(ex.name)
            fUrl.setText(ex.url)
            fUser.setText(ex.user)
            fPass.setText(ex.pass)
            fMac.setText(ex.mac)
            swEnable.isChecked = ex.enabled
            btnDelete.visibility = View.VISIBLE
        }

        btnSave.setOnClickListener { onSave() }
        btnFile.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        btnDelete.setOnClickListener { confirmDelete() }
    }

    private fun onSave() {
        if (busy) return
        val url = fUrl.text.toString().trim()
        val user = fUser.text.toString().trim()
        val pass = fPass.text.toString().trim()
        var mac = fMac.text.toString().trim()
        if (url.isEmpty()) {
            status.text = getString(R.string.need_fields)
            return
        }
        if (type == "xtream" && (user.isEmpty() || pass.isEmpty())) {
            status.text = getString(R.string.need_fields)
            return
        }
        if (type == "stalker") {
            val n = StalkerApi.normalizeMac(mac)
            if (n == null) {
                status.text = getString(R.string.bad_mac)
                return
            }
            mac = n
        }
        val name = fName.text.toString().trim().ifEmpty { ServerStore.defaultName(type, url) }
        val server = Server(
            existing?.id ?: ServerStore.newId(), name, type, url, user, pass, mac,
            swEnable.isChecked, existing?.status ?: 0
        )
        if (forceSave || type == "m3u" || !server.enabled) {
            finishSave(server, server.status)
            return
        }
        busy = true
        btnSave.isEnabled = false
        status.text = getString(R.string.connecting)
        lifecycleScope.launch {
            try {
                Connector.connect(this@ServerFormActivity, server)
                finishSave(server, 1)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                status.text = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
                forceSave = true
                btnSave.setText(R.string.btn_save_anyway)
            } finally {
                busy = false
                btnSave.isEnabled = true
            }
        }
    }

    private fun finishSave(server: Server, st: Int) {
        ServerStore.upsert(this, server.copy(status = st))
        if (existing != null) {
            Toast.makeText(this, R.string.saved_edit, Toast.LENGTH_SHORT).show()
        } else {
            startActivity(Intent(this, ServerSavedActivity::class.java).putExtra("id", server.id))
        }
        finish()
    }

    private fun confirmDelete() {
        val ex = existing ?: return
        AlertDialog.Builder(this)
            .setTitle(R.string.confirm_delete)
            .setMessage(ex.name)
            .setPositiveButton(R.string.yes) { _, _ ->
                ServerStore.delete(this, ex.id)
                finish()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun openFile(uri: Uri) {
        status.text = getString(R.string.connecting)
        lifecycleScope.launch {
            try {
                val src = withContext(Dispatchers.IO) {
                    val stream = contentResolver.openInputStream(uri) ?: throw IOException("تعذّر فتح الملف")
                    stream.use { M3uApi.parse("file", it) }
                }
                Session.m3u = src
                Session.account = null
                Session.stalker = null
                Session.serverName = getString(R.string.file_server)
                status.text = ""
                startActivity(Intent(this@ServerFormActivity, HomeActivity::class.java))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                status.text = getString(R.string.load_error, e.message ?: e.javaClass.simpleName)
            }
        }
    }
}
