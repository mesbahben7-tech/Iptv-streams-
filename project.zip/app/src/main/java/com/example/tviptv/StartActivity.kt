package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class StartActivity : AppCompatActivity() {

    private fun toast(res: Int) {
        Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)

        val xtream = findViewById<Button>(R.id.btn_xtream)
        xtream.setOnClickListener { startActivity(Intent(this, MainActivity::class.java)) }
        findViewById<Button>(R.id.btn_m3u).setOnClickListener {
            startActivity(Intent(this, M3uLoginActivity::class.java))
        }
        findViewById<Button>(R.id.btn_mac).setOnClickListener {
            startActivity(Intent(this, StalkerLoginActivity::class.java))
        }
        findViewById<Button>(R.id.btn_playlist).setOnClickListener { openSaved() }
        xtream.requestFocus()
        showPreviousCrash()
    }

    private fun showPreviousCrash() {
        val cp = getSharedPreferences("crash", MODE_PRIVATE)
        val log = cp.getString("log", null) ?: return
        cp.edit().remove("log").apply()
        AlertDialog.Builder(this)
            .setTitle("سبب إغلاق التطبيق في المرة السابقة")
            .setMessage(log)
            .setPositiveButton("حسنًا", null)
            .show()
    }

    private fun fail(e: Exception) {
        Toast.makeText(this, getString(R.string.load_error, e.message ?: ""), Toast.LENGTH_LONG).show()
    }

    private fun openSavedM3u() {
        val url = getSharedPreferences("m3u", MODE_PRIVATE).getString("url", "") ?: ""
        if (url.isEmpty()) {
            toast(R.string.no_saved)
            return
        }
        toast(R.string.connecting)
        lifecycleScope.launch {
            try {
                val src = M3uApi.load(url)
                Session.m3u = src
                Session.account = null
                Session.stalker = null
                startActivity(Intent(this@StartActivity, HomeActivity::class.java))
            } catch (e: Exception) {
                fail(e)
            }
        }
    }

    private fun openSaved() {
        val last = getSharedPreferences("app", MODE_PRIVATE).getString("last", "") ?: ""
        if (last == "m3u") {
            openSavedM3u()
            return
        }
        if (last == "stalker") {
            val p = getSharedPreferences("stalker", MODE_PRIVATE)
            val portal = p.getString("portal", "") ?: ""
            val mac = p.getString("mac", "") ?: ""
            if (portal.isEmpty() || mac.isEmpty()) {
                toast(R.string.no_saved)
                return
            }
            val acc = StalkerAccount(portal, mac)
            toast(R.string.connecting)
            lifecycleScope.launch {
                try {
                    StalkerApi.connect(acc)
                    Session.stalker = acc
                    Session.account = null
                    startActivity(Intent(this@StartActivity, HomeActivity::class.java))
                } catch (e: Exception) {
                    fail(e)
                }
            }
            return
        }
        val prefs = getSharedPreferences("acc", MODE_PRIVATE)
        val host = prefs.getString("host", "") ?: ""
        if (host.isEmpty()) {
            toast(R.string.no_saved)
            return
        }
        val acc = Account.from(host, prefs.getString("user", "") ?: "", prefs.getString("pass", "") ?: "")
        toast(R.string.connecting)
        lifecycleScope.launch {
            try {
                XtreamApi.login(acc)
                Session.account = acc
                Session.stalker = null
                startActivity(Intent(this@StartActivity, HomeActivity::class.java))
            } catch (e: Exception) {
                fail(e)
            }
        }
    }
}
