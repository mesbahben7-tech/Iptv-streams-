package com.example.tviptv

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class HomeActivity : AppCompatActivity() {

    private fun openKind(kind: Kind) {
        startActivity(Intent(this, BrowseActivity::class.java).putExtra("kind", kind.name))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Session.hasSource()) {
            finish()
            return
        }
        setContentView(R.layout.activity_home)
        val live = findViewById<Button>(R.id.btn_live)
        live.setOnClickListener { openKind(Kind.LIVE) }
        findViewById<Button>(R.id.btn_movies).setOnClickListener { openKind(Kind.MOVIES) }
        findViewById<Button>(R.id.btn_series).setOnClickListener {
            if (Session.stalker != null) {
                Toast.makeText(this, R.string.coming_soon, Toast.LENGTH_SHORT).show()
            } else {
                openKind(Kind.SERIES)
            }
        }
        findViewById<Button>(R.id.btn_info).setOnClickListener {
            startActivity(Intent(this, InfoActivity::class.java))
        }
        live.requestFocus()
    }
}
