package com.streamplayer.iptv

import android.content.SharedPreferences
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

data class Channel(
    val name: String, val url: String, val logo: String? = null, val cmd: String? = null,
    val type: String = "itv", val ep: Int = 0, val id: String = "",
    /** إن وُجد: العنصر مسلسل، والضغط عليه يفتح قائمة الحلقات */
    val loader: (suspend () -> List<Channel>)? = null,
    val categoryId: String = "", val categoryName: String = "",
    val rating: String = "", val year: String = ""
)

data class EpgItem(val title: String, val from: String, val to: String)

fun yearOf(name: String, date: String): String =
    Regex("(19|20)\\d{2}").find(date.takeIf { '-' in it } ?: "")?.value ?: Regex("\\((19|20)\\d{2}\\)").find(name)?.value?.trim('(', ')') ?: ""
/** type: m3u (a=url) | xtream (a=server, b=user, c=pass) | stalker (a=portal, b=MAC) */
data class Source(val type: String, val a: String, val b: String = "", val c: String = "")

data class Prayer(val name: String, val time: String)

/** مواقيت الصلاة من aladhan.com (الجزائر: وزارة الشؤون الدينية، غيرها: رابطة العالم الإسلامي) */
suspend fun prayerTimes(city: String, country: String): List<Prayer> {
    fun e(x: String) = URLEncoder.encode(x, "UTF-8")
    val method = if (country.trim().lowercase() in setOf("algeria", "الجزائر")) 19 else 3
    val t = JSONObject(get("https://api.aladhan.com/v1/timingsByCity?city=${e(city)}&country=${e(country)}&method=$method"))
        .getJSONObject("data").getJSONObject("timings")
    return listOf("الفجر" to "Fajr", "الظهر" to "Dhuhr", "العصر" to "Asr", "المغرب" to "Maghrib", "العشاء" to "Isha")
        .map { Prayer(it.first, t.getString(it.second).take(5)) }
}

private val http = OkHttpClient()
suspend fun get(url: String, headers: Map<String, String> = emptyMap()): String = withContext(Dispatchers.IO) {
    val r = Request.Builder().url(url).apply { headers.forEach { (k, v) -> addHeader(k, v) } }.build()
    http.newCall(r).execute().use { it.body?.string() ?: "" }
}

object M3u {
    fun parse(t: String): List<Channel> {
        val out = mutableListOf<Channel>(); var name = ""; var logo: String? = null; var group = ""
        for (l in t.lineSequence().map { it.trim() }) {
            if (l.startsWith("#EXTINF")) {
                name = l.substringAfterLast(",")
                logo = Regex("tvg-logo=\"([^\"]*)\"").find(l)?.groupValues?.get(1)
                group = Regex("group-title=\"([^\"]*)\"").find(l)?.groupValues?.get(1).orEmpty()
            } else if (l.isNotEmpty() && !l.startsWith("#")) {
                val kind = when { "/movie/" in l -> "movie"; "/series/" in l -> "series"; else -> "itv" }
                out += Channel(name.ifBlank { l }, l, logo, type = kind, categoryName = group); name = ""; logo = null; group = ""
            }
        }
        return out
    }
}

class Xtream(server: String, private val u: String, private val p: String) {
    private val base = server.trimEnd('/')
    private suspend fun api(action: String) =
        JSONArray(get("$base/player_api.php?username=$u&password=$p&action=$action"))

    private suspend fun categoryMap(action: String): Map<String, String> = runCatching {
        val a = api(action)
        (0 until a.length()).associate { i ->
            val o = a.getJSONObject(i)
            o.optString("category_id") to o.optString("category_name", "غير مصنف")
        }.filterKeys { it.isNotBlank() }
    }.getOrDefault(emptyMap())

    suspend fun live(): List<Channel> {
        val categories = categoryMap("get_live_categories")
        return api("get_live_streams").let { a ->
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                val catId = o.optString("category_id")
                Channel(o.optString("name"), "$base/live/$u/$p/${o.optString("stream_id")}.m3u8", o.optString("stream_icon"), id = o.optString("stream_id"), categoryId = catId, categoryName = categories[catId] ?: if (catId.isNotBlank()) "غير مصنف" else "")
            }
        }
    }

    suspend fun movies(): List<Channel> {
        val categories = categoryMap("get_vod_categories")
        return api("get_vod_streams").let { a ->
            (0 until a.length()).map {
                val o = a.getJSONObject(it); val catId = o.optString("category_id")
                val ext = o.optString("container_extension", "mp4")
                Channel(o.optString("name"), "$base/movie/$u/$p/${o.optString("stream_id")}.$ext", o.optString("stream_icon"), type = "movie", categoryId = catId, categoryName = categories[catId] ?: if (catId.isNotBlank()) "غير مصنف" else "", rating = o.optString("rating"), year = yearOf(o.optString("name"), ""))
            }
        }
    }

    /** البرنامج الحالي والتالي (XMLTV غير مدعوم حالياً لـ M3U) */
    suspend fun epg(id: String): List<String> {
        val arr = JSONObject(get("$base/player_api.php?username=$u&password=$p&action=get_short_epg&stream_id=$id&limit=2"))
            .optJSONArray("epg_listings") ?: return emptyList()
        return (0 until arr.length()).map {
            val t = arr.getJSONObject(it).optString("title")
            runCatching { String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8) }.getOrDefault(t)
        }
    }

    suspend fun epgFull(id: String): List<EpgItem> {
        val arr = JSONObject(get("$base/player_api.php?username=$u&password=$p&action=get_short_epg&stream_id=$id&limit=6"))
            .optJSONArray("epg_listings") ?: return emptyList()
        val f = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US)
        fun hm(o: JSONObject, k: String) = o.optString(k).toLongOrNull()?.let { s -> f.format(java.util.Date(s * 1000)) } ?: ""
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it); val t = o.optString("title")
            EpgItem(runCatching { String(Base64.decode(t, Base64.DEFAULT), Charsets.UTF_8) }.getOrDefault(t), hm(o, "start_timestamp"), hm(o, "stop_timestamp"))
        }
    }

    suspend fun series(): List<Channel> {
        val categories = categoryMap("get_series_categories")
        return api("get_series").let { a ->
            (0 until a.length()).map {
                val o = a.getJSONObject(it); val id = o.optString("series_id"); val catId = o.optString("category_id")
                Channel(o.optString("name"), "", o.optString("cover"), type = "series", loader = { episodes(id) }, categoryId = catId, categoryName = categories[catId] ?: if (catId.isNotBlank()) "غير مصنف" else "", rating = o.optString("rating"), year = yearOf(o.optString("name"), o.optString("releaseDate", o.optString("release_date"))))
            }
        }
    }

    private suspend fun episodes(id: String): List<Channel> {
        val eps = JSONObject(get("$base/player_api.php?username=$u&password=$p&action=get_series_info&series_id=$id"))
            .optJSONObject("episodes") ?: return emptyList()
        val out = mutableListOf<Channel>()
        for (s in eps.keys().asSequence().toList().sortedBy { it.toIntOrNull() ?: 0 }) {
            val arr = eps.getJSONArray(s)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ext = o.optString("container_extension", "mp4")
                out += Channel("S$s E${o.optString("episode_num")} - ${o.optString("title")}",
                    "$base/series/$u/$p/${o.optString("id")}.$ext")
            }
        }
        return out
    }
}

class Stalker(portal: String, private val mac: String) {
    private val root = portal.trimEnd('/').removeSuffix("/c")
    private val base = "$root/server/load.php"
    private val origin = java.net.URI(root).let { "${it.scheme}://${it.authority}" }
    /** يحوّل مسار الشعار/الصورة النسبي إلى رابط كامل */
    private fun img(x: String): String = when {
        x.isBlank() || x.startsWith("http") -> x
        x.startsWith("/") -> origin + x
        else -> (if (root.endsWith("stalker_portal")) root else "$root/stalker_portal") + "/misc/logos/320/" + x
    }
    private var token = ""
    private fun headers() = mapOf(
        "Cookie" to "mac=$mac; stb_lang=en; timezone=GMT",
        "Authorization" to "Bearer $token",
        "User-Agent" to "Mozilla/5.0 (QtEmbedded; U; Linux; C) MAG250"
    )
    private suspend fun call(q: String): JSONObject? =
        JSONObject(get("$base?$q&JsHttpRequest=1-xml", headers())).optJSONObject("js")

    suspend fun live(): List<Channel> {
        token = call("type=stb&action=handshake&token=")?.optString("token") ?: ""
        val genres = runCatching {
            val g = call("type=itv&action=get_genres")?.optJSONArray("data") ?: JSONArray()
            (0 until g.length()).associate { i -> val o = g.getJSONObject(i); o.optString("id") to o.optString("title", o.optString("name")) }
        }.getOrDefault(emptyMap())
        val arr = call("type=itv&action=get_all_channels")?.optJSONArray("data") ?: return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it); val catId = o.optString("tv_genre_id", o.optString("genre_id"))
            Channel(o.optString("name"), "", img(o.optString("logo")), cmd = o.optString("cmd"), id = o.optString("id"), categoryId = catId, categoryName = genres[catId] ?: if (catId.isNotBlank()) "غير مصنف" else "")
        }
    }

    suspend fun resolve(cmd: String, type: String = "itv", ep: Int = 0): String {
        val extra = if (ep > 0) "&series=$ep" else ""
        val c = call("type=$type&action=create_link&cmd=" + URLEncoder.encode(cmd, "UTF-8") + extra)?.optString("cmd") ?: cmd
        return c.substringAfter(" ").trim()
    }

    suspend fun epg(chId: String): List<String> {
        val arr = JSONObject(get("$base?type=itv&action=get_short_epg&ch_id=$chId&size=2&JsHttpRequest=1-xml", headers()))
            .optJSONArray("js") ?: return emptyList()
        return (0 until arr.length()).map { arr.getJSONObject(it).optString("name") }
    }

    suspend fun epgFull(chId: String): List<EpgItem> {
        val arr = JSONObject(get("$base?type=itv&action=get_short_epg&ch_id=$chId&size=6&JsHttpRequest=1-xml", headers())).optJSONArray("js") ?: return emptyList()
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            EpgItem(o.optString("name"), o.optString("time").drop(11).take(5), o.optString("time_to").drop(11).take(5))
        }
    }

    private suspend fun items(type: String): List<JSONObject> {
        val out = mutableListOf<JSONObject>()
        var page = 1; var total = Int.MAX_VALUE
        while (out.size < total && page <= 20) { // حد أقصى 20 صفحة؛ ارفعه عند الحاجة
            val js = call("type=$type&action=get_ordered_list&p=$page") ?: break
            val arr = js.optJSONArray("data") ?: break
            if (arr.length() == 0) break
            for (i in 0 until arr.length()) out += arr.getJSONObject(i)
            total = js.optInt("total_items", out.size); page++
        }
        return out
    }

    suspend fun movies() = items("vod").map {
        Channel(it.optString("name"), "", img(it.optString("screenshot_uri")), it.optString("cmd"), "vod", year = it.optString("year"), rating = it.optString("rating_imdb"))
    }

    suspend fun series() = items("series").map { o ->
        val cmd = o.optString("cmd"); val eps = o.optJSONArray("series")
        Channel(o.optString("name"), "", img(o.optString("screenshot_uri")), year = o.optString("year"), rating = o.optString("rating_imdb"), loader = {
            if (eps == null || eps.length() == 0) listOf(Channel(o.optString("name"), "", cmd = cmd, type = "vod"))
            else (0 until eps.length()).map { Channel("حلقة ${eps.optInt(it)}", "", cmd = cmd, type = "vod", ep = eps.optInt(it)) }
        })
    }
}

object Repo {
    var live = listOf<Channel>(); var movies = listOf<Channel>(); var series = listOf<Channel>()
    var stalker: Stalker? = null
    var xtream: Xtream? = null
    private val epgCache = java.util.concurrent.ConcurrentHashMap<String, List<String>>()

    /** [الحالي، التالي] للقنوات المباشرة في Xtream وStalker */
    suspend fun nowNext(c: Channel): List<String> {
        if (c.id.isBlank() || c.type != "itv") return emptyList()
        epgCache[c.id]?.let { return it }
        val r = runCatching { xtream?.epg(c.id) ?: stalker?.epg(c.id) ?: emptyList() }.getOrDefault(emptyList())
        if (r.isNotEmpty()) epgCache[c.id] = r
        return r
    }

    private val epgFullCache = java.util.concurrent.ConcurrentHashMap<String, List<EpgItem>>()

    suspend fun epgItems(c: Channel): List<EpgItem> {
        if (c.id.isBlank() || c.type != "itv") return emptyList()
        epgFullCache[c.id]?.let { return it }
        val r = runCatching { xtream?.epgFull(c.id) ?: stalker?.epgFull(c.id) ?: emptyList() }.getOrDefault(emptyList())
        if (r.isNotEmpty()) epgFullCache[c.id] = r
        return r
    }

    suspend fun load(s: Source) {
        stalker = null; xtream = null; epgCache.clear(); epgFullCache.clear(); live = emptyList(); movies = emptyList(); series = emptyList()
        when (s.type) {
            "m3u" -> {
                val all = M3u.parse(get(s.a))
                movies = all.filter { "/movie/" in it.url }
                series = all.filter { "/series/" in it.url }
                live = all - movies.toSet() - series.toSet()
            }
            "xtream" -> {
                val x = Xtream(s.a, s.b, s.c); xtream = x; live = x.live()
                movies = runCatching { x.movies() }.getOrDefault(emptyList())
                series = runCatching { x.series() }.getOrDefault(emptyList())
            }
            "stalker" -> {
                val st = Stalker(s.a, s.b); live = st.live(); stalker = st
                movies = runCatching { st.movies() }.getOrDefault(emptyList())
                series = runCatching { st.series() }.getOrDefault(emptyList())
            }
        }
    }
}

/** آخر 20 عنصراً شُغّل (المسلسلات تُحفظ حلقاتها لا المسلسل نفسه) */
object Recent {
    fun load(pr: SharedPreferences): List<Channel> {
        val a = JSONArray(pr.getString("recent", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Channel(o.optString("n"), o.optString("u"), o.optString("l"), o.optString("c").ifBlank { null },
                o.optString("t", "itv"), o.optInt("e"), o.optString("i"))
        }
    }

    fun add(pr: SharedPreferences, c: Channel) {
        val list = (listOf(c) + load(pr).filter { it.name != c.name || it.cmd != c.cmd || it.url != c.url }).take(20)
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("n", it.name).put("u", it.url).put("l", it.logo ?: "").put("c", it.cmd ?: "")
                .put("t", it.type).put("e", it.ep).put("i", it.id))
        }
        pr.edit().putString("recent", a.toString()).apply()
    }
}

/** المفضلة (تُحفظ محلياً) */
object Favs {
    fun key(c: Channel) = c.name + "|" + (c.cmd ?: c.url)
    fun all(pr: SharedPreferences): Set<String> = pr.getStringSet("favs", emptySet()) ?: emptySet()
    fun has(pr: SharedPreferences, c: Channel) = key(c) in all(pr)
    fun toggle(pr: SharedPreferences, c: Channel): Boolean {
        val s = all(pr).toMutableSet(); val k = key(c)
        val on = if (k in s) { s.remove(k); false } else { s.add(k); true }
        pr.edit().putStringSet("favs", s).apply(); return on
    }
}

/** تاريخ انتهاء اشتراك Xtream */
suspend fun xtreamExpiry(server: String, u: String, p: String): String = runCatching {
    val e = JSONObject(get("${server.trimEnd('/')}/player_api.php?username=$u&password=$p")).optJSONObject("user_info")?.optString("exp_date").orEmpty()
    if (e.isBlank() || e == "null") "غير محدد" else java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(e.toLong() * 1000))
}.getOrDefault("—")

/** الرابط الفعلي للتشغيل (يحلّ روابط Stalker) */
suspend fun resolveUrl(c: Channel): String = c.cmd?.let { Repo.stalker?.resolve(it, c.type, c.ep) } ?: c.url

/** تسجيل البث الخام (TS/MP4 المباشر) إلى ملف حتى يُلغى العمل */
suspend fun recordStream(url: String, file: java.io.File) = withContext(Dispatchers.IO) {
    http.newCall(Request.Builder().url(url).build()).execute().use { resp ->
        val src = resp.body?.byteStream() ?: return@use
        file.outputStream().use { out ->
            val buf = ByteArray(64 * 1024)
            while (isActive) { val n = src.read(buf); if (n < 0) break; out.write(buf, 0, n) }
        }
    }
}
