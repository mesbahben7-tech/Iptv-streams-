package com.example.tviptv

import android.util.JsonReader
import android.util.JsonToken

object JsonStream {
    fun str(r: JsonReader): String = when (r.peek()) {
        JsonToken.STRING, JsonToken.NUMBER -> r.nextString()
        JsonToken.BOOLEAN -> r.nextBoolean().toString()
        JsonToken.NULL -> {
            r.nextNull()
            ""
        }
        else -> {
            r.skipValue()
            ""
        }
    }

    /** Reads an array of objects without building a full tree in memory. */
    fun readObjects(r: JsonReader, keys: Set<String>, onObject: (Map<String, String>) -> Unit) {
        if (r.peek() != JsonToken.BEGIN_ARRAY) {
            r.skipValue()
            return
        }
        r.beginArray()
        while (r.hasNext()) {
            if (r.peek() != JsonToken.BEGIN_OBJECT) {
                r.skipValue()
                continue
            }
            val m = HashMap<String, String>()
            r.beginObject()
            while (r.hasNext()) {
                val n = r.nextName()
                if (n in keys) m[n] = str(r) else r.skipValue()
            }
            r.endObject()
            onObject(m)
        }
        r.endArray()
    }
}
