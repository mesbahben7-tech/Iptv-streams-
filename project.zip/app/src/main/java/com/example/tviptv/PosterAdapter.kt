package com.example.tviptv

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class PosterAdapter(
    private val onLongClick: (Int) -> Unit,
    private val onClick: (Int) -> Unit
) : RecyclerView.Adapter<PosterAdapter.VH>() {

    private var data: List<Entry> = emptyList()
    var favIds: Set<String> = emptySet()

    var items: List<Entry>
        get() = data
        set(value) {
            data = value
            notifyDataSetChanged()
        }

    fun append(more: List<Entry>) {
        if (more.isEmpty()) return
        val start = data.size
        data = data + more
        notifyItemRangeInserted(start, more.size)
    }

    fun refresh(position: Int) {
        if (position in data.indices) notifyItemChanged(position)
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val img: ImageView = view.findViewById(R.id.poster)
        val title: TextView = view.findViewById(R.id.title)
        val meta: TextView = view.findViewById(R.id.meta)
        val fav: TextView = view.findViewById(R.id.fav)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_poster, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = data[position]
        holder.title.text = e.name
        val parts = mutableListOf<String>()
        if (e.rating.isNotBlank() && e.rating != "0") parts.add("★ " + e.rating)
        if (e.year.isNotBlank()) parts.add(e.year)
        holder.meta.text = parts.joinToString("   ")
        holder.fav.visibility = if (favIds.contains(e.id)) View.VISIBLE else View.GONE

        if (e.icon.startsWith("http")) {
            Glide.with(holder.img)
                .load(e.icon)
                .override(300, 450)
                .centerCrop()
                .placeholder(R.drawable.poster_placeholder)
                .error(R.drawable.poster_placeholder)
                .into(holder.img)
        } else {
            holder.img.setImageResource(R.drawable.poster_placeholder)
        }

        holder.itemView.setOnClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onClick(p)
        }
        holder.itemView.setOnLongClickListener {
            val p = holder.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) {
                onLongClick(p)
                true
            } else {
                false
            }
        }
    }

    override fun onViewRecycled(holder: VH) {
        try {
            Glide.with(holder.img).clear(holder.img)
        } catch (e: Exception) {
            // activity may already be destroyed
        }
        super.onViewRecycled(holder)
    }

    override fun getItemCount() = data.size
}
